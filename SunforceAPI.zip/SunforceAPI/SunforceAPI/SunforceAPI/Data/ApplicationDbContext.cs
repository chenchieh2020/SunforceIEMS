﻿using Microsoft.EntityFrameworkCore;
using SunforceAPI.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace SunforceAPI.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Alert> Alerts { get; set; }
        public DbSet<RealTimeAlert> RealTimeAlerts { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // 配置 Alert (歷史告警) 的複合主鍵
            modelBuilder.Entity<Alert>()
                .HasKey(a => new { a.DateTime, a.DeviceId });

            // 配置 RealTimeAlert (即時告警) 的複合主鍵
            modelBuilder.Entity<RealTimeAlert>()
                .ToTable("AlertRealTime") // 指定表名
                .HasKey(a => new { a.DataTime, a.DeviceID });

            // 其他映射配置...
        }
    }
}