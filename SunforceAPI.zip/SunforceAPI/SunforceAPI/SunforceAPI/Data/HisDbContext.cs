﻿using Microsoft.EntityFrameworkCore;
using SunforceAPI.Models;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace SunforceAPI.Data
{
    public class HisDbContext : DbContext
    {
        public HisDbContext(DbContextOptions<HisDbContext> options)
            : base(options)
        {
        }

        public DbSet<HisDay> HisDays { get; set; }
        public DbSet<HisMonth> HisMonths { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<HisDay>()
                .HasKey(h => new { h.DataTime, h.DeviceID });

            modelBuilder.Entity<HisMonth>()
                .HasKey(h => new { h.DataTime, h.DeviceID });

            // 如果需要設定欄位對應或資料表名也可以加上
        }
    }
}
