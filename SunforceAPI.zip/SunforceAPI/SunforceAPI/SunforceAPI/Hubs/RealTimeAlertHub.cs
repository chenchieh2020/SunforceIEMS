﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace SunforceAPI.Hubs
{
    /// <summary>
    /// 即時告警 SignalR Hub
    /// 用於處理即時告警的 WebSocket 通訊
    /// </summary>
    public class RealTimeAlertHub : Hub
    {
        private readonly ILogger<RealTimeAlertHub> _logger;

        public RealTimeAlertHub(ILogger<RealTimeAlertHub> logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// 客戶端加入特定分組
        /// </summary>
        /// <param name="group">分組名稱，例如 "global" 或 "alertPage"</param>
        public async Task JoinGroup(string group)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, group);
            _logger.LogInformation("客戶端 {ConnectionId} 已加入組 {Group}", Context.ConnectionId, group);
        }

        /// <summary>
        /// 客戶端離開特定分組
        /// </summary>
        /// <param name="group">分組名稱</param>
        public async Task LeaveGroup(string group)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, group);
            _logger.LogInformation("客戶端 {ConnectionId} 已離開組 {Group}", Context.ConnectionId, group);
        }

        /// <summary>
        /// 客戶端連接時的處理
        /// </summary>
        public override async Task OnConnectedAsync()
        {
            // 預設將所有連接的客戶端加入全局通知組
            await Groups.AddToGroupAsync(Context.ConnectionId, "global");
            _logger.LogInformation("客戶端 {ConnectionId} 已連接並加入全局組", Context.ConnectionId);
            await base.OnConnectedAsync();
        }

        /// <summary>
        /// 客戶端斷開連接時的處理
        /// </summary>
        public override async Task OnDisconnectedAsync(Exception exception)
        {
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, "global");
            _logger.LogInformation("客戶端 {ConnectionId} 已斷開連接", Context.ConnectionId);

            if (exception != null)
            {
                _logger.LogWarning(exception, "客戶端 {ConnectionId} 因錯誤斷開", Context.ConnectionId);
            }

            await base.OnDisconnectedAsync(exception);
        }
    }
}