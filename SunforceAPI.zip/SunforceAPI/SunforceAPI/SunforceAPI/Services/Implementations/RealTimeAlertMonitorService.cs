﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SunforceAPI.Models;
using SunforceAPI.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using SunforceAPI.DTOs;
using System.Data.SqlClient;
using System.Threading;
using System.Threading.Tasks;

namespace SunforceAPI.Services.Implementations
{
    /// <summary>
    /// 即時告警監控後台服務
    /// 定期從數據庫檢查新的告警並通過 WebSocket 推送給客戶端
    /// </summary>
    public class RealTimeAlertMonitorService : BackgroundService
    {
        private readonly ILogger<RealTimeAlertMonitorService> _logger;
        private readonly IServiceProvider _serviceProvider;
        private readonly string _connectionString;
        private readonly TimeSpan _pollingInterval = TimeSpan.FromSeconds(5); // 每5秒檢查一次
        private DateTime _lastCheckTime;

        public RealTimeAlertMonitorService(
            ILogger<RealTimeAlertMonitorService> logger,
            IServiceProvider serviceProvider,
            string connectionString)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
            _connectionString = connectionString;
            _lastCheckTime = DateTime.Now.AddMinutes(-1); // 初始檢查最近1分鐘的告警
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("即時告警監控服務已啟動，於 {Time}", DateTimeOffset.Now);

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    await CheckForNewAlerts(stoppingToken);
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "檢查新告警時發生錯誤");
                }

                await Task.Delay(_pollingInterval, stoppingToken);
            }
        }

        private async Task CheckForNewAlerts(CancellationToken stoppingToken)
        {
            var currentTime = DateTime.Now;
            var newOrUpdatedAlerts = new List<RealTimeAlert>();

            // 使用 Scope 來解決 Scoped 服務在 Singleton 服務中的注入問題
            using (var scope = _serviceProvider.CreateScope())
            {
                var realTimeAlertService = scope.ServiceProvider.GetRequiredService<IRealTimeAlertService>();

                using (var connection = new SqlConnection(_connectionString))
                {
                    await connection.OpenAsync(stoppingToken);

                    // 查詢在上次檢查後新增或更新的告警
                    using (var command = connection.CreateCommand())
                    {
                        command.CommandText = @"
                            SELECT 
                                [IsDisable], [Ack], [Finish], [DataTime], [DeviceID], 
                                [Descript], [CurrValue], [AlertValue], [AlertLimit], 
                                [AlertPriority], [AlertType], [AlertGroup], [AlertLocked], 
                                [AlertDescript], [UserName], [UserIP], [ToMvid], 
                                [VisibleGroup], [BimObjectID]
                            FROM 
                                [SunforceAlert].[dbo].[AlertRealTime] 
                            WHERE 
                                [DataTime] > @LastCheckTime
                            ORDER BY 
                                [DataTime] DESC";

                        command.Parameters.Add(new SqlParameter("@LastCheckTime", SqlDbType.DateTime) { Value = _lastCheckTime });

                        using (var reader = await command.ExecuteReaderAsync(stoppingToken))
                        {
                            while (await reader.ReadAsync(stoppingToken))
                            {
                                // 建立告警物件
                                var alert = MapToRealTimeAlert(reader);
                                newOrUpdatedAlerts.Add(alert);

                                // 處理告警類型
                                bool isNewCriticalAlert = alert.Finish == 0 && alert.Ack == 0;

                                // 全局告警通知（會觸發聲音）僅限於新的未確認告警
                                if (isNewCriticalAlert)
                                {
                                    await realTimeAlertService.SendGlobalAlertAsync(alert);
                                    _logger.LogInformation(
                                        "發送全局告警: DeviceID={DeviceID}, DataTime={DataTime}, AlertType={AlertType}",
                                        alert.DeviceID,
                                        alert.DataTime,
                                        alert.AlertType);
                                }

                                // 告警頁面更新（不論什麼類型的告警變更都要推送）
                                await realTimeAlertService.SendAlertPageUpdateAsync(alert);
                                _logger.LogDebug(
                                    "發送告警頁面更新: DeviceID={DeviceID}, DataTime={DataTime}, Type={Type}",
                                    alert.DeviceID,
                                    alert.DataTime,
                                    alert.AlertType);
                            }
                        }
                    }
                }

                // 如果有多個新告警，同時發送批量更新
                if (newOrUpdatedAlerts.Count > 1)
                {
                    await realTimeAlertService.SendBatchAlertUpdatesAsync(newOrUpdatedAlerts);
                    _logger.LogInformation("發送批量告警更新，共 {Count} 條", newOrUpdatedAlerts.Count);
                }
            }

            // 更新最後檢查時間
            _lastCheckTime = currentTime;
        }

        /// <summary>
        /// 將 SqlDataReader 轉換為 RealTimeAlert 實體
        /// </summary>
        private RealTimeAlert MapToRealTimeAlert(SqlDataReader reader)
        {
            // 檢查 DataTime 欄位的實際類型
            int dataTimeOrdinal = reader.GetOrdinal("DataTime");
            string dataTimeValue;

            // 根據數據庫欄位的實際類型選擇適當的方法來獲取值
            if (reader.GetFieldType(dataTimeOrdinal) == typeof(DateTime))
            {
                // 如果是 DateTime 類型，轉換為字符串
                dataTimeValue = reader.GetDateTime(dataTimeOrdinal).ToString("yyyy-MM-dd HH:mm:ss");
            }
            else
            {
                // 如果已經是字符串類型，直接獲取
                dataTimeValue = reader.GetString(dataTimeOrdinal);
            }

            return new RealTimeAlert
            {
                IsDisable = reader.GetInt32(reader.GetOrdinal("IsDisable")),
                Ack = reader.GetInt32(reader.GetOrdinal("Ack")),
                Finish = reader.GetInt32(reader.GetOrdinal("Finish")),
                DataTime = dataTimeValue,
                DeviceID = reader.GetString(reader.GetOrdinal("DeviceID")),
                Descript = reader.GetString(reader.GetOrdinal("Descript")),
                CurrValue = reader.GetString(reader.GetOrdinal("CurrValue")),
                AlertValue = reader.GetString(reader.GetOrdinal("AlertValue")),
                AlertLimit = reader.GetString(reader.GetOrdinal("AlertLimit")),
                AlertPriority = reader.IsDBNull(reader.GetOrdinal("AlertPriority")) ? null : reader.GetString(reader.GetOrdinal("AlertPriority")),
                AlertType = reader.GetString(reader.GetOrdinal("AlertType")),
                AlertGroup = reader.IsDBNull(reader.GetOrdinal("AlertGroup")) ? null : reader.GetString(reader.GetOrdinal("AlertGroup")),
                AlertLocked = reader.GetInt32(reader.GetOrdinal("AlertLocked")),
                AlertDescript = reader.IsDBNull(reader.GetOrdinal("AlertDescript")) ? null : reader.GetString(reader.GetOrdinal("AlertDescript")),
                UserName = reader.IsDBNull(reader.GetOrdinal("UserName")) ? null : reader.GetString(reader.GetOrdinal("UserName")),
                UserIP = reader.IsDBNull(reader.GetOrdinal("UserIP")) ? null : reader.GetString(reader.GetOrdinal("UserIP")),
                ToMvid = reader.GetInt32(reader.GetOrdinal("ToMvid")),
                VisibleGroup = reader.IsDBNull(reader.GetOrdinal("VisibleGroup")) ? null : reader.GetString(reader.GetOrdinal("VisibleGroup")),
                BimObjectID = reader.IsDBNull(reader.GetOrdinal("BimObjectID")) ? null : reader.GetString(reader.GetOrdinal("BimObjectID"))
            };
        }
    }

    /// <summary>
    /// 用於註冊即時告警監控服務的擴展方法
    /// </summary>
    public static class RealTimeAlertMonitorServiceExtensions
    {
        public static IServiceCollection AddRealTimeAlertMonitorService(this IServiceCollection services, string connectionString)
        {
            return services.AddHostedService(provider =>
                new RealTimeAlertMonitorService(
                    provider.GetRequiredService<ILogger<RealTimeAlertMonitorService>>(),
                    provider,
                    connectionString
                )
            );
        }
    }
}