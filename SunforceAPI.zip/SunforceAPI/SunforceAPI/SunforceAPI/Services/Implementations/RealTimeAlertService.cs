﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using SunforceAPI.Hubs;
using SunforceAPI.Models;
using SunforceAPI.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SunforceAPI.Services.Implementations
{
    /// <summary>
    /// 即時告警服務實現類
    /// 通過 SignalR 向客戶端發送即時告警通知
    /// </summary>
    public class RealTimeAlertService : IRealTimeAlertService
    {
        private readonly IHubContext<RealTimeAlertHub> _hubContext;
        private readonly ILogger<RealTimeAlertService> _logger;

        public RealTimeAlertService(
            IHubContext<RealTimeAlertHub> hubContext,
            ILogger<RealTimeAlertService> logger)
        {
            _hubContext = hubContext;
            _logger = logger;
        }

        /// <summary>
        /// 發送全局告警通知
        /// </summary>
        public async Task SendGlobalAlertAsync(RealTimeAlert alert)
        {
            try
            {
                var message = new
                {
                    type = "global",
                    alert = new
                    {
                        dataTime = alert.DataTime,  // 直接使用字符串
                        deviceID = alert.DeviceID,
                        descript = alert.Descript,
                        currValue = alert.CurrValue,
                        alertValue = alert.AlertValue,
                        alertLimit = alert.AlertLimit,
                        alertType = alert.AlertType,
                        alertDescript = alert.AlertDescript,
                        ack = alert.Ack,
                        finish = alert.Finish,
                        userName = alert.UserName ?? "-"
                    },
                    timestamp = DateTime.Now
                };

                await _hubContext.Clients.Group("global").SendAsync("ReceiveAlert", message);
                _logger.LogInformation($"已發送全局告警通知: DeviceID={alert.DeviceID}, DateTime={alert.DataTime}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "發送全局告警通知時發生錯誤");
                throw;
            }
        }

        /// <summary>
        /// 發送告警頁面更新
        /// </summary>
        public async Task SendAlertPageUpdateAsync(RealTimeAlert alert)
        {
            try
            {
                var message = new
                {
                    type = "alertUpdate",
                    alert = new
                    {
                        dataTime = alert.DataTime,  // 直接使用字符串
                        deviceID = alert.DeviceID,
                        descript = alert.Descript,
                        currValue = alert.CurrValue,
                        alertValue = alert.AlertValue,
                        alertLimit = alert.AlertLimit,
                        alertType = alert.AlertType,
                        alertDescript = alert.AlertDescript,
                        ack = alert.Ack,
                        finish = alert.Finish,
                        userName = alert.UserName ?? "-",
                        rowKey = $"{alert.DataTime}-{alert.DeviceID}"
                    },
                    timestamp = DateTime.Now
                };

                await _hubContext.Clients.Group("alertPage").SendAsync("ReceiveAlert", message);
                _logger.LogInformation($"已發送告警頁面更新: DeviceID={alert.DeviceID}, DateTime={alert.DataTime}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "發送告警頁面更新時發生錯誤");
                throw;
            }
        }

        /// <summary>
        /// 發送批量告警更新
        /// </summary>
        public async Task SendBatchAlertUpdatesAsync(IEnumerable<RealTimeAlert> alerts)
        {
            try
            {
                var alertList = new List<object>();
                foreach (var alert in alerts)
                {
                    alertList.Add(new
                    {
                        dataTime = alert.DataTime,  // 直接使用字符串
                        deviceID = alert.DeviceID,
                        descript = alert.Descript,
                        currValue = alert.CurrValue,
                        alertValue = alert.AlertValue,
                        alertLimit = alert.AlertLimit,
                        alertType = alert.AlertType,
                        alertDescript = alert.AlertDescript,
                        ack = alert.Ack,
                        finish = alert.Finish,
                        userName = alert.UserName ?? "-",
                        rowKey = $"{alert.DataTime}-{alert.DeviceID}"
                    });
                }

                var message = new
                {
                    type = "batchUpdate",
                    alerts = alertList,
                    timestamp = DateTime.Now
                };

                await _hubContext.Clients.Group("alertPage").SendAsync("ReceiveBatchAlerts", message);
                _logger.LogInformation("已發送批量告警更新，共 {Count} 條", alertList.Count);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "發送批量告警更新時發生錯誤");
                throw;
            }
        }

        /// <summary>
        /// 發送告警確認通知
        /// </summary>
        public async Task SendAlertAcknowledgedAsync(string dateTime, string deviceId, string userName)
        {
            try
            {
                var message = new
                {
                    type = "acknowledge",
                    dateTime = dateTime,  // 直接使用字符串
                    deviceId = deviceId,
                    rowKey = $"{dateTime}-{deviceId}",
                    userName = userName,
                    timestamp = DateTime.Now
                };

                // 發送給所有客戶端
                await _hubContext.Clients.All.SendAsync("ReceiveAlertAcknowledged", message);
                _logger.LogInformation($"已發送告警確認通知: DeviceID={deviceId}, DateTime={dateTime}, User={userName}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"發送告警確認通知時發生錯誤: DeviceID={deviceId}, DateTime={dateTime}");
                throw;
            }
        }
    }
}