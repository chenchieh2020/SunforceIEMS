﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SunforceAPI.Data;
using SunforceAPI.DTOs;
using SunforceAPI.Models;
using SunforceAPI.Services.Interfaces;
namespace SunforceAPI.Services.Implementations
{
    public class AlertService : IAlertService
    {
        private readonly ApplicationDbContext _context;
        private readonly IMapper _mapper;
        public AlertService(ApplicationDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        public async Task<PaginatedResult<AlertDto>> GetAlertsAsync(AlertQueryParams queryParams)
        {
            var query = _context.Alerts.AsQueryable();

            // 應用過濾條件
            if (queryParams.StartDate.HasValue)
            {
                string startDateStr = queryParams.StartDate.Value.ToString("yyyy/MM/dd");
                // 對於字符串日期比較，使用 StartsWith 或 CompareTo
                query = query.Where(a => a.DateTime.CompareTo(startDateStr) >= 0);
            }

            if (queryParams.EndDate.HasValue)
            {
                // 設為當天最後一秒 (23:59:59)
                var endDate = queryParams.EndDate.Value.AddDays(1);
                string endDateStr = endDate.ToString("yyyy/MM/dd");
                query = query.Where(a => a.DateTime.CompareTo(endDateStr) < 0);
            }

            // 關鍵字搜尋
            if (!string.IsNullOrEmpty(queryParams.Keyword))
            {
                query = query.Where(a =>
                    a.DeviceId.Contains(queryParams.Keyword) ||
                    a.Descript.Contains(queryParams.Keyword) ||
                    a.AlertType.Contains(queryParams.Keyword) ||
                    a.AlertValue.Contains(queryParams.Keyword) ||
                    a.AlertLimit.Contains(queryParams.Keyword) ||
                    a.AlertDescript.Contains(queryParams.Keyword));
            }

            // 始終按日期降序排序（最新的在前面）
            query = query.OrderByDescending(a => a.DateTime);

            // 判斷是否為初次載入，沒有任何過濾條件
            int totalItems;
            List<Alert> items;

            var isInitialLoad = !queryParams.StartDate.HasValue &&
                                !queryParams.EndDate.HasValue &&
                                string.IsNullOrEmpty(queryParams.Keyword);

            if (isInitialLoad && queryParams.DefaultRecordLimit.HasValue)
            {
                // 使用原始SQL查詢提高性能，只獲取最新的N筆記錄
                var topN = queryParams.DefaultRecordLimit.Value;

                // 獲取最新的N筆記錄總數
                var sqlCount = $"SELECT TOP {topN} * FROM AlertRaw ORDER BY DataTime DESC";
                var tempItems = await _context.Alerts.FromSqlRaw(sqlCount).ToListAsync();
                totalItems = tempItems.Count;

                // 分頁
                int skip = (queryParams.PageNumber - 1) * queryParams.PageSize;
                int take = queryParams.PageSize;

                if (skip < totalItems)
                {
                    items = tempItems
                        .Skip(skip)
                        .Take(Math.Min(take, totalItems - skip))
                        .ToList();
                }
                else
                {
                    items = new List<Alert>();
                }
            }
            else
            {
                // 如果有過濾條件，獲取所有符合條件的記錄總數
                totalItems = await query.CountAsync();

                // 分頁
                items = await query
                    .Skip((queryParams.PageNumber - 1) * queryParams.PageSize)
                    .Take(queryParams.PageSize)
                    .ToListAsync();
            }

            // 映射到DTO
            var alertDtos = _mapper.Map<List<AlertDto>>(items);

            // 創建分頁結果
            return new PaginatedResult<AlertDto>
            {
                Items = alertDtos,
                TotalCount = totalItems,
                PageNumber = queryParams.PageNumber,
                PageSize = queryParams.PageSize
            };
        }

        public async Task<AlertDto> GetAlertByDetailAsync(string dataTime, string deviceID)
        {
            // 直接使用字串比較
            var alert = await _context.Alerts
                .FirstOrDefaultAsync(a => a.DateTime == dataTime && a.DeviceId == deviceID);

            if (alert == null)
                return null;

            return _mapper.Map<AlertDto>(alert);
        }

        public async Task<IEnumerable<AlertDto>> GetAllAlertsForExportAsync(AlertQueryParams queryParams)
        {
            // 使用與獲取分頁數據相同的過濾邏輯，但不分頁，返回所有結果
            var query = _context.Alerts.AsQueryable();

            // 應用過濾條件，與 GetAlertsAsync 保持一致
            if (queryParams.StartDate.HasValue)
            {
                string startDateStr = queryParams.StartDate.Value.ToString("yyyy/MM/dd");
                // 對於字符串日期比較，使用 CompareTo
                query = query.Where(a => a.DateTime.CompareTo(startDateStr) >= 0);
            }

            if (queryParams.EndDate.HasValue)
            {
                // 設為當天最後一秒 (23:59:59)
                var endDate = queryParams.EndDate.Value.AddDays(1);
                string endDateStr = endDate.ToString("yyyy/MM/dd");
                query = query.Where(a => a.DateTime.CompareTo(endDateStr) < 0);
            }

            if (!string.IsNullOrEmpty(queryParams.Keyword))
            {
                query = query.Where(a =>
                    a.DeviceId.Contains(queryParams.Keyword) ||
                    a.Descript.Contains(queryParams.Keyword) ||
                    a.AlertType.Contains(queryParams.Keyword) ||
                    a.AlertValue.Contains(queryParams.Keyword) ||
                    a.AlertLimit.Contains(queryParams.Keyword) ||
                    a.AlertDescript.Contains(queryParams.Keyword)
                );
            }

            // 判斷是否為初次載入，沒有任何過濾條件
            var isInitialLoad = !queryParams.StartDate.HasValue &&
                                !queryParams.EndDate.HasValue &&
                                string.IsNullOrEmpty(queryParams.Keyword);

            if (isInitialLoad && queryParams.DefaultRecordLimit.HasValue)
            {
                // 使用原始SQL查詢提高性能，只獲取最新的N筆記錄
                var topN = queryParams.DefaultRecordLimit.Value;
                var sqlCount = $"SELECT TOP {topN} * FROM AlertRaw ORDER BY DataTime DESC";
                var alerts = await _context.Alerts.FromSqlRaw(sqlCount).ToListAsync();

                // 轉換為DTO
                return _mapper.Map<IEnumerable<AlertDto>>(alerts);
            }
            else
            {
                // 如果有過濾條件，使用一般查詢
                query = query.OrderByDescending(a => a.DateTime);
                var alerts = await query.ToListAsync();

                // 轉換為DTO
                return _mapper.Map<IEnumerable<AlertDto>>(alerts);
            }
        }
    }
}
