﻿using AutoMapper;
using Microsoft.EntityFrameworkCore;
using SunforceAPI.Data;
using SunforceAPI.DTOs;
using SunforceAPI.Models;
using SunforceAPI.Services.Interfaces;
namespace SunforceAPI.Services.Implementations
{
    public class HisDayService
    {
        private readonly HisDbContext _context;
        private readonly IMapper _mapper;

        public HisDayService(HisDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<IEnumerable<HisDayDto>> GetAllAsync()
        {
            var data = await _context.HisDays.ToListAsync();
            return _mapper.Map<List<HisDayDto>>(data);
        }

        public async Task AddAsync(HisDayDto dto)
        {
            var entity = _mapper.Map<HisDay>(dto);
            _context.HisDays.Add(entity);
            await _context.SaveChangesAsync();
        }
    }

}