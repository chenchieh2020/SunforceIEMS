﻿using SunforceAPI.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace SunforceAPI.Services.Interfaces
{
    /// 即時告警服務介面
    /// 定義即時告警通知相關的方法
    public interface IRealTimeAlertService
    {
        /// 發送全局告警通知
        /// 用於向所有連接的客戶端發送告警通知 (包括聲音提示)
        /// <param name="alert">告警資訊</param>
        Task SendGlobalAlertAsync(RealTimeAlert alert);

        /// 發送告警頁面更新
        /// 用於只更新告警頁面的數據，不觸發聲音提示
        /// <param name="alert">告警資訊</param>
        Task SendAlertPageUpdateAsync(RealTimeAlert alert);

        /// 發送批量告警更新
        /// 用於一次性發送多個告警資訊，通常用於初始化或大量數據變更
        /// </summary>
        /// <param name="alerts">告警資訊集合</param>
        Task SendBatchAlertUpdatesAsync(IEnumerable<RealTimeAlert> alerts);

        /// 發送告警確認通知
        /// 當告警被確認時觸發此方法
        /// </summary>
        /// <param name="dateTime">告警時間 (字符串)</param>
        /// <param name="deviceId">設備ID</param>
        /// <param name="userName">確認用戶名</param>
        Task SendAlertAcknowledgedAsync(string dateTime, string deviceId, string userName);
    }
}