﻿using SunforceAPI.DTOs;
using SunforceAPI.Models;
namespace SunforceAPI.Services.Interfaces
{
    public interface IAlertService
    {
        Task<PaginatedResult<AlertDto>> GetAlertsAsync(AlertQueryParams queryParams);
        Task<AlertDto> GetAlertByDetailAsync(string dataTime, string deviceID);
        Task<IEnumerable<AlertDto>> GetAllAlertsForExportAsync(AlertQueryParams queryParams);
    }
}