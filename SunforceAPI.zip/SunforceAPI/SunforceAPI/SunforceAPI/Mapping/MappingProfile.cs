﻿using AutoMapper;
using SunforceAPI.DTOs;
using SunforceAPI.Models;

namespace SunforceAPI.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<Alert, AlertDto>()
                .ForMember(dest => dest.DataTime, opt => opt.MapFrom(src => src.DateTime))
                .ForMember(dest => dest.DeviceID, opt => opt.MapFrom(src => src.DeviceId))
                .ForMember(dest => dest.Descript, opt => opt.MapFrom(src => src.Descript))
                .ForMember(dest => dest.AlertValue, opt => opt.MapFrom(src => src.AlertValue))
                .ForMember(dest => dest.AlertLimit, opt => opt.MapFrom(src => src.AlertLimit))
                .ForMember(dest => dest.AlertType, opt => opt.MapFrom(src => src.AlertType))
                .ForMember(dest => dest.AlertDescript, opt => opt.MapFrom(src => src.AlertDescript));

            CreateMap<RealTimeAlert, RealTimeAlertDto>()
                .ForMember(dest => dest.DataTime, opt => opt.MapFrom(src => src.DataTime)) // 直接映射，兩者都是字符串
                .ForMember(dest => dest.DeviceID, opt => opt.MapFrom(src => src.DeviceID))
                .ForMember(dest => dest.Descript, opt => opt.MapFrom(src => src.Descript))
                .ForMember(dest => dest.Ack, opt => opt.MapFrom(src => src.Ack))
                .ForMember(dest => dest.Finish, opt => opt.MapFrom(src => src.Finish))
                .ForMember(dest => dest.UserName, opt => opt.MapFrom(src => string.IsNullOrEmpty(src.UserName) ? "-" : src.UserName))
                .ForMember(dest => dest.CurrValue, opt => opt.MapFrom(src => src.CurrValue))
                .ForMember(dest => dest.AlertValue, opt => opt.MapFrom(src => src.AlertValue))
                .ForMember(dest => dest.AlertLimit, opt => opt.MapFrom(src => src.AlertLimit))
                .ForMember(dest => dest.AlertType, opt => opt.MapFrom(src => src.AlertType))
                .ForMember(dest => dest.AlertDescript, opt => opt.MapFrom(src => src.AlertDescript))
                .ForMember(dest => dest.Selected, opt => opt.Ignore());

            // HisDay / HisMonth（雙向）
            CreateMap<HisDay, HisDayDto>().ReverseMap();
            CreateMap<HisMonth, HisMonthDto>().ReverseMap();
        }
    }
}