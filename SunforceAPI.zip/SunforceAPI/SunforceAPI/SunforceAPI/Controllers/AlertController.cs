﻿using Microsoft.AspNetCore.Mvc;
using SunforceAPI.DTOs;
using SunforceAPI.Services.Interfaces;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using System.IO;
using Microsoft.EntityFrameworkCore;
using SunforceAPI.Models;

namespace SunforceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlertController : ControllerBase
    {
        private readonly IAlertService _alertService;
        private readonly ILogger<AlertController> _logger;
        public AlertController(IAlertService alertService, ILogger<AlertController> logger)
        {
            _alertService = alertService;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<PaginatedResult<AlertDto>>> GetAlerts([FromQuery] AlertQueryParams queryParams)
        {
            try
            {
                // 如果沒有指定過濾條件，則默認獲取最新200條
                if (!queryParams.StartDate.HasValue &&
                    !queryParams.EndDate.HasValue &&
                    string.IsNullOrEmpty(queryParams.Keyword))
                {
                    queryParams.DefaultRecordLimit = 200;
                }

                var result = await _alertService.GetAlertsAsync(queryParams);
                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "獲取告警數據時發生錯誤");
                return StatusCode(500, $"內部伺服器錯誤: {ex.Message}");
            }
        }

        [HttpGet("detail")]
        public async Task<ActionResult<AlertDto>> GetAlertByDetail([FromQuery] string dataTime, [FromQuery] string deviceID)
        {
            try
            {
                var alert = await _alertService.GetAlertByDetailAsync(dataTime, deviceID);
                if (alert == null)
                {
                    return NotFound("找不到指定時間和設備ID的告警記錄");
                }
                return Ok(alert);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"獲取時間為{dataTime}設備ID為{deviceID}的告警記錄時發生錯誤");
                return StatusCode(500, $"內部伺服器錯誤: {ex.Message}");
            }
        }

        [HttpGet("export")]
        public async Task<IActionResult> ExportToExcel([FromQuery] AlertQueryParams queryParams)
        {
            try
            {
                // 如果沒有指定過濾條件，則默認獲取最新200條
                if (!queryParams.StartDate.HasValue &&
                    !queryParams.EndDate.HasValue &&
                    string.IsNullOrEmpty(queryParams.Keyword))
                {
                    queryParams.DefaultRecordLimit = 200;
                }

                // 使用 Service 獲取資料
                var alerts = await _alertService.GetAllAlertsForExportAsync(queryParams);

                try
                {
                    // 創建 Excel 工作簿
                    using var workbook = new XSSFWorkbook();
                    var sheet = workbook.CreateSheet("告警記錄");

                    // 創建標題行
                    var headerRow = sheet.CreateRow(0);
                    headerRow.CreateCell(0).SetCellValue("時間");
                    headerRow.CreateCell(1).SetCellValue("設備ID");
                    headerRow.CreateCell(2).SetCellValue("設備描述");
                    headerRow.CreateCell(3).SetCellValue("告警值");
                    headerRow.CreateCell(4).SetCellValue("告警限制");
                    headerRow.CreateCell(5).SetCellValue("告警類型");
                    headerRow.CreateCell(6).SetCellValue("告警描述");

                    // 添加數據行
                    int rowIndex = 1;
                    foreach (var alert in alerts)
                    {
                        var row = sheet.CreateRow(rowIndex++);
                        row.CreateCell(0).SetCellValue(alert.DataTime);
                        row.CreateCell(1).SetCellValue(alert.DeviceID);
                        row.CreateCell(2).SetCellValue(alert.Descript);
                        row.CreateCell(3).SetCellValue(alert.AlertValue);
                        row.CreateCell(4).SetCellValue(alert.AlertLimit);
                        row.CreateCell(5).SetCellValue(alert.AlertType);
                        row.CreateCell(6).SetCellValue(alert.AlertDescript);
                    }

                    // 調整列寬
                    for (int i = 0; i < 7; i++)
                    {
                        sheet.AutoSizeColumn(i);
                    }

                    // 將工作簿轉換為 byte array
                    using var ms = new MemoryStream();
                    workbook.Write(ms);

                    // 返回檔案
                    return File(
                        ms.ToArray(),
                        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        "alerts.xlsx"
                    );
                }
                catch (Exception ex)
                {
                    // 捕獲並記錄 Excel 創建過程中的錯誤
                    _logger.LogError(ex, "創建 Excel 檔案時發生錯誤");
                    return StatusCode(500, $"創建 Excel 檔案時發生錯誤: {ex.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "匯出告警數據時發生錯誤");
                return StatusCode(500, $"內部伺服器錯誤: {ex.Message}");
            }
        }
    }
}