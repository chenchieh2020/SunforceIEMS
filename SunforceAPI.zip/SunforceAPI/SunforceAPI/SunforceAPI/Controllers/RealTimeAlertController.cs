﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SunforceAPI.Data;
using SunforceAPI.DTOs;
using SunforceAPI.Models;
using SunforceAPI.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace SunforceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RealTimeAlertController : ControllerBase
    {
        private readonly ILogger<RealTimeAlertController> _logger;
        private readonly ApplicationDbContext _dbContext;
        private readonly IRealTimeAlertService _realTimeAlertService;
        private readonly IMapper _mapper;

        public RealTimeAlertController(
            ILogger<RealTimeAlertController> logger,
            ApplicationDbContext dbContext,
            IRealTimeAlertService realTimeAlertService,
            IMapper mapper)
        {
            _logger = logger;
            _dbContext = dbContext;
            _realTimeAlertService = realTimeAlertService;
            _mapper = mapper;
        }

        /// <summary>
        /// 獲取即時告警列表
        /// </summary>
        [HttpGet]
        public async Task<IActionResult> GetRealTimeAlerts([FromQuery] int pageNumber = 1, [FromQuery] int pageSize = 20)
        {
            try
            {
                _logger.LogInformation("開始獲取即時告警列表，頁碼：{PageNumber}，每頁大小：{PageSize}", pageNumber, pageSize);

                // 檢查數據庫連接
                if (_dbContext.Database.CanConnect() == false)
                {
                    _logger.LogError("數據庫連接失敗");
                    return StatusCode(500, "數據庫連接失敗，請檢查數據庫設置");
                }

                // 獲取告警總數（排除已確認且已復歸的告警）
                var totalCount = 0;
                var alerts = new List<RealTimeAlert>();

                try
                {
                    // 按照規則過濾告警：排除 Finish=1 且 Ack=1 的告警
                    var query = _dbContext.RealTimeAlerts
                        .Where(a => !(a.Finish == 1 && a.Ack == 1));

                    totalCount = await query.CountAsync();

                    _logger.LogInformation("獲取到符合條件的告警數量：{TotalCount}", totalCount);

                    // 獲取分頁數據，按時間降序排序
                    alerts = await query
                        .OrderByDescending(a => a.DataTime)  // 字符串排序，可能不是最準確的，但可用
                        .Skip((pageNumber - 1) * pageSize)
                        .Take(pageSize)
                        .ToListAsync();

                    _logger.LogInformation("成功獲取當前頁面的告警數據，條數：{Count}", alerts.Count);
                }
                catch (Exception dbEx)
                {
                    _logger.LogError(dbEx, "數據庫查詢出錯: {Message}", dbEx.Message);
                    return StatusCode(500, $"數據庫查詢錯誤: {dbEx.Message}");
                }

                try
                {
                    // 映射到 DTO
                    var alertDtos = _mapper.Map<List<RealTimeAlertDto>>(alerts);
                    _logger.LogInformation("數據映射完成，返回告警列表");

                    return Ok(new
                    {
                        items = alertDtos,
                        totalCount = totalCount,
                        pageNumber = pageNumber,
                        pageSize = pageSize
                    });
                }
                catch (Exception mapperEx)
                {
                    _logger.LogError(mapperEx, "數據映射出錯: {Message}", mapperEx.Message);
                    return StatusCode(500, $"數據映射錯誤: {mapperEx.Message}");
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "獲取即時告警列表時發生錯誤: {Message}", ex.Message);
                return StatusCode(500, $"獲取告警資料時發生錯誤: {ex.Message}");
            }
        }

        /// <summary>
        /// 確認所有告警
        /// </summary>
        [HttpPost("acknowledgeAll")]
        public async Task<IActionResult> AcknowledgeAll()
        {
            try
            {
                string userName = User.Identity?.Name ?? "系統用戶";
                string userIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "0.0.0.0";

                _logger.LogInformation("開始確認所有告警，用戶：{UserName}，IP：{UserIp}", userName, userIp);

                // 獲取所有未確認的告警
                var alerts = await _dbContext.RealTimeAlerts
                    .Where(a => a.Ack == 0)
                    .ToListAsync();

                int acknowledgedCount = 0;

                // 確認每個告警
                foreach (var alert in alerts)
                {
                    alert.Ack = 1;
                    alert.UserName = userName;
                    alert.UserIP = userIp;
                    acknowledgedCount++;

                    // 發送告警確認通知
                    await _realTimeAlertService.SendAlertAcknowledgedAsync(
                        alert.DataTime,
                        alert.DeviceID,
                        userName);
                }

                // 保存更改
                await _dbContext.SaveChangesAsync();

                return Ok(new
                {
                    success = true,
                    message = $"已確認 {acknowledgedCount} 個告警",
                    acknowledgedCount = acknowledgedCount
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "確認所有告警時發生錯誤");
                return StatusCode(500, new { success = false, message = "確認告警時發生錯誤" });
            }
        }

        /// <summary>
        /// 確認選擇的告警
        /// </summary>
        [HttpPost("acknowledgeSelected")]
        public async Task<IActionResult> AcknowledgeSelected([FromBody] List<AlertKeyDto> alertKeys)
        {
            if (alertKeys == null || !alertKeys.Any())
            {
                return BadRequest(new { success = false, message = "未選擇任何告警" });
            }

            try
            {
                string userName = User.Identity?.Name ?? "系統用戶";
                string userIp = HttpContext.Connection.RemoteIpAddress?.ToString() ?? "0.0.0.0";

                int acknowledgedCount = 0;

                foreach (var key in alertKeys)
                {
                    // 查找告警 - 使用字符串比較
                    var alert = await _dbContext.RealTimeAlerts
                        .FirstOrDefaultAsync(a => a.DataTime == key.DataTime &&
                                               a.DeviceID == key.DeviceID &&
                                               a.Ack == 0);

                    if (alert != null)
                    {
                        // 確認告警
                        alert.Ack = 1;
                        alert.UserName = userName;
                        alert.UserIP = userIp;
                        acknowledgedCount++;

                        // 發送告警確認通知
                        await _realTimeAlertService.SendAlertAcknowledgedAsync(
                            alert.DataTime,
                            alert.DeviceID,
                            userName);
                    }
                }

                // 保存更改
                await _dbContext.SaveChangesAsync();

                return Ok(new
                {
                    success = true,
                    message = $"已確認 {acknowledgedCount} 個告警",
                    acknowledgedCount = acknowledgedCount
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "確認選擇告警時發生錯誤");
                return StatusCode(500, new { success = false, message = "確認告警時發生錯誤" });
            }
        }
    }
}