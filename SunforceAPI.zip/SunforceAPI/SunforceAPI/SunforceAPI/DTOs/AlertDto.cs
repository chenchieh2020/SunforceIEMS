﻿namespace SunforceAPI.DTOs
{
    public class AlertDto
    {

        public string DataTime { get; set; }
        public string DeviceID { get; set; }
        public string Descript { get; set; }
        public string AlertValue { get; set; }
        public string AlertLimit { get; set; }
        public string AlertType { get; set; }
        public string AlertDescript { get; set; }
    }
}