﻿using SunforceAPI.Models;
using System;

namespace SunforceAPI.DTOs
{
    /// 實時告警資料傳輸物件 (DTO)
    /// 僅包含前端顯示所需的欄位
    public class RealTimeAlertDto
    {
        /// 是否被選中 (前端勾選框使用，不是資料庫欄位)
        public bool Selected { get; set; } = false;

        /// 確認狀態 (0=未確認, 1=已確認)
        public int Ack { get; set; }

        /// 告警狀態 (0=告警中, 1=已復歸)，用於前端顯示邏輯但不顯示
        public int Finish { get; set; }

        /// 確認者身分
        public string UserName { get; set; }

        /// 告警發生時間 (已是字符串格式)
        public string DataTime { get; set; }

        /// 設備/點位ID
        public string DeviceID { get; set; }

        /// 設備/點位描述
        public string Descript { get; set; }

        /// 當前值
        public string CurrValue { get; set; }

        /// 告警值
        public string AlertValue { get; set; }

        /// 告警限制值
        public string AlertLimit { get; set; }

        /// 告警類型
        public string AlertType { get; set; }

        /// 告警描述
        public string AlertDescript { get; set; }

        /// 為前端表格行顯示生成一個唯一鍵 (使用時間+設備ID作為複合鍵)
        public string RowKey => $"{DataTime}-{DeviceID}";

        /// 從資料庫實體轉換為DTO
        /// <param name="entity">資料庫實體</param>
        /// <returns>DTO物件</returns>
        public static RealTimeAlertDto FromEntity(RealTimeAlert entity)
        {
            if (entity == null)
                return null;

            return new RealTimeAlertDto
            {
                Ack = entity.Ack,
                Finish = entity.Finish,
                UserName = string.IsNullOrEmpty(entity.UserName) ? "-" : entity.UserName,
                DataTime = entity.DataTime,  // 直接使用，已是字符串
                DeviceID = entity.DeviceID,
                Descript = entity.Descript,
                CurrValue = entity.CurrValue,
                AlertValue = entity.AlertValue,
                AlertLimit = entity.AlertLimit,
                AlertType = entity.AlertType,
                AlertDescript = entity.AlertDescript
            };
        }
    }
}