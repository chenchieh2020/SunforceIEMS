namespace SunforceAPI.DTOs
{
    public class HisMonthDto
    {
        public string DataTime { get; set; } = string.Empty;

        public string DeviceID { get; set; } = string.Empty;

        public decimal MinValue { get; set; }

        public decimal MaxValue { get; set; }

        public decimal MidValue { get; set; }

        public decimal AvgValue { get; set; }

        public decimal LastValue { get; set; }
    }
}
