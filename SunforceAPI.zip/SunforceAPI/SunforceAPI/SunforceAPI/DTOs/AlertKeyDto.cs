﻿using System;

namespace SunforceAPI.DTOs
{
    /// <summary>
    /// 用於前端傳遞告警鍵的DTO
    /// </summary>
    public class AlertKeyDto
    {
        /// <summary>
        /// 告警時間 (格式: yyyy-MM-dd HH:mm:ss)
        /// </summary>
        public string DataTime { get; set; }

        /// <summary>
        /// 設備ID
        /// </summary>
        public string DeviceID { get; set; }
    }
}