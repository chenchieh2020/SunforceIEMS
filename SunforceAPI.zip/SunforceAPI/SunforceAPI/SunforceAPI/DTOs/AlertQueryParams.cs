﻿namespace SunforceAPI.DTOs
{
    public class AlertQueryParams
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? Keyword { get; set; }
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20; // 默認每頁20條
        public int? DefaultRecordLimit { get; set; } // 用於首次載入限制記錄數
    }
}