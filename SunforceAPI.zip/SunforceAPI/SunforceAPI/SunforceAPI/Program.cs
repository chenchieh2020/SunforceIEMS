using Microsoft.EntityFrameworkCore;
using SunforceAPI.Data;
using SunforceAPI.Services.Interfaces;
using SunforceAPI.Services.Implementations;
using AutoMapper;
using SunforceAPI.Mapping;
using SunforceAPI.Hubs;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// �K�[�A�Ȩ�e��
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
        options.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ���~���� - �W�[��x�ŧO�H�����h�H��
builder.Services.AddLogging(logging =>
{
    logging.AddConsole();
    logging.AddDebug();
    logging.SetMinimumLevel(LogLevel.Debug);
    logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", LogLevel.Information);
});
Console.WriteLine("�ϥγs�u�r��: " + builder.Configuration.GetConnectionString("DefaultConnection"));

// ���U DbContext
builder.Services.AddDbContext<ApplicationDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"),
        sqlServerOptionsAction: sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(30),
                errorNumbersToAdd: null);
            sqlOptions.CommandTimeout(60); // �W�[�R�O�W�ɮɶ�
        });

    // �b�}�o���Ҥ��ҥθԲӤ�x
    if (builder.Environment.IsDevelopment())
    {
        options.EnableSensitiveDataLogging();
        options.EnableDetailedErrors();
    }
});

// ���U SunforceHisDbContext
builder.Services.AddDbContext<HisDbContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("SunforceHisConnection"),
        sqlServerOptionsAction: sqlOptions =>
        {
            sqlOptions.EnableRetryOnFailure(
                maxRetryCount: 5,
                maxRetryDelay: TimeSpan.FromSeconds(30),
                errorNumbersToAdd: null);
            sqlOptions.CommandTimeout(60); // �P�˳]�w�W�ɮɶ�
        });

    if (builder.Environment.IsDevelopment())
    {
        options.EnableSensitiveDataLogging();
        options.EnableDetailedErrors();
    }
});

// ���U AutoMapper
builder.Services.AddSingleton(provider => {
    var config = new MapperConfiguration(cfg => {
        cfg.AddProfile<MappingProfile>();
    });
    return config.CreateMapper();
});

// ���U�즳�A��
builder.Services.AddScoped<IAlertService, AlertService>();

// ���U�Y�ɧiĵ�����A��
builder.Services.AddScoped<IRealTimeAlertService, RealTimeAlertService>();

// ���U SignalR
builder.Services.AddSignalR(options =>
{
    options.EnableDetailedErrors = true;
    options.MaximumReceiveMessageSize = 102400; // 100 KB
    options.ClientTimeoutInterval = TimeSpan.FromSeconds(30);
    options.KeepAliveInterval = TimeSpan.FromSeconds(15);
});

// ���U�Y�ɧiĵ�ʱ��A��
builder.Services.AddRealTimeAlertMonitorService(
    builder.Configuration.GetConnectionString("DefaultConnection"));

// �K�[ CORS �F��
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowSpecificOrigins",
        policy =>
        {
            policy.WithOrigins("http://localhost:9000")  // �e�ݪ����}
                  .AllowAnyHeader()
                  .AllowAnyMethod()
                  .AllowCredentials(); // ���\���ҡASignalR �ݭn
        });
});

using (var scope = builder.Services.BuildServiceProvider().CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    Console.WriteLine("�ϥγs�u�r��: " + builder.Configuration.GetConnectionString("DefaultConnection"));
    Console.WriteLine("���ճs�u��Ʈw...");
    try
    {
        bool canConnect = db.Database.CanConnect();
        Console.WriteLine("Database CanConnect: " + canConnect);
    }
    catch (Exception ex)
    {
        Console.WriteLine("�s�u���ѡG" + ex.Message);
    }
}


var app = builder.Build();

// �t�m HTTP �ШD�޹D
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// �ҥ� CORS - �T�O�b UseRouting ���e�ϥ�
app.UseCors("AllowSpecificOrigins");

// �ҥ� WebSockets (SignalR �ݭn)
app.UseWebSockets(new WebSocketOptions
{
    KeepAliveInterval = TimeSpan.FromSeconds(120),
    ReceiveBufferSize = 4 * 1024 // 4 KB
});

app.UseRouting(); // �T�O���Ѧb CORS ����K�[
app.UseAuthorization();

// �M�g�������
app.MapControllers();

// �M�g SignalR Hub
app.MapHub<RealTimeAlertHub>("/realTimeAlertHub");

app.Run();