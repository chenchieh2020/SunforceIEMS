﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SunforceAPI.Models
{
    [Table("AlertRaw")]
    public class Alert
    {
        [Key]
        [Column("DataTime")]
        [StringLength(25)]
        public string DateTime { get; set; } // 改為 string 類型，而不是 DateTime 類型

        [Key]
        [Column("DeviceID")]
        [StringLength(80)]
        public string DeviceId { get; set; }

        [StringLength(128)]
        public string Descript { get; set; }

        [StringLength(30)]
        public string AlertValue { get; set; }

        [StringLength(30)]
        public string AlertLimit { get; set; }

        [StringLength(10)]
        public string AlertPriority { get; set; }

        [StringLength(20)]
        public string AlertType { get; set; }

        public string AlertGroup { get; set; }

        public int AlertLocked { get; set; }

        public string AlertDescript { get; set; }

        [StringLength(50)]
        public string UserName { get; set; }

        [StringLength(30)]
        public string UserIP { get; set; }

        [StringLength(50)]
        public string VisibleGroup { get; set; }
    }
}