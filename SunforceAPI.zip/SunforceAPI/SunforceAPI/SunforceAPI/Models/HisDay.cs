using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SunforceAPI.Models
{
    [Table("HisDay")]
    public class HisDay
    {
        [Key]
        [Column("DataTime")]
        [StringLength(14)]
        public string DataTime { get; set; } = string.Empty;

        [Key]
        [Column("DeviceID")]
        [StringLength(80)]
        public string DeviceID { get; set; } = string.Empty;

        [Column(TypeName = "decimal(29,6)")]
        public decimal MinValue { get; set; }

        [Column(TypeName = "decimal(29,6)")]
        public decimal MaxValue { get; set; }

        [Column(TypeName = "decimal(29,6)")]
        public decimal MidValue { get; set; }

        [Column(TypeName = "decimal(29,6)")]
        public decimal AvgValue { get; set; }

        [Column(TypeName = "decimal(29,6)")]
        public decimal LastValue { get; set; }
    }
}
