﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SunforceAPI.Models
{
    /// <summary>
    /// 實時告警模型類
    /// 對應 AlertRealTime 資料表
    /// </summary>
    [Table("AlertRealTime")]
    public class RealTimeAlert
    {
       
        /// 是否禁用
        public int IsDisable { get; set; }

       
        /// 確認狀態 (0=未確認, 1=已確認)
        public int Ack { get; set; }

       
        /// 告警狀態 (0=告警中, 1=已復歸)
        public int Finish { get; set; }


        /// 告警發生時間 (主鍵之一) - 修改為 string 類型
        [Key]
        [Column("DataTime")]
        [StringLength(25)]
        public string DataTime { get; set; }


        /// 設備/點位ID (主鍵之一)
        [Key]
        [Column("DeviceID")]
        [StringLength(80)]
        public string DeviceID { get; set; }


        /// 設備/點位描述
        [StringLength(128)]
        public string Descript { get; set; }


        /// 當前值
        [StringLength(30)]
        public string CurrValue { get; set; }


        /// 告警值
        [StringLength(30)]
        public string AlertValue { get; set; }


        /// 告警限制值
        [StringLength(30)]
        public string AlertLimit { get; set; }


        /// 告警優先級
        [StringLength(10)]
        public string AlertPriority { get; set; }


        /// 告警類型
        [StringLength(20)]
        public string AlertType { get; set; }


        /// 告警分組
        public string AlertGroup { get; set; }


        /// 告警鎖定狀態
        public int AlertLocked { get; set; }


        /// 告警描述
        public string AlertDescript { get; set; }


        /// 確認用戶名
        [StringLength(50)]
        public string UserName { get; set; }


        /// 確認用戶IP
        [StringLength(30)]
        public string UserIP { get; set; }


        /// 關聯ID
        public int ToMvid { get; set; }


        /// 可見分組
        [StringLength(50)]
        public string VisibleGroup { get; set; }

 
        /// BIM對象ID
        public string BimObjectID { get; set; }

        // 獲取一個唯一鍵 (複合鍵)
        /// <returns>唯一鍵字符串</returns>
        [NotMapped]
        public string UniqueKey => $"{DataTime}-{DeviceID}";

        // 為轉換提供的屬性（不映射到數據庫）
        [NotMapped]
        public DateTime? DateTimeValue
        {
            get
            {
                if (DateTime.TryParse(DataTime, out DateTime result))
                    return result;
                return null;
            }
        }
    }
}