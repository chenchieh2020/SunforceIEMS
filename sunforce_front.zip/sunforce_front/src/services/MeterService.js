import axios from "axios";

export const fetchMeters = (page, limit) => {
  return axios.get(`http://localhost:5234/api/electricmeters`, {
    params: {
      page,
      limit,
    },
  });
};

export const fetchMeterModels = () => {
  return axios.get("http://localhost:5234/api/metermodels");
};

export const fetchMeterUsages = () => {
  return axios.get("http://localhost:5234/api/electricmeterusages");
};
