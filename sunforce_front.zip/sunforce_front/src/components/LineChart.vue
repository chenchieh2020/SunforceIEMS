<template>
  <q-card flat bordered class="q-ma-none" style="width: 100%">
    <q-card-section class="q-pa-none" style="width: 100%">
      <div class="chart-container">
        <canvas ref="chart" style="width: 100%; height: 100%"></canvas>
      </div>
    </q-card-section>
  </q-card>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  Title,
  Tooltip,
  Legend,
  CategoryScale,
} from "chart.js";

Chart.register(
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  Title,
  Tooltip,
  Legend,
  CategoryScale
);

const props = defineProps({
  data: {
    type: Object,
    required: true,
  },
  options: {
    type: Object,
    required: false,
    default: () => ({}),
  },
});

const chart = ref(null);
const chartInstance = ref(null);

const createGradient = (ctx) => {
  const gradient = ctx.createLinearGradient(0, 0, 0, 450);
  gradient.addColorStop(0, "rgba(0, 123, 255, 0.5)");
  gradient.addColorStop(0.5, "rgba(0, 123, 255, 0.25)");
  gradient.addColorStop(1, "rgba(0, 123, 255, 0)");
  return gradient;
};

const generateFullDayData = () => {
  const labels = [];
  const data = [];
  for (let i = 0; i < 24; i++) {
    for (let j = 0; j < 4; j++) {
      const hour = i.toString().padStart(2, "0");
      const minutes = (j * 15).toString().padStart(2, "0");
      labels.push(`${hour}:${minutes}`);
      data.push(Math.random() * 10); // 生成隨機數據，可根據需要調整
    }
  }
  return { labels, data };
};

const initialData = generateFullDayData();

const updateChartData = (data, gradient) => {
  return {
    labels: data.labels,
    datasets: [
      {
        label: "用電量 (kWh)",
        backgroundColor: gradient,
        pointBackgroundColor: "white",
        borderWidth: 1,
        borderColor: "#007bff",
        data: data.data,
        fill: true,
      },
    ],
  };
};

onMounted(() => {
  const ctx = chart.value.getContext("2d");
  const gradient = createGradient(ctx);
  const gradientData = updateChartData(initialData, gradient);

  chartInstance.value = new Chart(ctx, {
    type: "line",
    data: gradientData,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: {
        easing: "easeInOutQuad",
        duration: 320,
      },
      interaction: {
        mode: "index",
        intersect: false,
      },
      hover: {
        mode: "index",
        intersect: false,
      },
      scales: {
        x: {
          grid: {
            color: "rgba(200, 200, 200, 0.5)",
            lineWidth: 1,
          },
        },
        y: {
          grid: {
            color: "rgba(200, 200, 200, 0.8)",
            lineWidth: 1,
          },
        },
      },
      elements: {
        line: {
          tension: 0.4,
        },
      },
      legend: {
        display: true,
      },
      point: {
        backgroundColor: "white",
      },
      plugins: {
        tooltip: {
          titleFont: {
            family: "Open Sans",
          },
          backgroundColor: "rgba(25,118,210,0.6)",
          titleFontColor: "red",
          caretSize: 5,
          cornerRadius: 2,
          xPadding: 10,
          yPadding: 10,
        },
      },
    },
  });
});

watch(
  () => props.data,
  (newData) => {
    if (chartInstance.value) {
      const ctx = chart.value.getContext("2d");
      const gradient = createGradient(ctx);
      const gradientData = updateChartData(newData, gradient);

      chartInstance.value.data = gradientData;
      chartInstance.value.update();
    }
  },
  { deep: true }
);
</script>

<style scoped>
.chart-container {
  width: 100%;
  height: 100%; /* 調整高度以適應需要 */
}
canvas {
  width: 100% !important;
  height: 100% !important; /* 讓 canvas 適應容器 */
}
</style>
