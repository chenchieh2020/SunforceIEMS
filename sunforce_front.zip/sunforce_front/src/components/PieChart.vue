<template>
  <q-card flat bordered class="chart-container shadow">
    <q-card-section class="chart-header">
      <div class="chart-title">{{ title }}</div>
    </q-card-section>
    <q-card-section class="q-pa-none">
      <canvas ref="chart"></canvas>
    </q-card-section>
  </q-card>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import {
  Chart,
  DoughnutController,
  ArcElement,
  Tooltip,
  Legend,
} from "chart.js";

Chart.register(DoughnutController, ArcElement, Tooltip, Legend);

const props = defineProps({
  title: String,
  chartData: Object,
});

const chart = ref(null);

onMounted(() => {
  createChart();
});

watch(() => props.chartData, createChart, { deep: true });

function createChart() {
  if (chart.value) {
    new Chart(chart.value, {
      type: "doughnut",
      data: props.chartData,
      options: {
        maintainAspectRatio: false,
      },
    });
  }
}
</script>

<style scoped>
.chart-container {
  width: 23%;
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0 4px 8px rgba(15, 10, 10, 0.425);
}

.chart-header {
  width: 100%;
  color: rgb(122, 122, 122);
  text-align: left;
  padding: 10px 15px;
  border-bottom: solid #a7a7a7;
  box-sizing: border-box;
}

.chart-title {
  margin: 0;
  font-size: medium;
  font-weight: 800;
}

canvas {
  width: 100%;
  height: 200px;
}
</style>
