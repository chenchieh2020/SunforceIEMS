import { Dialog } from "quasar";

export default ({ app }) => {
  // Directly use the Dialog plugin without needing to reference Quasar
  app.config.globalProperties.$q.dialog = Dialog;
};
