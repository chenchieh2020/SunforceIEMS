// src/boot/pinia.js
import { createPinia } from "pinia";
import { boot } from "quasar/wrappers"; // 确保有这行引用，如果你用到了 boot 函数

export default boot(({ app }) => {
  const pinia = createPinia();
  app.use(pinia);
});
