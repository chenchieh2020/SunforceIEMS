<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn
          flat
          dense
          round
          icon="menu"
          aria-label="Menu"
          @click="toggleLeftDrawer"
        />

        <q-toolbar-title> IEMS 能源管理系統 </q-toolbar-title>

        <div class="row items-center">
          <!-- 告警按鈕與計數 -->
          <q-btn
            flat
            round
            icon="notifications"
            color="white"
            @click="navigateToAlerts"
            class="relative-position"
          >
            <q-badge
              v-if="hasActiveAlerts"
              color="red"
              floating
              class="alert-badge"
            >
              {{ unreadAlertsCount }}
            </q-badge>
          </q-btn>
          <q-toggle
            v-model="soundEnabled"
            :icon="soundEnabled ? 'volume_up' : 'volume_off'"
            color="red"
            class="q-mr-sm"
          />
          <q-toggle
            v-model="isDark"
            :icon="isDark ? 'dark_mode' : 'light_mode'"
            color="yellow"
            class="q-mr-sm"
          />
          <div>Beta v{{ $q.version }}</div>
        </div>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="leftDrawerOpen" show-if-above bordered>
      <div class="user-info">
        <q-avatar size="76px">
          <img :src="userAvatar" alt="User Avatar" />
        </q-avatar>
        <q-item-label style="padding-left: 10px">{{ userName }}</q-item-label>
      </div>
      <q-list>
        <q-item-label header> 能源管理監控 </q-item-label>

        <q-item clickable v-ripple @click="openTab('/', '整場能耗分析')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/xfyxpoer.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>整場能耗分析</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable v-ripple @click="openTab('/page1', '區域能耗分析')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/mjcariee.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>區域能耗分析</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable v-ripple @click="openTab('/page2', '分類用電分析')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/jgnvfzqg.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>分類用電分析</q-item-label>
          </q-item-section>
          </q-item>
                <q-item clickable v-ripple @click="openTab('/energy-breakdown', '能耗分項分析')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/ysoasulr.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>能耗分項分析</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable v-ripple @click="openTab('/page3', '電錶總覽')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/sbrtyqxj.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>電錶總覽</q-item-label>
          </q-item-section>
        </q-item>
        <q-item
          clickable
          v-ripple
          @click="openTab('/page4', '需量-峰平谷分析')"
        >
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/uwinmnkh.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>需量-峰平谷分析</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable v-ripple @click="openTab('/page5', '同環比分析')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/hcxrqqeo.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>同環比分析</q-item-label>
          </q-item-section>
        </q-item>
        <q-item clickable v-ripple @click="openTab('/page6', '用電數據查詢')">
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/fkdzyfle.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>用電數據查詢</q-item-label>
          </q-item-section>
        </q-item>
        <q-item
          clickable
          v-ripple
          @click="openTab('/RealtimeAlert', '即時告警列表')"
          class="relative-position"
        >
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/lznlxwtc.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label class="relative-position">
              即時告警列表
              <!-- 告警數量標記移至標題附近 -->
              <q-badge
                v-if="hasActiveAlerts"
                color="red"
                class="alert-badge alert-badge-near-title"
              >
                {{ unreadAlertsCount }}
              </q-badge>
            </q-item-label>
          </q-item-section>
        </q-item>
        <q-item
          clickable
          v-ripple
          @click="openTab('/HistoryAlert', '歷史告警列表')"
        >
          <q-item-section avatar>
            <lord-icon
              src="https://cdn.lordicon.com/rwtswsap.json"
              trigger="hover"
              colors="primary:#3080e8"
              style="width: 32px; height: 32px"
            >
            </lord-icon>
          </q-item-section>
          <q-item-section>
            <q-item-label>歷史告警列表</q-item-label>
          </q-item-section>
        </q-item>
      </q-list>

      <q-item-label header> 工程管理 </q-item-label>
      <q-item
        clickable
        v-ripple
        @click="openTab('/ElectricMeterPage', '電表-點位 管理')"
      >
        <q-item-section avatar>
          <lord-icon
            src="https://cdn.lordicon.com/fnxnvref.json"
            trigger="hover"
            colors="primary:#0a2e5c"
            style="width: 32px; height: 32px"
          >
          </lord-icon>
        </q-item-section>
        <q-item-section>
          <q-item-label>電表點位管理</q-item-label>
        </q-item-section>
      </q-item>
      <q-item
        clickable
        v-ripple
        @click="openTab('/CustomerPage', '客戶-區域-設備 管理')"
      >
        <q-item-section avatar>
          <lord-icon
            src="https://cdn.lordicon.com/hrjifpbq.json"
            trigger="hover"
            colors="primary:#0a2e5c"
            style="width: 32px; height: 32px"
          >
          </lord-icon>
        </q-item-section>
        <q-item-section>
          <q-item-label>客戶區域設備管理</q-item-label>
        </q-item-section>
      </q-item>
      <q-item clickable v-ripple @click="openTab('/COPManage', 'COP資料管理')">
        <q-item-section avatar>
          <lord-icon
            src="https://cdn.lordicon.com/wkvacbiw.json"
            trigger="hover"
            colors="primary:#0a2e5c"
            style="width: 32px; height: 32px"
          >
          </lord-icon>
        </q-item-section>
        <q-item-section>
          <q-item-label>COP資料管理</q-item-label>
        </q-item-section>
      </q-item>
    </q-drawer>

    <q-page-container>
      <div class="tab-container">
        <q-tabs v-model="activeTab" align="left">
          <q-tab
            v-for="tab in tabs"
            :key="tab.route"
            :name="tab.route"
            @click="setActiveTab(tab.route)"
          >
            <div class="tab-content">
              <q-btn
                flat
                dense
                icon="close"
                class="q-mr-sm"
                @click.stop="closeTab(tab.route)"
              ></q-btn>
              <span>{{ tab.label }}</span>
            </div>
          </q-tab>
        </q-tabs>

        <div v-if="!tabs.length" class="logo-container">
          <img src="..\img\IEMS.png" alt="Logo" class="logo" />
        </div>

        <router-view v-if="activeTab"></router-view>
      </div>
    </q-page-container>

    <!-- 隱藏的音頻元素用於播放告警聲音 -->
    <audio
      ref="alertSound"
      src="/sounds/alert-sound.mp3"
      preload="auto"
      id="alertSound"
    ></audio>
  </q-layout>
</template>

<script setup>
import { ref, computed, watch, onMounted, onBeforeUnmount } from "vue";
import { useTabStore } from "src/stores/tab";
import { useRouter } from "vue-router";
import { Dark, LocalStorage, Notify } from "quasar";
import * as signalR from "@microsoft/signalr";
import axios from "axios";

// 基本設置
const leftDrawerOpen = ref(false);
const tabStore = useTabStore();
const router = useRouter();
const isDark = ref(Dark.isActive);
const alertSound = ref(null);

// API 設定
const API_URL = "http://localhost:5121";
const HUB_URL = `${API_URL}/realTimeAlertHub`;

// SignalR 設置
const connection = ref(null);
const connectionStatus = ref("未連接");
const connectionStatusClass = ref("status-disconnected");
const reconnectInterval = ref(null);
const reconnectAttempts = ref(0);
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3秒後重連
const pollingInterval = ref(null); // 用於定期檢查連接狀態
const isConnecting = ref(false);

// 告警相關狀態
const soundEnabled = ref(true);
const unreadAlerts = ref([]);
const unreadAlertsCount = computed(() => unreadAlerts.value.length);
const hasActiveAlerts = computed(() => unreadAlertsCount.value > 0);
const alertRefreshInterval = ref(null); // 用於定期刷新告警
const systemInitialized = ref(false);

// 從 LocalStorage 加載設置
onMounted(() => {
  // 嘗試從 LocalStorage 加載聲音設置
  const savedSoundEnabled = LocalStorage.getItem("alert-sound-enabled");
  if (savedSoundEnabled !== null) {
    soundEnabled.value = savedSoundEnabled;
  }

  // 等待系統初始化完成
  setTimeout(() => {
    systemInitialized.value = true;
    // 連接 SignalR
    connectSignalR();

    // 延遲獲取告警，確保系統初始化完成
    setTimeout(() => {
      // 獲取未確認的警報
      fetchActiveAlerts();
    }, 2000);
  }, 1500);
});

// 獲取活動中的告警（未確認且未復歸的）
const fetchActiveAlerts = async () => {
  if (!systemInitialized.value) return;

  try {
    console.log("正在獲取活動告警...");
    const response = await axios.get(`${API_URL}/api/RealTimeAlert`, {
      params: {
        pageNumber: 1,
        pageSize: 20, // 獲取較多條目以確保捕獲所有活動告警
      },
      timeout: 10000,
      withCredentials: false,
    });

    if (response.data && response.data.items) {
      // 篩選未確認且未復歸的告警
      const criticalAlerts = response.data.items.filter(
        (alert) => alert.finish === 0 && alert.ack === 0
      );

      // 更新未讀告警列表
      unreadAlerts.value = criticalAlerts;

      console.log(`已加載 ${unreadAlerts.value.length} 個未確認的告警`);
    }
  } catch (error) {
    console.error("獲取活動告警失敗:", error);
  }
};

// 保存設置到 LocalStorage
watch(soundEnabled, (newValue) => {
  LocalStorage.set("alert-sound-enabled", newValue);
});

// 監聽 isDark 的變化來切換暗黑模式
watch(isDark, (val) => {
  Dark.set(val);
});

const userAvatar = ref("/sunforce_avatar.png");
const userName = ref("最高權限管理者");

// SignalR 連接管理
const connectSignalR = () => {
  if (isConnecting.value) return;
  if (!systemInitialized.value) return;

  // 如果已經連接，不再重新連接
  if (
    connection.value &&
    connection.value.state === signalR.HubConnectionState.Connected
  ) {
    console.log("SignalR 已連接，不再嘗試重新連接");
    return;
  }

  isConnecting.value = true;

  try {
    console.log("建立新的 SignalR 連接...");

    // 創建新連接
    connection.value = new signalR.HubConnectionBuilder()
      .withUrl(HUB_URL, {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
      .configureLogging(signalR.LogLevel.Information)
      .build();

    // 設置連接開始事件
    connection.value.onreconnecting((error) => {
      console.warn("SignalR 正在重新連接:", error);
      connectionStatus.value = "重新連接中";
      connectionStatusClass.value = "status-reconnecting";
    });

    connection.value.onreconnected((connectionId) => {
      console.log("SignalR 已重新連接, ID:", connectionId);
      connectionStatus.value = "已連接";
      connectionStatusClass.value = "status-connected";

      // 重新加入組
      joinGroups();
    });

    connection.value.onclose((error) => {
      console.error("SignalR 連接已關閉:", error);
      connectionStatus.value = "已關閉";
      connectionStatusClass.value = "status-disconnected";
    });

    // 處理收到的告警消息 - 監聽所有告警類型
    connection.value.on("ReceiveAlert", (message) => {
      console.log("收到告警更新:", message);
      if (message.type === "global" || message.type === "alertUpdate") {
        handleNewAlert(message.alert);
      }
    });

    // 監聽批量告警更新
    connection.value.on("ReceiveBatchAlerts", (message) => {
      console.log("收到批量告警更新:", message);
      if (message.type === "batchUpdate") {
        message.alerts.forEach((alert) => handleNewAlert(alert));
      }
    });

    // 監聽告警確認通知
    connection.value.on("ReceiveAlertAcknowledged", (message) => {
      console.log("收到告警確認通知:", message);

      // 從未讀告警列表中移除已確認的告警
      removeAcknowledgedAlert(message.dateTime, message.deviceId);
    });

    // 啟動連接
    startConnection();
  } catch (error) {
    console.error("建立 SignalR 連接失敗:", error);
    connectionStatus.value = "連接失敗";
    connectionStatusClass.value = "status-failed";
    isConnecting.value = false;
  }
};

// 加入 SignalR 群組
const joinGroups = async () => {
  try {
    if (
      connection.value &&
      connection.value.state === signalR.HubConnectionState.Connected
    ) {
      // 加入全局通知組
      await connection.value.invoke("JoinGroup", "global");
      console.log("已加入全局通知組");

      // 同時加入告警頁面組，確保獲取所有告警更新
      await connection.value.invoke("JoinGroup", "alertPage");
      console.log("已加入告警頁面組");
    }
  } catch (error) {
    console.error("加入組失敗:", error);
  }
};

// 從未讀告警中移除已確認的告警
const removeAcknowledgedAlert = (dateTime, deviceId) => {
  const index = unreadAlerts.value.findIndex(
    (alert) =>
      (alert.dataTime === dateTime || alert.dateTime === dateTime) &&
      (alert.deviceID === deviceId || alert.deviceId === deviceId)
  );

  if (index !== -1) {
    unreadAlerts.value.splice(index, 1);
    console.log(`已從未讀列表中移除確認的告警: ${deviceId} (${dateTime})`);
  }
};

// 啟動 SignalR 連接
const startConnection = async () => {
  try {
    console.log("正在啟動 SignalR 連接...");
    await connection.value.start();
    console.log("SignalR 已成功連接!");
    connectionStatus.value = "已連接";
    connectionStatusClass.value = "status-connected";
    reconnectAttempts.value = 0;

    // 加入群組
    await joinGroups();

    // 清除重連計時器
    if (reconnectInterval.value) {
      clearTimeout(reconnectInterval.value);
      reconnectInterval.value = null;
    }

    isConnecting.value = false;
  } catch (error) {
    console.error("SignalR 連接失敗:", error);
    connectionStatus.value = "連接失敗";
    connectionStatusClass.value = "status-failed";
    isConnecting.value = false;

    // 設置重連
    if (
      !reconnectInterval.value &&
      reconnectAttempts.value < maxReconnectAttempts
    ) {
      reconnectInterval.value = setTimeout(() => {
        reconnectAttempts.value++;
        connectionStatus.value = `重新連接中 (${reconnectAttempts.value}/${maxReconnectAttempts})`;
        connectionStatusClass.value = "status-reconnecting";

        console.log(
          `嘗試重新連接 (${reconnectAttempts.value}/${maxReconnectAttempts})`
        );
        startConnection();

        if (reconnectAttempts.value >= maxReconnectAttempts) {
          clearTimeout(reconnectInterval.value);
          reconnectInterval.value = null;
          connectionStatus.value = "連接失敗";
          connectionStatusClass.value = "status-failed";

          // 連接失敗後仍然定期輪詢告警
          fetchActiveAlerts();
        }
      }, reconnectDelay);
    }
  }
};

// 處理新的告警資料
const handleNewAlert = (newAlert) => {
  try {
    if (!newAlert) {
      console.error("收到無效告警數據");
      return;
    }

    // 檢查是否為不顯示的告警類型 (告警復歸且被確認)
    if (newAlert.finish === 1 && newAlert.ack === 1) {
      removeAcknowledgedAlert(
        newAlert.dataTime || newAlert.dateTime,
        newAlert.deviceID || newAlert.deviceId
      );
      return;
    }

    console.log("處理新告警:", newAlert);

    // 將 dataTime 和 deviceID 鍵名標準化
    const normalizedAlert = {
      ...newAlert,
      dataTime: newAlert.dataTime || newAlert.dateTime, // 兼容不同命名
      deviceID: newAlert.deviceID || newAlert.deviceId, // 兼容不同命名
      rowKey:
        newAlert.rowKey ||
        `${newAlert.dataTime || newAlert.dateTime}-${
          newAlert.deviceID || newAlert.deviceId
        }`,
    };

    // 檢查是否為新增告警（未確認且未復歸）
    const isNewCriticalAlert =
      normalizedAlert.finish === 0 && normalizedAlert.ack === 0;

    // 如果是未確認且未復歸的告警，添加到未讀列表
    if (isNewCriticalAlert) {
      // 檢查是否已存在
      const existingIndex = unreadAlerts.value.findIndex(
        (a) =>
          a.rowKey === normalizedAlert.rowKey ||
          (a.deviceID === normalizedAlert.deviceID &&
            a.dataTime === normalizedAlert.dataTime)
      );

      if (existingIndex === -1) {
        // 新增到未讀告警
        unreadAlerts.value.push(normalizedAlert);
        console.log("新增未讀告警, 當前未讀數量:", unreadAlerts.value.length);

        // 如果啟用了聲音，播放提示音
        if (soundEnabled.value) {
          playAlertSound();
        }

        // 顯示通知
        showAlertNotification(normalizedAlert);
      } else {
        // 更新現有告警
        unreadAlerts.value[existingIndex] = normalizedAlert;
      }
    } else if (normalizedAlert.ack === 1 || normalizedAlert.finish === 1) {
      // 如果告警已確認或已復歸，從未讀列表中移除
      removeAcknowledgedAlert(
        normalizedAlert.dataTime,
        normalizedAlert.deviceID
      );
    }
  } catch (error) {
    console.error("處理新告警時發生錯誤:", error, newAlert);
  }
};

// 播放告警提示音
const playAlertSound = () => {
  try {
    console.log("正在嘗試播放告警聲音...");
    // 先嘗試使用 ref
    if (alertSound.value) {
      alertSound.value.currentTime = 0;
      alertSound.value.play().catch((error) => {
        console.error("播放告警聲音失敗 (ref):", error);

        // 如果 ref 方式失敗，嘗試使用 getElementById
        const audioElement = document.getElementById("alertSound");
        if (audioElement) {
          audioElement.currentTime = 0;
          audioElement.play().catch((err) => {
            console.error("播放告警聲音失敗 (getElementById):", err);
          });
        } else {
          console.error("找不到音頻元素");

          // 最後嘗試創建一個新的音頻元素作為備用
          try {
            const newAudio = new Audio("/sounds/alert-sound.mp3");
            newAudio.play().catch((err) => {
              console.error("使用新創建的音頻元素播放失敗:", err);
            });
          } catch (err) {
            console.error("創建新音頻元素失敗:", err);
          }
        }
      });
    } else {
      // 嘗試使用 getElementById 作為備用方法
      const audioElement = document.getElementById("alertSound");
      if (audioElement) {
        audioElement.currentTime = 0;
        audioElement.play().catch((err) => {
          console.error("播放告警聲音失敗 (getElementById):", err);
        });
      } else {
        console.error("找不到音頻元素");
      }
    }
  } catch (error) {
    console.error("播放告警提示音時發生錯誤:", error);
  }
};

// 顯示桌面通知
const showAlertNotification = (alert) => {
  Notify.create({
    message: `新告警: ${alert.descript || alert.deviceID}`,
    caption: `${alert.alertDescript || alert.alertType || "系統告警"}`,
    icon: "warning",
    color: "negative",
    position: "top-right",
    timeout: 5000,
    actions: [
      { label: "查看", color: "white", handler: () => navigateToAlerts() },
    ],
  });
};

// 跳轉到告警頁面
const navigateToAlerts = () => {
  openTab("/RealtimeAlert", "即時告警列表");
};

// 組件卸載時斷開 SignalR 連接
onBeforeUnmount(() => {
  // 清除所有計時器
  if (alertRefreshInterval.value) {
    clearInterval(alertRefreshInterval.value);
    alertRefreshInterval.value = null;
  }

  if (pollingInterval.value) {
    clearInterval(pollingInterval.value);
    pollingInterval.value = null;
  }

  if (reconnectInterval.value) {
    clearTimeout(reconnectInterval.value);
    reconnectInterval.value = null;
  }

  // 斷開 SignalR 連接
  if (connection.value) {
    try {
      // 如果連接是連接狀態，則嘗試離開組
      if (connection.value.state === signalR.HubConnectionState.Connected) {
        // 離開組
        connection.value
          .invoke("LeaveGroup", "global")
          .catch((err) => console.error("離開全局組時發生錯誤:", err));
        connection.value
          .invoke("LeaveGroup", "alertPage")
          .catch((err) => console.error("離開告警頁面組時發生錯誤:", err));
      }

      // 停止連接
      connection.value
        .stop()
        .catch((err) => console.error("停止連接時發生錯誤:", err));
    } catch (error) {
      console.error("斷開 SignalR 連接時發生錯誤:", error);
    }
  }
});

// 標籤頁管理功能
const openTab = (route, label) => {
  tabStore.addTab({ route, label });
  setActiveTab(route);
};

const closeTab = (route) => {
  tabStore.removeTab(route);
  if (tabStore.activeTab === route) {
    setActiveTab(tabStore.tabs.length ? tabStore.tabs[0].route : null);
  }
};

const setActiveTab = (route) => {
  tabStore.setActiveTab(route);
  if (route) {
    router.push(route);
  }
};

const activeTab = computed(() => tabStore.activeTab);
const tabs = computed(() => tabStore.tabs);

watch(activeTab, (newRoute) => {
  if (newRoute) {
    router.push(newRoute);
  }
});

function toggleLeftDrawer() {
  leftDrawerOpen.value = !leftDrawerOpen.value;
}
</script>

<style scoped>
.q-tabs {
  display: flex;
  align-items: center;
}

.tab-container {
  display: flex;
  flex-direction: column;
  margin-top: 0%;
  border-bottom-color: #ffac55;
}

.logo-container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}

.logo {
  padding-top: 10%;
  max-width: 25%;
  max-height: 25%;
}

.tab-content {
  display: flex;
  align-items: center;
}

.tab-content .q-btn {
  margin-right: 8px;
}

.user-info {
  display: flex;
  align-items: center;
  padding: 16px;
}

.user-info q-avatar {
  margin-right: 16px;
}

/* 相對定位容器 */
.relative-position {
  position: relative;
}

/* 告警徽章靠近標題 */
.alert-badge-near-title {
  position: absolute;
  top: -8px;
  right: -15px;
  font-size: 0.8em;
  padding: 2px 6px;
}

/* 連接狀態指示器樣式 */
.connection-indicator {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  margin-right: 8px;
}

.status-connected {
  background-color: #21ba45;
}

.status-disconnected {
  background-color: #c10015;
}

.status-reconnecting {
  background-color: #f2c037;
  animation: blink 1s infinite;
}

.status-error,
.status-failed {
  background-color: #c10015;
}

@keyframes blink {
  50% {
    opacity: 0.5;
  }
}

/* 告警徽章樣式 */
.alert-badge {
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% {
    transform: scale(0.95);
    box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.7);
  }

  70% {
    transform: scale(1);
    box-shadow: 0 0 0 10px rgba(255, 0, 0, 0);
  }

  100% {
    transform: scale(0.95);
    box-shadow: 0 0 0 0 rgba(255, 0, 0, 0);
  }
}
</style>
