// src/router/routes.js
const routes = [
  {
    path: "/",
    component: () => import("layouts/MainLayout.vue"),
    children: [
      {
        name: "整場能耗分析",
        path: "",
        component: () => import("pages/IndexPage.vue"),
      },
      {
        name: "區域能耗分析",
        path: "page1",
        component: () => import("pages/TestPage1.vue"),
      },
      {
        name: "分類用電分析",
        path: "page2",
        component: () => import("pages/TestPage2.vue"),
      },
      {
        name: "能耗分項分析",
        path: "energy-breakdown",
        component: () => import("pages/EnergyBreakdown.vue"),
      },
      {
        name: "電錶總覽",
        path: "page3",
        component: () => import("pages/TestPage3.vue"),
      },
      {
        name: "需量-峰平谷分析",
        path: "page4",
        component: () => import("pages/TestPage4.vue"),
      },
      {
        name: "同環比分析",
        path: "page5",
        component: () => import("pages/TestPage5.vue"),
      },
      {
        name: "用電數據查詢",
        path: "page6",
        component: () => import("pages/TestPage6.vue"),
      },
      {
        name: "點位管理與勾稽",
        path: "ElectricMeterPage",
        component: () => import("pages/ElectricMeterPage.vue"),
      },
      {
        name: "客戶管理",
        path: "CustomerPage",
        component: () => import("pages/CustomerPage.vue"),
      },
      {
        name: "區域管理",
        path: "/region-management/:customerId",
        component: () => import("pages/RegionManagement.vue"),
        props: true,
      },
      {
        name: "閘道器管理",
        path: "/gateway-management/:customerId/:regionId",
        component: () => import("pages/GatewayManagement.vue"),
        props: true,
      },
      {
        name: "開發中",
        path: "DevelopingPage",
        component: () => import("pages/DevelopingPage.vue"),
      },
      {
        name: "API通訊管理",
        path: "BackendHealth",
        component: () => import("pages/BackendHealth.vue"),
      },
      {
        name: "COP資料管理",
        path: "COPManage",
        component: () => import("pages/COPManage.vue"),
      },
      {
        name: "即時告警列表",
        path: "RealtimeAlert",
        component: () => import("pages/RealtimeAlert.vue"),
      },
      {
        name: "歷史告警列表",
        path: "HistoryAlert",
        component: () => import("pages/HistoryAlert.vue"),
      },
      // Add more routes as needed
    ],
  },
];

export default routes;
