// src/stores/tab.js
import { defineStore } from "pinia";

export const useTabStore = defineStore("tab", {
  state: () => ({
    tabs: [],
    activeTab: null,
  }),
  actions: {
    addTab(tab) {
      if (!this.tabs.find((t) => t.route === tab.route)) {
        this.tabs.push(tab);
      }
      this.activeTab = tab.route;
    },
    removeTab(route) {
      this.tabs = this.tabs.filter((t) => t.route !== route);
      if (this.activeTab === route) {
        this.activeTab = this.tabs.length ? this.tabs[0].route : null;
      }
    },
    setActiveTab(route) {
      this.activeTab = route;
    },
  },
});
