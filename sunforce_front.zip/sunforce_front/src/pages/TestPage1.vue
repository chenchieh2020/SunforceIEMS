<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇區域(第一層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption3"
              :options="options3"
              label="選擇區域(第二層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption4"
              :options="options4"
              label="選擇用電種類"
              outlined
              dense
              multiple
              use-chips
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="startDate"
              label="開始日期"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="endDate"
              label="結束日期"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card>
      <q-card-section class="chart-header">
        <div class="chart-title">區域用電種類時序趨勢圖</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <canvas ref="chart"></canvas>
      </q-card-section>
    </q-card>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Dark } from "quasar";

Chart.register(
  LineController,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler
);

const chart = ref(null);
let chartInstance = null;

// Function to generate time labels for every 30 minutes
const generateTimeLabels = () => {
  const labels = [];
  for (let hour = 0; hour < 24; hour++) {
    labels.push(`${String(hour).padStart(2, "0")}:00`);
    labels.push(`${String(hour).padStart(2, "0")}:30`);
  }
  return labels;
};

// Simulate real usage data
const generateUsageData = (base, fluctuation) => {
  return Array(48)
    .fill()
    .map((_, i) => {
      const hour = Math.floor(i / 2);
      const minute = i % 2 === 0 ? 0 : 30;
      let value = base + Math.random() * fluctuation;
      if (hour >= 7 && hour <= 9) {
        value *= 1.5;
      } else if (hour >= 12 && hour <= 14) {
        value *= 0.8;
      } else if (hour >= 18 && hour <= 20) {
        value *= 1.3;
      }
      return Math.round(value);
    });
};

const getChartConfig = (isDark) => {
  const gridColor = isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)";
  const textColor = isDark ? "#ffffff" : "#666666";

  return {
    labels: generateTimeLabels(),
    datasets: [
      {
        label: "空壓用電",
        data: generateUsageData(40, 15),
        backgroundColor: "rgba(255, 193, 7, 0.1)",
        borderColor: "rgba(255, 193, 7, 1)",
        borderWidth: 1,
        fill: true,
        tension: 0.4,
      },
      {
        label: "照明用電",
        data: generateUsageData(30, 10),
        backgroundColor: "rgba(76, 175, 80, 0.1)",
        borderColor: "rgba(76, 175, 80, 1)",
        borderWidth: 1,
        fill: true,
        tension: 0.4,
      },
      {
        label: "動力用電",
        data: generateUsageData(70, 30),
        backgroundColor: "rgba(33, 150, 243, 0.1)",
        borderColor: "rgba(33, 150, 243, 1)",
        borderWidth: 1,
        fill: true,
        tension: 0.4,
      },
      {
        label: "空調用電",
        data: generateUsageData(50, 20),
        backgroundColor: "rgba(0, 150, 136, 0.1)",
        borderColor: "rgba(0, 150, 136, 1)",
        borderWidth: 1,
        fill: true,
        tension: 0.4,
      },
    ],
  };
};

const getChartOptions = (isDark) => {
  const gridColor = isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)";
  const textColor = isDark ? "#ffffff" : "#666666";

  return {
    responsive: true,
    scales: {
      x: {
        stacked: false,
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
      y: {
        beginAtZero: true,
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
    },
    plugins: {
      legend: {
        position: "top",
        labels: {
          color: textColor,
          font: {
            size: 12,
          },
        },
      },
      tooltip: {
        mode: "index",
        intersect: false,
        backgroundColor: isDark
          ? "rgba(0, 0, 0, 0.8)"
          : "rgba(255, 255, 255, 0.8)",
        titleColor: isDark ? "#ffffff" : "#000000",
        bodyColor: isDark ? "#ffffff" : "#000000",
        borderColor: isDark ? "rgba(255, 255, 255, 0.2)" : "rgba(0, 0, 0, 0.2)",
        borderWidth: 1,
      },
    },
  };
};

// 初始化圖表
const initChart = () => {
  if (chartInstance) {
    chartInstance.destroy();
  }

  const isDark = Dark.isActive;
  chartInstance = new Chart(chart.value, {
    type: "line",
    data: getChartConfig(isDark),
    options: getChartOptions(isDark),
  });
};

// 監聽暗色模式變化
watch(
  () => Dark.isActive,
  (isDark) => {
    initChart();
  }
);

onMounted(() => {
  initChart();
});

// Rest of your component code...
</script>

<style>
.col-25 {
  width: 25%;
}

.chart-container {
  width: 23%;
}

@media (max-width: 800px) {
  .chart-container {
    width: 100% !important;
  }
}
</style>
