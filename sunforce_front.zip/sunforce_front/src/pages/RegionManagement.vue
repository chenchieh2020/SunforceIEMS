<template>
  <div class="q-pa-md">
    <!-- Breadcrumb Navigation -->
    <q-breadcrumbs separator-icon="chevron_right" class="q-mb-md">
      <q-breadcrumbs-el
        icon="home"
        label="客戶管理"
        @click="navigateToCustomerManagement"
      />
      <q-breadcrumbs-el label="區域管理" />
    </q-breadcrumbs>
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md items-center">
          <div class="text-h6">區域管理 - {{ customerName }}</div>
          <q-space />
          <q-col cols="auto">
            <!-- 新增客戶按鈕 -->
            <q-btn
              label="+ 新增區域"
              color="deep-orange"
              @click="openAddDialog"
              unelevated
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>

    <q-page class="q-pa-md">
      <!-- 樹狀結構區域管理 -->
      <q-card class="q-mb-md">
        <q-card-section>
          <div
            v-if="regionTree.length === 0"
            class="text-center q-mt-md q-mb-md"
          >
            <q-btn label="新增區域" color="primary" @click="openAddDialog()" />
          </div>
          <div v-else>
            <q-tree :nodes="regionTree" node-key="regionID">
              <template v-slot:default-header="props">
                <div class="row items-center">
                  <span>{{ props.node.label }}</span>

                  <q-btn
                    flat
                    icon="edit"
                    dense
                    color="primary"
                    @click="openEditDialog(props.node)"
                  />

                  <q-btn
                    flat
                    icon="delete"
                    dense
                    color="negative"
                    @click="deleteRegion(props.node)"
                  />
                  <q-btn
                    color="secondary"
                    label="設備管理"
                    @click="navigateToAddGateway(props.node)"
                  />
                </div>
              </template>
            </q-tree>
          </div>
        </q-card-section>
      </q-card>
    </q-page>
    <!-- 新增區域對話框 -->
    <q-dialog v-model="isAddDialogOpen">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">新增區域資訊</div>
        </q-card-section>
        <q-card-section>
          <q-input
            v-model="newRegion.RegionName"
            label="區域名稱"
            outlined
            dense
          />
          <q-input
            v-model="route.params.customerId"
            label="客戶ID"
            outlined
            dense
            readonly
          />
          <q-select
            v-model="newRegion.ParentRegionID"
            :options="regionOptions"
            label="父區域名稱"
            option-value="RegionID"
            option-label="RegionName"
            outlined
            dense
          />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="addRegion" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 编辑區域對話框 -->
    <q-dialog v-model="isEditDialogOpen">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">編輯區域資訊</div>
        </q-card-section>
        <q-card-section>
          <q-input
            v-model="newRegion.RegionName"
            label="區域名稱"
            outlined
            dense
          />
          <q-input
            v-model="route.params.customerId"
            label="客戶ID"
            outlined
            dense
            readonly
          />
          <q-select
            v-model="newRegion.ParentRegionID"
            :options="regionOptions"
            label="父區域名稱"
            option-value="RegionID"
            option-label="RegionName"
            outlined
            dense
          />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="editRegion" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute, useRouter } from "vue-router";
import { useQuasar } from "quasar";

const $q = useQuasar();
const route = useRoute();
const router = useRouter();

const regionTree = ref([]);
const customerName = ref("");
const isAddDialogOpen = ref(false);
const isEditDialogOpen = ref(false);
const newRegion = ref({
  RegionName: "",
  ParentRegionID: null,
  CustomerID: route.params.customerId,
});
let editingNode = null;

const regionOptions = ref([]); // List of available regions for the parent region dropdown

const fetchCustomerInfo = async () => {
  try {
    const customerId = route.params.customerId;
    const response = await axios.get(
      `http://localhost:5234/api/customers/${customerId}`
    );
    customerName.value = response.data.customerName;
  } catch (error) {
    console.error("Failed to fetch customer info:", error);
    $q.notify({
      type: "negative",
      message: "無法加載客戶資料",
      position: "center",
    });
  }
};

const fetchRegions = async () => {
  try {
    const customerId = route.params.customerId;
    const response = await axios.get(
      `http://localhost:5234/api/CustomerRegions`,
      {
        params: { customerId: customerId },
      }
    );

    const regions = response.data.regions;
    regionTree.value = buildTree(regions);

    // Populate regionOptions with all regions for the parent dropdown
    regionOptions.value = regions.map((region) => ({
      RegionID: region.regionID,
      RegionName: region.regionName,
    }));
  } catch (error) {
    console.error("Failed to fetch regions:", error);
    $q.notify({
      type: "negative",
      message: "無法加載區域資料",
      position: "center",
    });
  }
};

const buildTree = (regions) => {
  const map = {};

  // 建立一個 Map，以便快速查找節點
  regions.forEach((region) => {
    map[region.regionID] = {
      ...region,
      children: [],
      label: region.regionName,
    };
  });

  const tree = [];

  regions.forEach((region) => {
    if (region.parentRegionID === null) {
      // 如果沒有 parentRegionID，這個區域是根節點，直接加入樹狀結構
      tree.push(map[region.regionID]);
    } else {
      // 如果有 parentRegionID，找到其父節點並把自己加入父節點的 children 中
      const parent = map[region.parentRegionID];
      if (parent) {
        parent.children.push(map[region.regionID]);
      }
    }
  });

  return tree;
};

const openAddDialog = () => {
  newRegion.value = {
    RegionName: "",
    ParentRegionID: null,
    CustomerID: route.params.customerId,
  };
  isAddDialogOpen.value = true;
};

const addRegion = async () => {
  try {
    const payload = {
      RegionName: newRegion.value.RegionName,
      ParentRegionID: newRegion.value.ParentRegionID
        ? newRegion.value.ParentRegionID.RegionID
        : null,
      CustomerID: newRegion.value.CustomerID,
    };

    await axios.post("http://localhost:5234/api/CustomerRegions", payload);

    $q.notify({
      type: "positive",
      message: ` ${newRegion.value.RegionName} 區域新增成功`,
      position: "center",
    });

    await fetchRegions();
    isAddDialogOpen.value = false;
  } catch (error) {
    console.error("Failed to add region:", error);
    $q.notify({
      type: "negative",
      message: "Failed to add region",
      position: "center",
    });
  }
};

const openEditDialog = (node) => {
  // Find the parent region by ID to get its object for display in the dropdown
  const parentRegion = regionOptions.value.find(
    (region) => region.RegionID === node.parentRegionID
  );

  // Set the newRegion values accordingly
  newRegion.value = {
    RegionName: node.label, // Set the region name
    ParentRegionID: parentRegion || null, // Use the complete region object for display, not just the ID
    CustomerID: node.customerID,
    RegionID: node.regionID, // Set the correct RegionID
  };

  editingNode = node; // Capture the node being edited
  isEditDialogOpen.value = true;
};

const editRegion = async () => {
  if (!editingNode) return;

  try {
    const payload = {
      RegionID: newRegion.value.RegionID,
      RegionName: newRegion.value.RegionName,
      // Extract the ID from the ParentRegionID object
      ParentRegionID: newRegion.value.ParentRegionID
        ? newRegion.value.ParentRegionID.RegionID
        : null,
      CustomerID: newRegion.value.CustomerID,
    };

    console.log("Editing Region Payload:", payload);

    const response = await axios.put(
      `http://localhost:5234/api/CustomerRegions/${newRegion.value.RegionID}`,
      payload
    );

    console.log("Server Response:", response);

    $q.notify({
      type: "positive",
      message: `區域名稱更新為 ${newRegion.value.RegionName}`,
      position: "center",
    });

    await fetchRegions();
    isEditDialogOpen.value = false;
  } catch (error) {
    console.error("Failed to update region:", error.response.data);
    $q.notify({
      type: "negative",
      message: "更新區域失敗",
      position: "center",
    });
  }
};

const deleteRegion = async (node) => {
  // 解包 Proxy 对象，获取原始数据
  const originalNode = JSON.parse(JSON.stringify(node));

  // 检查是否有有效的 regionID
  if (!originalNode || !originalNode.regionID) {
    $q.notify({
      type: "negative",
      message: "無法刪除：區域ID無效",
      position: "center",
    });
    return;
  }

  // 确认删除操作
  const hasChildren = originalNode.children && originalNode.children.length > 0;
  const confirmMessage = hasChildren
    ? `區域 "${originalNode.regionName}" 下有 ${originalNode.children.length} 個子區域，確定要刪除該區域及其所有子區域嗎？`
    : `你確定要刪除區域 "${originalNode.regionName}" 嗎？`;

  $q.notify({
    type: "warning",
    message: confirmMessage,
    position: "center",
    timeout: 0, // 通知不会自动消失
    actions: [
      {
        label: "取消",
        color: "white",
        handler: () => {
          $q.notify({
            type: "info",
            message: "刪除操作已取消",
            position: "center",
          });
        },
      },
      {
        label: "確認",
        color: "yellow",
        handler: async () => {
          try {
            await axios.delete(
              `http://localhost:5234/api/CustomerRegions/${originalNode.regionID}`
            );
            $q.notify({
              type: "positive",
              message: `區域 "${originalNode.regionName}" 刪除成功`,
              position: "center",
            });
            await fetchRegions();
          } catch (error) {
            console.error("Failed to delete region:", error.response.data);
            $q.notify({
              type: "negative",
              message: `刪除區域失敗：${
                error.response.data.title || "未知錯誤"
              }`,
              position: "center",
            });
          }
        },
      },
    ],
  });
};

const navigateToCustomerManagement = () => {
  router.push({ name: "客戶管理" });
};

onMounted(() => {
  fetchCustomerInfo();
  fetchRegions();
});

const navigateToAddGateway = (node) => {
  router.push({
    name: "閘道器管理", // 更新为新的页面名称
    params: {
      regionId: node.regionID, // 将区域ID作为参数传递
      customerId: route.params.customerId, // 确保将 customerId 也传递
    },
  });
};
</script>
