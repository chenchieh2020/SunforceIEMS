<template>
  <q-page class="q-pa-md">
    <!-- 1. 報表類型選擇 -->
    <q-tabs v-model="selectedReportType" class="q-mb-md">
      <q-tab name="realtime" label="即時報表" />
      <q-tab name="daily" label="日報表" />
      <q-tab name="monthly" label="月報表" />
      <q-tab name="yearly" label="年報表" />
    </q-tabs>

    <!-- 2. 篩選條件區 -->
    <div class="q-mb-md row items-center">
      <q-input
        v-if="selectedReportType === 'realtime'"
        v-model="today"
        label="日期"
        readonly
        class="q-ml-md"
      />

      <div
        v-if="selectedReportType === 'daily'"
        class="row q-col-gutter-md q-ml-md"
      >
        <q-date v-model="startDate" label="開始日期" class="col" />
        <q-date v-model="endDate" label="結束日期" class="col" />
      </div>

      <q-select
        v-if="selectedReportType === 'monthly'"
        v-model="selectedMonth"
        :options="monthOptions"
        label="選擇月份"
        class="q-ml-md"
      />

      <q-select
        v-if="selectedReportType === 'yearly'"
        v-model="selectedYear"
        :options="yearOptions"
        label="選擇年份"
        class="q-ml-md"
      />

      <q-btn label="查詢" color="primary" @click="fetchData" class="q-ml-md" />
    </div>

    <!-- 3. 加載動畫 -->
    <div v-if="loading" class="text-center q-mb-md">
      <q-spinner size="md" color="primary" />
      <span class="q-ml-sm">正在加載數據...</span>
    </div>

    <!-- 4. 報表展示區 - Chart.js 趨勢圖 -->
    <q-card>
      <q-card-section class="chart-header">
        <div class="chart-title">區域用電種類時序趨勢圖</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <canvas ref="chartCanvas"></canvas>
      </q-card-section>
    </q-card>

    <!-- 5. 數據摘要 -->
    <div class="q-mt-md row">
      <q-card
        class="col q-pa-md"
        v-for="summary in summaries"
        :key="summary.name"
      >
        <q-card-section class="text-h6">{{ summary.name }}</q-card-section>
        <q-card-section class="text-h5 text-primary">{{
          summary.value
        }}</q-card-section>
      </q-card>
    </div>

    <!-- 6. 數據表格 -->
    <q-table
      :rows="tableData"
      :columns="columns"
      row-key="id"
      class="q-mt-md"
    />
  </q-page>
</template>

<script>
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from "vue";
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Dark } from "quasar";

// 註冊 Chart.js 元件
Chart.register(
  LineController,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
  Filler
);

export default {
  setup() {
    const selectedReportType = ref("realtime");
    const today = ref(new Date().toISOString().split("T")[0]);
    const startDate = ref(null);
    const endDate = ref(null);
    const selectedMonth = ref(null);
    const selectedYear = ref(null);
    const monthOptions = ref(
      [...Array(12)].map((_, i) => ({ label: `${i + 1} 月`, value: i + 1 }))
    );
    const yearOptions = ref(
      [...Array(10)].map((_, i) => ({
        label: `${2020 + i} 年`,
        value: 2020 + i,
      }))
    );

    const chartCanvas = ref(null);
    let chartInstance = null;
    const loading = ref(false);
    const tableData = ref([]);
    const columns = ref([
      { name: "timestamp", label: "時間", field: "timestamp", align: "left" },
      { name: "value", label: "數據值", field: "value", align: "right" },
    ]);

    // **數據摘要**
    const summaries = ref([
      { name: "總計", value: "0 kWh" },
      { name: "最大值", value: "0 kWh" },
      { name: "最小值", value: "0 kWh" },
    ]);

    const reportDescription = computed(() => {
      switch (selectedReportType.value) {
        case "realtime":
          return "顯示當天每 5 分鐘的即時數據";
        case "daily":
          return "選擇日期範圍，顯示每天的數據總和";
        case "monthly":
          return "選擇月份，顯示每日平均數據";
        case "yearly":
          return "選擇年份，顯示每月平均數據";
        default:
          return "";
      }
    });

    const fetchData = () => {
      loading.value = true;
      setTimeout(() => {
        // **模擬數據**
        tableData.value = [
          { id: 1, timestamp: "08:00", value: Math.random() * 100 },
          { id: 2, timestamp: "12:00", value: Math.random() * 100 },
          { id: 3, timestamp: "16:00", value: Math.random() * 100 },
        ];

        // **計算總計、最大值、最小值**
        const values = tableData.value.map((d) => d.value);
        const total = values.reduce((sum, val) => sum + val, 0).toFixed(2);
        const max = Math.max(...values).toFixed(2);
        const min = Math.min(...values).toFixed(2);

        summaries.value = [
          { name: "總計", value: `${total} kWh` },
          { name: "最大值", value: `${max} kWh` },
          { name: "最小值", value: `${min} kWh` },
        ];

        loading.value = false;
      }, 1000);
    };

    onMounted(fetchData);

    return {
      selectedReportType,
      today,
      startDate,
      endDate,
      selectedMonth,
      selectedYear,
      monthOptions,
      yearOptions,
      fetchData,
      tableData,
      columns,
      summaries,
      loading,
      reportDescription,
    };
  },
};
</script>

<style>
.chart-title {
  font-size: 18px;
  font-weight: bold;
}
</style>
