<template>
  <q-page class="q-pa-md">
    <!-- 手動刷新按鈕 -->
    <q-btn
      label="手動刷新進度"
      color="primary"
      @click="fetchProgressLogs"
      class="q-mt-md"
    />

    <!-- 自動刷新控制按鈕 -->
    <q-btn
      label="開始自動更新"
      color="secondary"
      @click="startAutoRefresh"
      class="q-mt-md"
    />

    <q-btn
      label="停止自動更新"
      color="negative"
      @click="stopAutoRefresh"
      class="q-mt-md"
    />

    <!-- 資料庫創建狀態 -->
    <q-card class="q-mb-md">
      <q-card-section>
        <div class="text-h6">資料庫創建狀態</div>
        <q-scroll-area style="height: 200px">
          <q-list bordered>
            <q-item
              v-for="(log, index) in databaseCreationLogs"
              :key="'db-' + index"
            >
              <q-item-section>
                <q-chip color="blue" text-color="white">{{ log }}</q-chip>
              </q-item-section>
            </q-item>
          </q-list>
        </q-scroll-area>
      </q-card-section>
    </q-card>

    <!-- 數據加總狀態 -->
    <q-card class="q-mb-md">
      <q-card-section>
        <div class="text-h6">數據加總狀態</div>
        <q-scroll-area style="height: 200px">
          <q-list bordered>
            <q-item
              v-for="(log, index) in dataSummarizationLogs"
              :key="'sum-' + index"
            >
              <q-item-section>
                <q-chip color="green" text-color="white">{{ log }}</q-chip>
              </q-item-section>
            </q-item>
          </q-list>
        </q-scroll-area>
      </q-card-section>
    </q-card>

    <!-- 最後處理時間戳 -->
    <q-card class="q-mb-md">
      <q-card-section>
        <div class="text-h6">最後處理時間戳</div>
        <q-scroll-area style="height: 100px">
          <q-list bordered>
            <q-item
              v-for="(log, index) in lastProcessedTimeLogs"
              :key="'time-' + index"
            >
              <q-item-section>
                <q-chip color="orange" text-color="white">{{ log }}</q-chip>
              </q-item-section>
            </q-item>
          </q-list>
        </q-scroll-area>
      </q-card-section>
    </q-card>
  </q-page>
</template>

<script>
export default {
  data() {
    return {
      databaseCreationLogs: [], // 資料庫創建日誌
      dataSummarizationLogs: [], // 數據加總日誌
      lastProcessedTimeLogs: [], // 最後處理時間戳日誌
      autoRefreshInterval: null,
    };
  },
  async mounted() {
    this.fetchProgressLogs(); // 頁面載入後立即加載一次數據
  },
  methods: {
    // 從後端API獲取進度日誌並分類
    async fetchProgressLogs() {
      try {
        const response = await this.$axios.get(
          "http://localhost:5234/api/kwh-summary/processing-progress"
        );
        const logs = response.data;

        // 分類日誌
        this.databaseCreationLogs = logs.filter(
          (log) => log.includes("創建表") || log.includes("表已存在")
        );
        this.dataSummarizationLogs = logs.filter(
          (log) => log.includes("加總") || log.includes("插入成功")
        );
        this.lastProcessedTimeLogs = logs.filter((log) =>
          log.includes("最後處理時間戳")
        );
      } catch (error) {
        console.error("無法獲取處理進度:", error);
        this.$q.notify({
          color: "negative",
          position: "top",
          message: "無法獲取處理進度，請稍後再試",
          icon: "warning",
        });
      }
    },

    // 開始自動刷新
    startAutoRefresh() {
      if (!this.autoRefreshInterval) {
        this.autoRefreshInterval = setInterval(() => {
          this.fetchProgressLogs();
        }, 5000); // 每 5 秒自動刷新一次
      }
    },

    // 停止自動刷新
    stopAutoRefresh() {
      if (this.autoRefreshInterval) {
        clearInterval(this.autoRefreshInterval);
        this.autoRefreshInterval = null;
      }
    },
  },
  beforeUnmount() {
    // 組件銷毀時停止自動刷新
    if (this.autoRefreshInterval) {
      clearInterval(this.autoRefreshInterval);
    }
  },
};
</script>
