<!-- src/pages/TestPage.vue -->
<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="text-h6">Development Page</div>
        <div>功能開發中</div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script setup></script>
