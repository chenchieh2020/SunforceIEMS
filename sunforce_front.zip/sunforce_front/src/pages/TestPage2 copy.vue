<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇用電種類"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card>
      <q-card-section class="chart-header">
        <div class="chart-title">區域分類用電長條圖</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <canvas ref="chart"></canvas>
      </q-card-section>
    </q-card>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import {
  Chart,
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";
import { Dark } from "quasar";

Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

const chart = ref(null);
let chartInstance = null;

const generateTimeLabels = () => {
  const labels = [];
  for (let hour = 0; hour < 24; hour++) {
    labels.push(`${String(hour).padStart(2, "0")}:00`);
    labels.push(`${String(hour).padStart(2, "0")}:30`);
  }
  return labels;
};

const getChartData = () => {
  return {
    labels: generateTimeLabels(),
    datasets: [
      {
        label: "區域A",
        data: Array(48)
          .fill()
          .map(() => Math.floor(Math.random() * 100) + 20),
        backgroundColor: "rgba(16, 54, 117, 0.2)",
        borderColor: "rgba(16, 54, 117, 1)",
        borderWidth: 1,
      },
      {
        label: "區域B",
        data: Array(48)
          .fill()
          .map(() => Math.floor(Math.random() * 100) + 20),
        backgroundColor: "rgba(19,154,218, 0.2)",
        borderColor: "rgba(19,154,218, 1)",
        borderWidth: 1,
      },
      {
        label: "區域C",
        data: Array(48)
          .fill()
          .map(() => Math.floor(Math.random() * 100) + 20),
        backgroundColor: "rgba(235,198,67, 0.2)",
        borderColor: "rgba(235,198,67, 1)",
        borderWidth: 1,
      },
      {
        label: "區域D",
        data: Array(48)
          .fill()
          .map(() => Math.floor(Math.random() * 100) + 20),
        backgroundColor: "rgba(246,104,8, 0.2)",
        borderColor: "rgba(246,104,8, 1)",
        borderWidth: 1,
      },
    ],
  };
};

const getChartOptions = (isDark) => {
  const gridColor = isDark ? "rgba(255, 255, 255, 0.1)" : "rgba(0, 0, 0, 0.1)";
  const textColor = isDark ? "#ffffff" : "#666666";

  return {
    responsive: true,
    scales: {
      x: {
        stacked: true,
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
      y: {
        stacked: true,
        beginAtZero: true,
        grid: {
          color: gridColor,
        },
        ticks: {
          color: textColor,
        },
      },
    },
    plugins: {
      legend: {
        position: "top",
        labels: {
          color: textColor,
        },
      },
      tooltip: {
        backgroundColor: isDark
          ? "rgba(0, 0, 0, 0.8)"
          : "rgba(255, 255, 255, 0.8)",
        titleColor: isDark ? "#ffffff" : "#000000",
        bodyColor: isDark ? "#ffffff" : "#000000",
        borderColor: isDark ? "rgba(255, 255, 255, 0.2)" : "rgba(0, 0, 0, 0.2)",
        borderWidth: 1,
      },
    },
  };
};

const initChart = () => {
  if (chartInstance) {
    chartInstance.destroy();
  }

  const isDark = Dark.isActive;

  chartInstance = new Chart(chart.value, {
    type: "bar",
    data: getChartData(),
    options: getChartOptions(isDark),
  });
};

// 監聽暗色模式變化
watch(
  () => Dark.isActive,
  (isDark) => {
    initChart();
  }
);

onMounted(() => {
  initChart();
});

// 選擇框相關
const selectedOption1 = ref(null);
const selectedOption2 = ref(null);

const options1 = [
  { label: "台灣化學纖維股份有限公司", value: "1-1" },
  { label: "台灣電力股份有限公司", value: "1-2" },
  { label: "台灣高速鐵路股份有限公司", value: "1-3" },
];

const options2 = [
  { label: "空調用電", value: "2-1" },
  { label: "照明用電", value: "2-2" },
  { label: "動力用電", value: "2-3" },
  { label: "空壓用電", value: "2-4" },
];

const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
  });
};
</script>

<style scoped>
.q-tabs {
  display: flex;
  align-items: center;
}

.chart-title {
  font-weight: bold;
  font-size: 1.2rem;
}

.chart-container {
  width: 100%;
}

.col-25 {
  width: 25%;
}
</style>
