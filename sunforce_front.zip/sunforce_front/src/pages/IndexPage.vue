<!-- src/pages/TestPage.vue -->
<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇區域(第一層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption3"
              :options="options3"
              label="選擇區域(第二層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="text-subtitle1">每日即時用電趨勢圖</div>
        <div class="text-h5">{{ currentDailyUsage }} kWh</div>
      </q-card-section>
      <q-card-section>
        <div
          class="blue-background flex flex-wrap justify-around items-center"
          style="width: 100%"
        >
          <line-chart :data="usageData" />
        </div>
      </q-card-section>
    </q-card>
  </div>

  <div class="q-pa-md updown-page">
    <q-card
      class="q-mb-md updown-card"
      style="width: 100%; width: 48%; height: 150px; margin: 5px"
    >
      <q-card-section class="text-center bg-grey-3 q-pa-none">
        <div class="text-h6 q-py-sm">總用電度數</div>
      </q-card-section>
      <q-card-section>
        <div class="row items-center text-center q-mb-sm">
          <div class="col text-subtitle2">本月目前累積</div>
          <div class="col text-subtitle2">同比</div>
          <div class="col text-subtitle2">目標數值</div>
          <div class="col text-subtitle2">較上月</div>
        </div>
        <div class="row items-center text-center">
          <div class="col text-h4 text-bold">6603.8</div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_upward" color="red" />
            2.1%
          </div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_upward" color="red" />
            0.6%
          </div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_downward" color="green" />
            0.8%
          </div>
        </div>
      </q-card-section>
    </q-card>

    <q-card
      class="q-mb-md updown-card"
      style="width: 100%; width: 48%; height: 150px; margin: 5px"
    >
      <q-card-section class="text-center bg-grey-3 q-pa-none">
        <div class="text-h6 q-py-sm">總EUI指標 kWh/m2</div>
      </q-card-section>
      <q-card-section>
        <div class="row items-center text-center q-mb-sm">
          <div class="col text-subtitle2">本月目前累積</div>
          <div class="col text-subtitle2">同比</div>
          <div class="col text-subtitle2">目標數值</div>
          <div class="col text-subtitle2">較上月</div>
        </div>
        <div class="row items-center text-center">
          <div class="col text-h4 text-bold">6.6</div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_upward" color="red" />
            0.1%
          </div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_upward" color="red" />
            1.1%
          </div>
          <div class="col text-h6 text-bold">
            <q-icon name="arrow_upward" color="red" />
            0.8%
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>

  <div class="q-pa-md">
    <q-card class="Percentage">
      <q-card-section class="chart-header">
        <div class="chart-title">本月分類用電百分比圖</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <div class="chart-container">
          <canvas ref="chart"></canvas>
        </div>
      </q-card-section>
    </q-card>
  </div>

  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div
          class="blue-background flex flex-wrap justify-around items-center"
          style="width: 100%"
        >
          <PieChart title="總用電區域佔比" :chartData="chartData1" />
          <PieChart title="空調用電區域佔比" :chartData="chartData2" />
          <PieChart title="照明用電區域佔比" :chartData="chartData3" />
          <PieChart title="動力用電區域佔比" :chartData="chartData4" />
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import PieChart from "src/components/PieChart.vue";
import LineChart from "src/components/LineChart.vue";
import {
  Chart,
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

Chart.register(
  BarController,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
);

const selectedOption1 = ref(null);
const selectedOption2 = ref(null);
const selectedOption3 = ref(null);

const options1 = [
  { label: "台灣化學纖維股份有限公司", value: "1-1" },
  { label: "台灣電力股份有限公司", value: "1-2" },
  { label: "台灣高速鐵路股份有限公司", value: "1-3" },
];

const options2 = [
  { label: "全廠", value: "2-1" },
  { label: "新港廠", value: "2-2" },
  { label: "麥寮廠", value: "2-3" },
  { label: "龍德廠", value: "2-4" },
];

const options3 = [
  { label: "全區", value: "3-1" },
  { label: "區域A", value: "3-2" },
  { label: "區域B", value: "3-3" },
  { label: "區域C", value: "3-4" },
];

const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
    option3: selectedOption3.value,
  });
};

defineOptions({
  name: "IndexPage",
});

const chartData1 = {
  labels: ["區域A", "區域B", "區域C"],
  datasets: [
    {
      data: [300, 50, 100],
      backgroundColor: ["#0072B2", "#E69F00", "#009E73"],
      hoverBackgroundColor: ["#0072B2", "#E69F00", "#009E73"],
    },
  ],
};

const chartData2 = {
  labels: ["區域A", "區域B", "區域C"],
  datasets: [
    {
      data: [200, 150, 50],
      backgroundColor: ["#0072B2", "#E69F00", "#009E73"],
      hoverBackgroundColor: ["#0072B2", "#E69F00", "#009E73"],
    },
  ],
};

const chartData3 = {
  labels: ["區域A", "區域B", "區域C"],
  datasets: [
    {
      data: [50, 150, 200],
      backgroundColor: ["#0072B2", "#E69F00", "#009E73"],
      hoverBackgroundColor: ["#0072B2", "#E69F00", "#009E73"],
    },
  ],
};

const chartData4 = {
  labels: ["區域A", "區域B", "區域C"],
  datasets: [
    {
      data: [120, 80, 150],
      backgroundColor: ["#0072B2", "#E69F00", "#009E73"],
      hoverBackgroundColor: ["#0072B2", "#E69F00", "#009E73"],
    },
  ],
};

const chart = ref(null);

const chartData = ref({
  labels: ["用電種類"],
  datasets: [
    {
      label: "空調用電",
      data: [57], // 百分比數據
      backgroundColor: "rgba(0, 114, 178, 0.4)",
      borderColor: "rgba(0, 114, 178, 1)",
      borderWidth: 1,
    },
    {
      label: "照明用電",
      data: [25], // 百分比數據
      backgroundColor: "rgba(240, 228, 66, 0.4)",
      borderColor: "rgba(240, 228, 66, 1)",
      borderWidth: 1,
    },
    {
      label: "動力用電",
      data: [3], // 百分比數據
      backgroundColor: "rgba(230, 159, 0, 0.4)",
      borderColor: "rgba(230, 159, 0, 1)",
      borderWidth: 1,
    },
    {
      label: "插座用電",
      data: [15], // 百分比數據
      backgroundColor: "rgba(0, 158, 115,  0.4)",
      borderColor: "rgba(0, 158, 115,  1)",
      borderWidth: 1,
    },
  ],
});

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false, // 允許自定義高度
  indexAxis: "y",
  scales: {
    x: {
      beginAtZero: true,
      stacked: true,
      title: {
        display: true,
        text: "百分比 (%)",
      },
    },
    y: {
      stacked: true,
      display: false, // 隱藏Y軸標籤
    },
  },
  plugins: {
    legend: {
      position: "top",
    },
    tooltip: {
      callbacks: {
        label: function (tooltipItem) {
          return tooltipItem.dataset.label + ": " + tooltipItem.raw + "%";
        },
      },
    },
  },
};

let myChart = null;

onMounted(() => {
  myChart = new Chart(chart.value, {
    type: "bar",
    data: chartData.value,
    options: chartOptions,
  });
});
</script>

<script>
export default {
  components: {
    LineChart,
  },
  data() {
    return {
      currentDailyUsage: 245, // 示例數值（每日目前累積用電量）
      usageData: {
        labels: [
          "00:00",
          "00:15",
          "00:30",
          "00:45",
          "01:00",
          "01:15",
          "01:30",
          "01:45",
          "02:00",
          "02:15",
          "02:30",
          "02:45",
          "03:00",
          "03:15",
          "03:30",
          "03:45",
          "04:00",
          "04:15",
          "04:30",
          "04:45",
          "05:00",
          "05:15",
          "05:30",
          "05:45",
          "06:00",
          "06:15",
          "06:30",
          "06:45",
          "07:00",
          "07:15",
          "07:30",
          "07:45",
          "08:00",
          "08:15",
          "08:30",
          "08:45",
          "09:00",
          "09:15",
          "09:30",
          "09:45",
          "10:00",
          "10:15",
          "10:30",
          "10:45",
          "11:00",
          "11:15",
          "11:30",
          "11:45",
          "12:00",
          "12:15",
          "12:30",
          "12:45",
          "13:00",
          "13:15",
          "13:30",
          "13:45",
          "14:00",
          "14:15",
          "14:30",
          "14:45",
          "15:00",
          "15:15",
          "15:30",
          "15:45",
          "16:00",
          "16:15",
          "16:30",
          "16:45",
          "17:00",
          "17:15",
          "17:30",
          "17:45",
          "18:00",
          "18:15",
          "18:30",
          "18:45",
          "19:00",
          "19:15",
          "19:30",
          "19:45",
          "20:00",
          "20:15",
          "20:30",
          "20:45",
          "21:00",
          "21:15",
          "21:30",
          "21:45",
          "22:00",
          "22:15",
          "22:30",
          "22:45",
          "23:00",
          "23:15",
          "23:30",
          "23:45",
        ],
        datasets: [
          {
            label: "用電量 (kWh)",
            backgroundColor: "rgba(75, 192, 192, 0.2)",
            borderColor: "rgba(75, 192, 192, 1)",
            borderWidth: 1,
            data: [
              12,
              11,
              11,
              10,
              10,
              9,
              9,
              8, // 凌晨
              8,
              7,
              7,
              6,
              6,
              5,
              5,
              4, // 清晨
              5,
              6,
              7,
              8,
              9,
              10,
              11,
              12, // 上午
              13,
              14,
              15,
              16,
              17,
              18,
              19,
              20, // 中午
              21,
              22,
              23,
              24,
              25,
              26,
              27,
              28, // 下午
              29,
              30,
              31,
              32,
              33,
              34,
              35,
              36, // 傍晚
              37,
              38,
              39,
              40,
              41,
              42,
              43,
              44, // 晚上
              42,
              40,
              38,
              36,
              34,
              32,
              30,
              28, // 晚間
              26,
              24,
              22,
              20,
              18,
              16,
              14,
              12, // 深夜
            ], // 示例數據（每 15 分鐘用電量）
          },
        ],
      },
    };
  },
};
</script>

<style>
.col-25 {
  width: 25%;
}

.chart-container {
  width: 23%;
}

@media (max-width: 800px) {
  .chart-container {
    width: 100% !important;
  }
}

.linechart {
  height: 150px;
}

.updown-page {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  min-height: auto !important;
}

.updown-card {
  flex: 1 1 calc(50% - 1rem);
  width: 48%;
  height: 150px;
}

@media (max-width: 600px) {
  .updown-card {
    flex: 1 1 100%;
    max-width: 100%;
    height: 150px;
  }
}
.Percentage .chart-header {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 16px;
}

.Percentage .chart-title {
  font-size: 18px;
  font-weight: bold;
}

.Percentage .chart-container {
  position: relative;
  width: 100%;
  height: 100px;
}
</style>
