<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md items-center">
          <q-space />
          <q-col cols="auto">
            <q-btn
              label="+ 新增 COP 資料"
              color="deep-orange"
              @click="openAddDialog"
              unelevated
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>

    <!-- 資料列表 -->
    <q-card class="q-mt-md">
      <q-table
        :rows="copConfigs"
        :columns="columns"
        row-key="copConfigID"
        :loading="loading"
        flat
        bordered
      >
        <template v-slot:body-cell-actions="props">
          <q-td :props="props" class="q-gutter-sm">
            <q-btn
              flat
              dense
              color="primary"
              icon="edit"
              @click="openEditDialog(props.row)"
            >
              <q-tooltip>編輯</q-tooltip>
            </q-btn>
            <q-btn
              flat
              dense
              color="negative"
              icon="delete"
              @click="confirmDelete(props.row)"
            >
              <q-tooltip>刪除</q-tooltip>
            </q-btn>
          </q-td>
        </template>
      </q-table>
    </q-card>

    <!-- 新增對話框 -->
    <q-dialog v-model="isAddDialogOpen" persistent>
      <q-card style="min-width: 500px">
        <q-card-section>
          <div class="text-h6">新增 COP 資料</div>
        </q-card-section>

        <q-card-section>
          <div class="q-gutter-md">
            <q-input
              v-model="newConfig.dataName"
              label="資料名稱"
              :rules="[(val) => !!val || '請輸入資料名稱']"
            />
            <q-select
              v-model="selectedDevice"
              :options="availableDevices"
              label="關聯Tagname"
              option-label="description"
              :rules="[(val) => !!val || '請選擇Tagname']"
            >
              <template v-slot:option="scope">
                <q-item v-bind="scope.itemProps">
                  <q-item-section>
                    <q-item-label>{{ scope.opt.description }}</q-item-label>
                    <q-item-label caption>{{
                      scope.opt.deviceId
                    }}</q-item-label>
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
            <q-select
              v-model="newConfig.copType"
              :options="copTypes"
              label="COP 資料類型"
              option-label="typeName"
              option-value="typeName"
              emit-value
              map-options
              :rules="[(val) => !!val || '請選擇 COP 類型']"
            />
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn
            flat
            label="儲存"
            color="primary"
            @click="saveCopConfig"
            :loading="saving"
          />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 編輯對話框 -->
    <q-dialog v-model="isEditDialogOpen" persistent>
      <q-card style="min-width: 500px">
        <q-card-section>
          <div class="text-h6">編輯 COP 資料</div>
        </q-card-section>

        <q-card-section>
          <div class="q-gutter-md">
            <q-input
              v-model="editConfig.dataName"
              label="資料名稱"
              :rules="[(val) => !!val || '請輸入資料名稱']"
            />
            <q-select
              v-model="selectedDeviceForEdit"
              :options="availableDevices"
              label="關聯Tagname"
              option-label="description"
              :rules="[(val) => !!val || '請選擇Tagname']"
            >
              <template v-slot:option="scope">
                <q-item v-bind="scope.itemProps">
                  <q-item-section>
                    <q-item-label>{{ scope.opt.description }}</q-item-label>
                    <q-item-label caption>{{
                      scope.opt.deviceId
                    }}</q-item-label>
                  </q-item-section>
                </q-item>
              </template>
            </q-select>
            <q-select
              v-model="editConfig.copType"
              :options="copTypes"
              label="COP 資料類型"
              option-label="typeName"
              option-value="typeName"
              emit-value
              map-options
              :rules="[(val) => !!val || '請選擇 COP 類型']"
            />
          </div>
        </q-card-section>

        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="儲存" color="primary" @click="updateConfig" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useQuasar } from "quasar";
import axios from "axios";

const $q = useQuasar();
const API_BASE_URL = "http://localhost:5234/api";

// 狀態
const loading = ref(false);
const saving = ref(false);
const isAddDialogOpen = ref(false);
const isEditDialogOpen = ref(false);
const copConfigs = ref([]);
const availableDevices = ref([]);
const copTypes = ref([]);

// 新增配置物件
const selectedDevice = ref(null);
const newConfig = ref({
  dataName: "",
  copType: "",
});

// 編輯配置物件
const selectedDeviceForEdit = ref(null);
const editConfig = ref({
  copConfigId: null,
  dataName: "",
  copType: "",
  deviceId: "",
  description: "",
});

// 表格欄位定義
const columns = [
  { name: "copConfigId", label: "ID", field: "copConfigId", sortable: true },
  { name: "dataName", label: "資料名稱", field: "dataName", sortable: true },
  {
    name: "copTypeName",
    label: "COP 類型",
    field: "copTypeName",
    sortable: true,
  },
  { name: "deviceId", label: "設備 ID", field: "deviceId", sortable: true },
  { name: "description", label: "描述", field: "description", sortable: true },
  { name: "actions", label: "操作", field: "actions", align: "center" },
];

// API 調用函數
const fetchAvailableDevices = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/cop/available-devices`);
    availableDevices.value = response.data;
  } catch (error) {
    console.error("Failed to fetch devices:", error);
    $q.notify({
      type: "negative",
      message: "載入設備列表失敗",
      position: "center",
    });
  }
};

const fetchCopTypes = async () => {
  try {
    const response = await axios.get(`${API_BASE_URL}/cop/types`);
    copTypes.value = response.data;
  } catch (error) {
    console.error("Failed to fetch COP types:", error);
    $q.notify({
      type: "negative",
      message: "載入 COP 類型失敗",
      position: "center",
    });
  }
};

const fetchCopConfigs = async () => {
  loading.value = true;
  try {
    const response = await axios.get(`${API_BASE_URL}/cop/configs`);
    copConfigs.value = response.data;
  } catch (error) {
    console.error("Failed to fetch COP configs:", error);
    $q.notify({
      type: "negative",
      message: "載入配置列表失敗",
      position: "center",
    });
  } finally {
    loading.value = false;
  }
};

// 新增配置
const saveCopConfig = async () => {
  saving.value = true;
  try {
    if (!selectedDevice.value) {
      throw new Error("請選擇設備");
    }

    const configToSave = {
      deviceId: selectedDevice.value.deviceId,
      dataName: newConfig.value.dataName,
      copType: newConfig.value.copType,
      description: selectedDevice.value.description,
    };

    await axios.post(`${API_BASE_URL}/cop/configs`, configToSave);

    $q.notify({
      type: "positive",
      message: "儲存成功",
      position: "center",
    });
    isAddDialogOpen.value = false;
    await fetchCopConfigs();
  } catch (error) {
    console.error("Failed to save COP config:", error);
    const errorMessage = error.response?.data || "儲存失敗";
    $q.notify({
      type: "negative",
      message: errorMessage,
      position: "center",
    });
  } finally {
    saving.value = false;
  }
};

// 更新配置
const updateConfig = async () => {
  try {
    if (!selectedDeviceForEdit.value) {
      throw new Error("請選擇設備");
    }

    const configToUpdate = {
      deviceId: selectedDeviceForEdit.value.deviceId,
      dataName: editConfig.value.dataName,
      copType: editConfig.value.copType,
      description: selectedDeviceForEdit.value.description,
    };

    console.log("Updating config:", configToUpdate);

    await axios.put(
      `${API_BASE_URL}/cop/configs/${editConfig.value.copConfigId}`,
      configToUpdate
    );

    $q.notify({
      type: "positive",
      message: "更新成功",
      position: "center",
    });
    isEditDialogOpen.value = false;
    await fetchCopConfigs();
  } catch (error) {
    console.error("Failed to update COP config:", error);
    let errorMessage = "更新失敗";

    if (error.response) {
      switch (error.response.status) {
        case 400:
          errorMessage = error.response.data || "請檢查輸入的資料是否完整";
          break;
        case 404:
          errorMessage = "找不到要更新的配置";
          break;
        case 500:
          errorMessage = "服務器錯誤，請稍後再試";
          break;
        default:
          errorMessage = error.response.data || "更新失敗";
      }
    }

    $q.notify({
      type: "negative",
      message: errorMessage,
      position: "center",
    });
  }
};

// 刪除配置
const confirmDelete = (row) => {
  $q.notify({
    type: "warning",
    message: `確定要刪除 "${row.dataName}" 的配置嗎？`,
    position: "center",
    timeout: 0,
    actions: [
      {
        label: "否",
        color: "white",
      },
      {
        label: "是",
        color: "negative",
        handler: async () => {
          try {
            loading.value = true;
            await axios.delete(
              `${API_BASE_URL}/cop/configs/${row.copConfigId}`
            );

            $q.notify({
              type: "positive",
              message: "配置已成功刪除",
              position: "center",
            });

            await fetchCopConfigs();
          } catch (error) {
            console.error("Delete error:", error);
            let errorMessage = "刪除失敗";

            if (error.response) {
              switch (error.response.status) {
                case 404:
                  errorMessage = "找不到要刪除的配置";
                  break;
                case 500:
                  errorMessage = "服務器錯誤，請稍後再試";
                  break;
                default:
                  errorMessage = error.response.data?.message || "刪除失敗";
              }
            }

            $q.notify({
              type: "negative",
              message: errorMessage,
              position: "center",
            });
          } finally {
            loading.value = false;
          }
        },
      },
    ],
  });
};

// 打開編輯對話框
const openEditDialog = (row) => {
  editConfig.value = {
    copConfigId: row.copConfigId,
    dataName: row.dataName,
    copType: row.copTypeName,
    deviceId: row.deviceId,
    description: row.description,
  };

  selectedDeviceForEdit.value = {
    deviceId: row.deviceId,
    description: row.description,
  };

  console.log("Opening edit dialog with:", editConfig.value);
  isEditDialogOpen.value = true;
};

// 開啟新增對話框
const openAddDialog = () => {
  selectedDevice.value = null;
  newConfig.value = {
    dataName: "",
    copType: "",
  };
  isAddDialogOpen.value = true;
};

// 初始化
onMounted(async () => {
  await Promise.all([
    fetchAvailableDevices(),
    fetchCopTypes(),
    fetchCopConfigs(),
  ]);
});
</script>
