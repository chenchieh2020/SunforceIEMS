<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇區域(第一層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption3"
              :options="options3"
              label="選擇區域(第二層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="startDate"
              label="開始日期"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="endDate"
              label="結束日期"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <div class="chart-container">
      <q-card flat bordered class="shadow">
        <q-card-section class="chart-header">
          <div class="chart-title">需量分析-峰平谷趨勢圖</div>
        </q-card-section>
        <q-card-section class="q-pa-none">
          <canvas class="FPG" ref="lineChart"></canvas>
        </q-card-section>
      </q-card>
    </div>

    <div class="table-container q-mt-md">
      <q-table
        :rows="rows"
        :columns="columns"
        row-key="date"
        flat
        bordered
        class="shadow"
      >
        <template v-slot:body-cell-date="props">
          <q-td :props="props">{{ props.row.date }}</q-td>
        </template>
        <template v-slot:body-cell-period="props">
          <q-td :props="props">{{ props.row.period }}</q-td>
        </template>
        <template v-slot:body-cell-demand="props">
          <q-td :props="props">{{ props.row.demand }}</q-td>
        </template>
        <template v-slot:body-cell-peakValue="props">
          <q-td :props="props">{{ props.row.peakValue }}</q-td>
        </template>
        <template v-slot:body-cell-time="props">
          <q-td :props="props">{{ props.row.time }}</q-td>
        </template>
      </q-table>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import {
  Chart,
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
  Filler,
  DoughnutController,
  ArcElement,
} from "chart.js";
import { QTable } from "quasar";

Chart.register(
  LineController,
  LineElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Tooltip,
  Legend,
  Filler,
  DoughnutController,
  ArcElement
);
const selectedOption1 = ref(null);
const selectedOption2 = ref(null);
const selectedOption3 = ref(null);

const options1 = [
  { label: "台灣化學纖維股份有限公司", value: "1-1" },
  { label: "台灣電力股份有限公司", value: "1-2" },
  { label: "台灣高速鐵路股份有限公司", value: "1-3" },
];

const options2 = [
  { label: "新港廠", value: "2-1" },
  { label: "麥寮廠", value: "2-2" },
  { label: "龍德廠", value: "2-3" },
];

const options3 = [
  { label: "區域A", value: "3-1" },
  { label: "區域B", value: "3-2" },
  { label: "區域C", value: "3-3" },
];

const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
    option3: selectedOption3.value,
  });
};

const lineChart = ref(null);

const columns = [
  { name: "date", label: "日期", align: "left", field: "date" },
  { name: "period", label: "用電時段", align: "left", field: "period" },
  { name: "demand", label: "需量 (kW)", align: "right", field: "demand" },
  { name: "peakValue", label: "最大值", align: "right", field: "peakValue" },
  { name: "time", label: "時間", align: "left", field: "time" },
];

const rows = [
  {
    date: "2023/07/12",
    period: "峰時段",
    demand: "4,129.00",
    peakValue: "4,129.00",
    time: "08:45",
  },
  {
    date: "2023/07/12",
    period: "平時段",
    demand: "3,810.00",
    peakValue: "3,810.00",
    time: "15:00",
  },
  {
    date: "2023/07/12",
    period: "谷時段",
    demand: "3,075.00",
    peakValue: "3,075.00",
    time: "18:45",
  },
  {
    date: "2023/07/12",
    period: "全時段",
    demand: "4,129.00",
    peakValue: "4,129.00",
    time: "08:45",
  },
];

// Function to generate time labels for every 30 minutes
const generateTimeLabels = () => {
  const labels = [];
  for (let hour = 0; hour < 24; hour++) {
    labels.push(`${String(hour).padStart(2, "0")}:00`);
    labels.push(`${String(hour).padStart(2, "0")}:30`);
  }
  return labels;
};

// Function to generate random but reasonable industrial electricity consumption data
const generateElectricityData = () => {
  const data = [];
  for (let i = 0; i < 48; i++) {
    let value;
    if (i >= 16 && i < 34) {
      // Peak period (08:00 - 17:00)
      value = Math.random() * 1000 + 4000;
    } else if ((i >= 34 && i < 44) || i < 8) {
      // Flat period (17:00 - 22:00)
      value = Math.random() * 500 + 3000;
    } else {
      // Valley period (22:00 - 08:00)
      value = Math.random() * 500 + 2000;
    }
    data.push(value);
  }
  return data;
};

const chartData = {
  labels: generateTimeLabels(),
  datasets: [
    {
      label: "總用電量",
      data: generateElectricityData(), // Simulated industrial electricity consumption data
      borderColor: "rgba(0, 128, 128, 1)",
      borderWidth: 2,
      fill: {
        target: "origin",
      },
      pointBackgroundColor: "rgba(255, 255, 255, 1)",
      pointBorderColor: "rgba(0, 128, 128, 1)",
      pointRadius: 5,
      pointHoverRadius: 7,
      cubicInterpolationMode: "monotone",
    },
    {
      label: "目標需量",
      data: Array(48).fill(3500), // Fixed target demand for illustration
      borderColor: "rgba(246,0,2, 1)",
      borderWidth: 1,
      borderDash: [10, 5],
      pointRadius: 0,
    },
  ],
};

const chartOptions = {
  responsive: true,
  scales: {
    x: {
      beginAtZero: true,
    },
    y: {
      beginAtZero: true,
    },
  },
  plugins: {
    legend: {
      display: true,
      position: "bottom",
    },
    tooltip: {
      mode: "index",
      intersect: false,
      titleFont: {
        family: "Open Sans",
      },
      backgroundColor: "rgba(25,118,210,0.6)",
    },
    custom: {
      id: "custom",
      beforeDraw: (chart) => {
        const {
          ctx,
          chartArea: { top, bottom, left, right },
          scales: { x },
        } = chart;
        ctx.save();

        // Define peak, flat, and valley time ranges
        const ranges = [
          {
            start: 8,
            end: 16,
            color: "rgba(125,47,174, 0.2)",
            label: "峰時段",
          },
          {
            start: 16,
            end: 20,
            color: "rgba(230, 159, 0, 0.2)",
            label: "平時段",
          },
          {
            start: 0,
            end: 8,
            color: "rgba(0, 114, 178, 0.2)",
            label: "谷時段",
          },
          {
            start: 20,
            end: 24,
            color: "rgba(0, 114, 178, 0.2)",
            label: "谷時段",
          },
        ];

        // Draw rectangles for each range
        ranges.forEach((range) => {
          const startPixel = x.getPixelForValue(range.start * 2); // multiply by 2 since we have 30-minute intervals
          const endPixel = x.getPixelForValue(range.end * 2);

          ctx.fillStyle = range.color;
          ctx.fillRect(startPixel, top, endPixel - startPixel, bottom - top);
          ctx.fillStyle = "rgba(0, 0, 0, 1)";
          ctx.fillText(range.label, (startPixel + endPixel) / 2, top + 20);
        });

        ctx.restore();
      },
    },
  },
};

onMounted(() => {
  new Chart(lineChart.value, {
    type: "line",
    data: chartData,
    options: chartOptions,
    plugins: [chartOptions.plugins.custom],
  });
});
</script>

<style scoped>
.chart-container {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.chart-header {
  width: 100%;
  font-size: large;
  color: rgb(0, 0, 0);
  text-align: left;
  padding: 15px;
  box-sizing: border-box;
}

.chart-title {
  margin: 0;
}

.FPG {
  width: 100% !important;
  height: 600px !important;
  padding: 15px;
}

.table-container {
  width: 100%;
  margin-top: 20px;
}

.donut-charts-container {
  display: flex;
  justify-content: space-around;
  margin-top: 20px;
}

.donut-chart {
  width: 25%;
}

.chart-legend {
  text-align: center;
  margin-top: 10px;
}

.chart-legend ul {
  list-style: none;
  padding: 0;
}

.chart-legend li {
  display: flex;
  align-items: center;
  margin: 5px 0;
  font-size: 14px;
}

.legend-color {
  display: inline-block;
  width: 12px;
  height: 12px;
  margin-right: 5px;
  vertical-align: middle;
}
</style>
