<template>
  <div class="q-pa-md">
    <!-- Breadcrumb Navigation -->
    <q-breadcrumbs separator-icon="chevron_right" class="q-mb-md">
      <q-breadcrumbs-el
        icon="home"
        label="客戶管理"
        @click="navigateToCustomerManagement"
      />
      <q-breadcrumbs-el label="區域管理" @click="navigateToRegionManagement" />
      <q-breadcrumbs-el label="設備管理" />
    </q-breadcrumbs>

    <q-card>
      <q-card-section>
        <div class="row q-gutter-md items-center">
          <div class="text-h6">
            設備管理 - {{ customerName }} - {{ regionName }}
          </div>
          <q-space />
          <q-col cols="auto">
            <!-- 新增設備按鈕 -->
            <q-btn
              label="新增設備"
              color="deep-orange"
              @click="openAddDialog"
              unelevated
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>

    <q-page class="q-pa-md">
      <!-- 骨架屏加载 -->
      <q-card v-if="loading">
        <q-card-section>
          <div class="row q-gutter-md">
            <q-col cols="12">
              <q-skeleton type="text" width="80%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="60%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="70%"></q-skeleton>
            </q-col>
          </div>
        </q-card-section>
        <q-skeleton type="rect" height="200px"></q-skeleton>
      </q-card>

      <!-- 設備列表 -->
      <q-table
        v-if="!loading && gateways.length > 0"
        :rows="gateways"
        :columns="columns"
        row-key="gatewayID"
      >
        <template v-slot:body-cell-gatewayModel="props">
          <q-td :props="props">
            <span>{{ props.row.gatewayModel || "未知型號" }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-electricMeters="props">
          <q-td :props="props">
            <q-chip
              v-for="meter in props.row.electricMeters || []"
              :key="meter"
              label-color="primary"
              class="q-ma-xs"
            >
              {{ meter }}
            </q-chip>
          </q-td>
        </template>

        <template v-slot:body-cell-actions="props">
          <q-td :props="props">
            <q-btn
              flat
              @click="openEditDialog(props.row)"
              label="編輯"
              color="primary"
            />
            <q-btn
              flat
              @click="confirmDeleteGateway(props.row.gatewayID)"
              label="刪除"
              color="negative"
            />
          </q-td>
        </template>
      </q-table>

      <!-- 无符合的設備资料 -->
      <div
        v-if="!loading && gateways.length === 0"
        class="q-pa-md q-gutter-md text-center"
      >
        <q-icon name="info" size="56px" color="grey-7" />
        <div class="text-h6 q-mt-md">無設備資料</div>
      </div>
    </q-page>

    <!-- 新增設備对话框 -->
    <q-dialog v-model="isAddDialogOpen" @before-show="fetchElectricMeters">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">新增設備</div>
        </q-card-section>
        <q-card-section>
          <q-input v-model="newGateway.gatewayName" label="設備名稱" required />
          <q-input
            v-model="newGateway.gatewayInstallNumber"
            label="安裝序號"
            required
          />
          <q-select
            placeholder="請選擇設備型號"
            v-model="selectedModelForNewGateway"
            :options="gatewayModels"
            label="設備型號"
            option-value="gatewayModelID"
            option-label="modelName"
            outlined
            dense
            required
            @input="onGatewayModelSelect"
          />
          <q-input
            v-model="selectedModelForNewGateway.gatewayModelID"
            label="設備型號ID"
            outlined
            dense
            readonly
          />
          <q-input
            v-model="selectedModelForNewGateway.modelName"
            label="設備型號名稱"
            outlined
            dense
            readonly
          />

          <q-input
            v-model="newGateway.gatewayInterface"
            label="通訊模組"
            required
          />
          <q-input v-model="newGateway.gatewayNote" label="備註" outlined />

          <q-checkbox
            v-model="newGateway.gatewayInstallStatus"
            label="已安裝"
            :true-value="1"
            :false-value="0"
          />
          <q-checkbox
            v-model="newGateway.gatewayUsingStatus"
            label="使用中"
            :true-value="1"
            :false-value="0"
          />

          <q-input
            v-model="newGateway.gatewayInstallDate"
            label="安裝日期"
            type="date"
          />

          <!-- 电表多选 -->
          <q-select
            v-model="newGateway.selectedElectricMeterIDs"
            :options="electricMeters"
            label="選擇電錶"
            option-value="electricMeterID"
            option-label="electricMeterName"
            outlined
            dense
            multiple
            use-chips
            required
          />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="addGateway" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 编辑設備对话框 -->
    <q-dialog v-model="isEditDialogOpen" @before-show="fetchElectricMeters">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">編輯設備</div>
        </q-card-section>
        <q-card-section>
          <q-input
            v-model="editGateway.gatewayName"
            label="設備名稱"
            required
          />
          <q-input
            v-model="editGateway.gatewayInstallNumber"
            label="安裝序號"
            required
          />
          <q-select
            placeholder="請選擇設備型號"
            v-model="selectedModelForEditGateway"
            :options="gatewayModels"
            label="設備型號"
            option-value="gatewayModelID"
            option-label="modelName"
            outlined
            dense
            required
            @input="onGatewayModelSelectForEdit"
          />
          <q-input
            v-model="selectedModelForEditGateway.gatewayModelID"
            label="設備型號ID"
            outlined
            dense
            readonly
          />
          <q-input
            v-model="selectedModelForEditGateway.modelName"
            label="設備型號名稱"
            outlined
            dense
            readonly
          />
          <q-input
            v-model="editGateway.gatewayInterface"
            label="通訊模組"
            required
          />
          <q-input v-model="editGateway.gatewayNote" label="備註" outlined />

          <q-checkbox
            v-model="editGateway.gatewayInstallStatus"
            label="已安裝"
            :true-value="1"
            :false-value="0"
          />
          <q-checkbox
            v-model="editGateway.gatewayUsingStatus"
            label="使用中"
            :true-value="1"
            :false-value="0"
          />

          <q-input
            v-model="editGateway.gatewayInstallDate"
            label="安裝日期"
            type="date"
          />

          <!-- 电表多选 -->
          <q-select
            v-model="editGateway.selectedElectricMeterIDs"
            :options="electricMeters"
            label="選擇電錶"
            option-value="electricMeterID"
            option-label="electricMeterName"
            outlined
            dense
            multiple
            use-chips
            required
          />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="updateGateway" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useRoute, useRouter } from "vue-router";
import { useQuasar } from "quasar";

const $q = useQuasar();
const route = useRoute();
const router = useRouter();

const regionId = ref(route.params.regionId);
const customerId = ref(route.params.customerId);
const regionName = ref(""); // 用于存储区域名称

const customerName = ref(""); // 用于存储客户名称
const loading = ref(true); // 用于加载状态的显示

const selectedModelForNewGateway = ref({
  gatewayModelID: null,
  modelName: "",
});

const selectedModelForEditGateway = ref({
  gatewayModelID: null,
  modelName: "",
});

const gateways = ref([]);
const gatewayModels = ref([]);
const electricMeters = ref([]);
const isAddDialogOpen = ref(false);
const isEditDialogOpen = ref(false);

// 获取区域名称的函数
const fetchRegionName = async () => {
  try {
    const response = await axios.get(
      `http://localhost:5234/api/CustomerRegions/${regionId.value}`
    );
    if (response.data && response.data.regionName) {
      regionName.value = response.data.regionName; // 假设API返回的区域名称字段为 regionName
      console.log("Region Name Fetched:", regionName.value);
    } else {
      console.warn("Region name is missing from API response.");
    }
  } catch (error) {
    console.error("Failed to fetch region name:", error);
    $q.notify({
      type: "negative",
      message: "無法加載區域名稱",
      position: "center",
    });
  }
};

// 获取客户名称的函数
const fetchCustomerName = async () => {
  try {
    const response = await axios.get(
      `http://localhost:5234/api/customers/${customerId.value}`
    );
    if (response.data && response.data.customerName) {
      customerName.value = response.data.customerName; // 假设API返回的客户名称字段为 customerName
      console.log("Customer Name Fetched:", customerName.value);
    } else {
      console.warn("Customer name is missing from API response.");
    }
  } catch (error) {
    console.error("Failed to fetch customer name:", error);
    $q.notify({
      type: "negative",
      message: "無法加載客戶名稱",
      position: "center",
    });
  }
};

// 初始化数据
onMounted(async () => {
  loading.value = true;
  await Promise.all([fetchRegionName(), fetchCustomerName()]);
  await fetchGateways();
  await fetchGatewayModels();
  loading.value = false;
});

const cancel = () => {
  router.push({
    name: "RegionManagement",
    params: { customerId: route.params.customerId },
  });
};

const navigateToCustomerManagement = () => {
  router.push({ name: "客戶管理" });
};

const navigateToRegionManagement = () => {
  if (!customerId.value) {
    console.error("Missing customerId, cannot navigate to RegionManagement");
    $q.notify({
      type: "negative",
      message: "無法導航到區域管理，缺少客戶ID",
      position: "center",
    });
    return;
  }
  router.push({
    name: "區域管理",
    params: { customerId: customerId.value },
  });
};

const newGateway = ref({
  gatewayName: "",
  gatewayModelID: null, // This should store the selected model ID
  gatewayInstallNumber: "",
  gatewayInterface: "",
  gatewayNote: "",
  gatewayInstallStatus: 0,
  gatewayUsingStatus: 0,
  gatewayInstallDate: "",
  selectedElectricMeterIDs: [],
});

const editGateway = ref({
  gatewayID: null,
  gatewayName: "",
  gatewayModelID: null, // This should store the selected model ID
  gatewayInstallNumber: "",
  gatewayInterface: "",
  gatewayNote: "",
  gatewayInstallStatus: 0,
  gatewayUsingStatus: 0,
  gatewayInstallDate: "",
  selectedElectricMeterIDs: [],
});

const onGatewayModelSelect = (gatewayModelID) => {
  const selectedModel = gatewayModels.value.find(
    (model) => model.gatewayModelID === gatewayModelID
  );
  if (selectedModel) {
    selectedModelForNewGateway.value = {
      gatewayModelID: selectedModel.gatewayModelID,
      modelName: selectedModel.modelName,
    };
  }
};

const onGatewayModelSelectForEdit = (gatewayModelID) => {
  const selectedModel = gatewayModels.value.find(
    (model) => model.gatewayModelID === gatewayModelID
  );
  if (selectedModel) {
    selectedModelForEditGateway.value = {
      gatewayModelID: selectedModel.gatewayModelID,
      modelName: selectedModel.modelName,
    };
    editGateway.value.gatewayModelID = selectedModel.gatewayModelID;
  }
};

const columns = [
  { name: "gatewayName", label: "設備名稱", field: "gatewayName" },
  { name: "gatewayModel", label: "設備型號", field: "gatewayModel" },
  {
    name: "gatewayInstallNumber",
    label: "安裝序號",
    field: "gatewayInstallNumber",
  },
  { name: "gatewayInterface", label: "通訊模組", field: "gatewayInterface" },
  {
    name: "gatewayUsingStatus",
    label: "使用狀態",
    field: "gatewayUsingStatus",
  },
  { name: "electricMeters", label: "所連接的電錶", field: "electricMeters" },
  { name: "actions", label: "操作", field: "actions" },
];

// 取得設備列表
const fetchGateways = async () => {
  try {
    const response = await axios.get(`http://localhost:5234/api/gateways`, {
      params: { regionId: regionId.value },
    });
    if (response.data) {
      gateways.value = response.data.map((gateway) => ({
        ...gateway,
        gatewayModel: gateway.modelName,
        electricMeters: gateway.electricMeters
          ? gateway.electricMeters.map((meter) => meter.electricMeterName)
          : [],
      }));
    }
  } catch (error) {
    console.error("Failed to fetch gateways:", error);
    $q.notify({
      type: "negative",
      message: "無法加載設備資料",
      position: "center",
    });
  } finally {
    loading.value = false;
  }
};

// 獲取所有設備型號
const fetchGatewayModels = async () => {
  try {
    const response = await axios.get("http://localhost:5234/api/GatewayModels");
    console.log("獲取所有設備型號回傳:", response.data); // 在此處檢查回傳的數據
    gatewayModels.value = response.data;
  } catch (error) {
    console.error("Failed to fetch gateway models:", error);
  }
};

// 取得電錶列表（仅在新增或编辑时调用）
const fetchElectricMeters = async () => {
  try {
    const response = await axios.get(
      "http://localhost:5234/api/electricmeters/all-electricmeters"
    );
    if (response.data) {
      electricMeters.value = response.data.map((meter) => ({
        electricMeterID: meter.electricMeterID,
        electricMeterName: meter.electricMeterName,
      }));
      console.log("Electric Meters Fetched:", electricMeters.value);
    } else {
      console.warn("No electric meters data found in API response.");
    }
  } catch (error) {
    console.error("Failed to fetch electric meters:", error);
  }
};

// Function to add a gateway:
const addGateway = async () => {
  try {
    const payload = {
      gatewayName: newGateway.value.gatewayName,
      gatewayModelID: selectedModelForNewGateway.value.gatewayModelID, // Ensure only model ID is sent
      modelName: selectedModelForNewGateway.value.modelName, // Add ModelName to the payload
      gatewayInstallNumber: newGateway.value.gatewayInstallNumber,
      gatewayInterface: newGateway.value.gatewayInterface,
      gatewayNote: newGateway.value.gatewayNote,
      gatewayInstallStatus: newGateway.value.gatewayInstallStatus,
      gatewayUsingStatus: newGateway.value.gatewayUsingStatus,
      gatewayInstallDate: newGateway.value.gatewayInstallDate,
      selectedElectricMeterIDs: newGateway.value.selectedElectricMeterIDs.map(
        (meter) => meter.electricMeterID
      ),
      regionID: regionId.value,
    };

    // Log the payload to inspect its content
    console.log("Payload:", payload);

    const response = await axios.post(
      `http://localhost:5234/api/gateways`,
      payload
    );

    console.log("新增設備回傳結果:", response);

    $q.notify({
      type: "positive",
      message: `設備 ${newGateway.value.gatewayName} 新增成功`,
      position: "center",
    });
    fetchGateways();
    isAddDialogOpen.value = false;
  } catch (error) {
    // Error handling
    console.error("Failed to add gateway:", error);
    $q.notify({
      type: "negative",
      message: `新增設備失敗: ${error.message}`,
      position: "center",
    });
  }
};
// 打开编辑对话框并初始化数据
const openEditDialog = async (gateway) => {
  try {
    // 获取与选定設備相关联的电表
    const response = await axios.get(
      `http://localhost:5234/api/gatewayelectricmeter/${gateway.gatewayID}`
    );

    // 获取所有电表信息
    await fetchElectricMeters();

    // 将获取到的电表ID转换为包含ID和名称的对象
    const selectedMeters = response.data.map((gem) => {
      const meter = electricMeters.value.find(
        (m) => m.electricMeterID === gem.electricMeterID
      );
      return {
        electricMeterID: gem.electricMeterID,
        electricMeterName: meter
          ? meter.electricMeterName
          : `Unknown Meter (ID: ${gem.electricMeterID})`,
      };
    });

    // 更新 editGateway 的值
    editGateway.value = {
      ...gateway,
      gatewayID: gateway.gatewayID,
      selectedElectricMeterIDs: selectedMeters, // 现在存储的是包含 ID 和名称的对象数组
    };

    // 初始化用于编辑的选定模型
    const selectedModel = gatewayModels.value.find(
      (model) => model.gatewayModelID === gateway.gatewayModelID
    );

    if (selectedModel) {
      selectedModelForEditGateway.value = {
        gatewayModelID: selectedModel.gatewayModelID,
        modelName: selectedModel.modelName,
      };
    } else {
      selectedModelForEditGateway.value = {
        gatewayModelID: null,
        modelName: "",
      };
    }

    isEditDialogOpen.value = true;
  } catch (error) {
    console.error("Failed to fetch associated electric meters:", error);
    $q.notify({
      type: "negative",
      message: "無法加載電表資料",
      position: "center",
    });
  }
};

// Function to update the gateway:
const updateGateway = async () => {
  try {
    const payload = {
      gatewayID: editGateway.value.gatewayID,
      gatewayName: editGateway.value.gatewayName,
      gatewayModelID: selectedModelForEditGateway.value.gatewayModelID,
      gatewayInstallNumber: editGateway.value.gatewayInstallNumber,
      gatewayInterface: editGateway.value.gatewayInterface,
      gatewayNote: editGateway.value.gatewayNote,
      gatewayInstallStatus: editGateway.value.gatewayInstallStatus,
      gatewayUsingStatus: editGateway.value.gatewayUsingStatus,
      gatewayInstallDate: editGateway.value.gatewayInstallDate,
      selectedElectricMeterIDs: editGateway.value.selectedElectricMeterIDs.map(
        (meter) => meter.electricMeterID
      ),
      regionID: regionId.value,
    };

    console.log("Update Payload:", payload);

    await axios.put(
      `http://localhost:5234/api/gateways/${editGateway.value.gatewayID}`,
      payload
    );

    $q.notify({
      type: "positive",
      message: "編輯設備成功",
      position: "center",
    });
    fetchGateways();
    isEditDialogOpen.value = false;
  } catch (error) {
    console.error(
      "Failed to update gateway:",
      error.response ? error.response.data : error.message
    );
    $q.notify({
      type: "negative",
      message: `編輯設備失敗: ${
        error.response ? error.response.data : error.message
      }`,
      position: "center",
    });
  }
};

// 打开新增对话框并重置新設備数据
const openAddDialog = () => {
  newGateway.value = {
    gatewayName: "",
    gatewayModel: null,
    gatewayInstallNumber: "",
    gatewayInterface: "",
    gatewayNote: "",
    gatewayInstallStatus: 0,
    gatewayUsingStatus: 0,
    gatewayInstallDate: "",
    selectedElectricMeterIDs: [],
  };
  fetchElectricMeters();
  isAddDialogOpen.value = true;
};

// 刪除設備
const confirmDeleteGateway = (gatewayID) => {
  $q.dialog({
    title: "確認刪除",
    message: "您確定要刪除此設備及其所有相關記錄嗎？這個操作無法撤銷。",
    ok: {
      label: "刪除",
      color: "negative",
    },
    cancel: {
      label: "取消",
      flat: true,
    },
  }).onOk(async () => {
    try {
      await axios.delete(`http://localhost:5234/api/gateways/${gatewayID}`);
      $q.notify({
        type: "positive",
        message: "刪除設備成功",
        position: "center",
      });
      fetchGateways();
    } catch (error) {
      console.error("Failed to delete gateway:", error);
      $q.notify({
        type: "negative",
        message: "刪除設備失敗",
        position: "center",
      });
    }
  });
};
</script>
