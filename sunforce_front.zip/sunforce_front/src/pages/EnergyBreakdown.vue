<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="pointOption"
              label="選擇點位項目"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="pointOption"
              label="選擇點位項目"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="startDate"
              label="開始日期"
              mask="####-##-##"
              type="date"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="endDate"
              label="結束日期"
              mask="####-##-##"
              type="date"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card>
      <q-card-section class="chart-header">
        <div class="chart-title">能耗分項分析圖</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <canvas ref="chartCanvas"></canvas>
      </q-card-section>
    </q-card>
  </div>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import {
  Chart,
  registerables,
} from "chart.js";
import { Dark } from "quasar";

Chart.register(...registerables)

const chartCanvas = ref(null);
const startDate = ref(getTodayDateString());
const endDate = ref(getTodayDateString());


function getTodayDateString() {
  const today = new Date()
  const yyyy = today.getFullYear()
  const mm = String(today.getMonth() + 1).padStart(2, '0') // 月份從 0 開始，要 +1
  const dd = String(today.getDate()).padStart(2, '0')
  return `${yyyy}-${mm}-${dd}`
}

watch(
  [startDate, endDate],
  () => {
    console.log("日期變化", {
      startDate: startDate.value,
      endDate: endDate.value,
    });
  },
  { immediate: true }
);

onMounted(() => {
  const ctx = chartCanvas.value.getContext('2d')

  const myChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['5/1', '5/2', '5/3', '5/4', '5/5', '5/6', '5/7'],
      datasets: [
        {
          label: '發電量 (kWh)',
          data: [90, 120, 110, 130, 115, 140, 110],
          yAxisID: 'y',
          borderColor: 'rgba(255, 99, 132, 1)',
          backgroundColor: 'rgba(255, 99, 132, 0.2)',
        },
        {
          label: '用電量 (kWh)',
          data: [110, 135, 122, 140, 144, 138, 100],
          yAxisID: 'y1',
          borderColor: 'rgba(54, 162, 235, 1)',
          backgroundColor: 'rgba(54, 162, 235, 0.2)',
        }
      ]
    },
    options: {
      responsive: true,
      interaction: {
        mode: 'index',
        intersect: false
      },
      stacked: false,
      scales: {
        y: {
          type: 'linear',
          position: 'left',
          title: {
            display: true,
            text: '發電量 (kWh)'
          }
        },
        y1: {
          type: 'linear',
          position: 'right',
          title: {
            display: true,
            text: '用電量 (kWh)'
          },
          grid: {
            drawOnChartArea: false
          }
        }
      }
    }
  })
});

// 選擇框相關
const selectedOption1 = ref(null);
const selectedOption2 = ref(null);

const pointOption = [
  { label: "a", value: "1-1" },
  { label: "CADIS幸福發電站", value: "1-2" },
  { label: "COSTCO1發電站", value: "1-3" },
  { label: "COSTCO2發電站", value: "1-4" },
  { label: "COSTCO3發電站", value: "1-5" },
  { label: "COSTCO4發電站", value: "1-6" },
  { label: "COSTCO5發電站", value: "1-7" },
  { label: "FCFC1發電站", value: "1-8" },
  { label: "FCFC2發電站", value: "1-9" },
  { label: "FCFC3發電站", value: "1-10" },
  { label: "一樓A區電錶", value: "1-11" },
  { label: "大立光LP3發電站", value: "1-12" },
  { label: "工南1發電站", value: "1-13" },
  { label: "工南2發電站", value: "1-14" },
  { label: "工南3發電站", value: "1-15" },
  { label: "工南4發電站", value: "1-16" },
  { label: "中油台中1發電站", value: "1-17" },
  { label: "中油台中2發電站", value: "1-18" },
  { label: "中油民雄發電站", value: "1-19" },
  { label: "中油綠能發電站", value: "1-20" },
  { label: "太陽光電發電站", value: "1-21" },
  { label: "太陽能發電  A", value: "1-22" },
  { label: "太陽能發電  B", value: "1-23" },
  { label: "台達中壢5A發電站", value: "1-24" },
  { label: "台達中壢5B發電站", value: "1-25" },
  { label: "台達北瑞光發電站", value: "1-26" },
  { label: "台達台中發電站", value: "1-27" },
  { label: "台達桃二廠發電站", value: "1-28" },
  { label: "台達桃五廠發電站", value: "1-29" },
  { label: "正皓造紙01發電站", value: "1-30" },
  { label: "正隆后里1發電站", value: "1-31" },
  { label: "正隆后里2發電站", value: "1-32" },
  { label: "正隆后里3發電站", value: "1-33" },
  { label: "旭威台化1發電站", value: "1-34" },
  { label: "旭威台化2發電站", value: "1-35" },
  { label: "旭威台化3發電站", value: "1-36" },
  { label: "旭威台化4發電站", value: "1-37" },
  { label: "旭威台化5發電站", value: "1-38" },
  { label: "百合Q棟發電站", value: "1-39" },
  { label: "百合T棟發電站", value: "1-40" },
  { label: "佐登妮絲發電站", value: "1-41" },
  { label: "宏達電桃園發電站", value: "1-42" },
  { label: "和泰楊梅發電站", value: "1-43" },
  { label: "明徽能源1發電站", value: "1-44" },
  { label: "明徽能源2發電站", value: "1-45" },
  { label: "明徽能源3發電站", value: "1-46" },
  { label: "明徽能源4發電站", value: "1-47" },
  { label: "東豐2發電站", value: "1-48" },
  { label: "東豐3發電站", value: "1-49" },
  { label: "南亞新港1發電站", value: "1-50" },
  { label: "南亞嘉義32發電站", value: "1-51" },
  { label: "南亞嘉義33發電站", value: "1-52" },
  { label: "南亞嘉義34發電站", value: "1-53" },
  { label: "南亞嘉義3發電站", value: "1-54" },
  { label: "南亞機工發電站", value: "1-55" },
  { label: "屏東國壽01發電站", value: "1-56" },
  { label: "屏東國壽02發電站", value: "1-57" },
  { label: "屏東國壽03發電站", value: "1-58" },
  { label: "屏東國壽04發電站", value: "1-59" },
  { label: "英特盛03發電站", value: "1-60" },
  { label: "英特盛04發電站", value: "1-61" },
  { label: "英業達桃科發電站", value: "1-62" },
  { label: "昶瑞機電發電站", value: "1-63" },
  { label: "高偉精密1_累計發電量.LastValue", value: "1-64" },
  { label: "高偉精密1發電站", value: "1-65" },
  { label: "高偉精密2發電站", value: "1-66" },
  { label: "捷亮科技發電站", value: "1-67" },
  { label: "發電機 01", value: "1-68" },
  { label: "菁華1大園發電站", value: "1-69" },
  { label: "菁華2大園發電站", value: "1-70" },
  { label: "菁華3大園發電站", value: "1-71" },
  { label: "菁華4大園發電站", value: "1-72" },
  { label: "集合式數位電錶", value: "1-73" },
  { label: "誠美材1發電站", value: "1-74" },
  { label: "誠美材2發電站", value: "1-75" },
  { label: "農友種苗1發電站", value: "1-76" },
  { label: "農友種苗2發電站", value: "1-77" },
  { label: "僑雄實業發電站", value: "1-78" },
  { label: "需量總電錶", value: "1-79" },
  { label: "澎科大1發電站", value: "1-80" },
  { label: "澎科大3發電站", value: "1-81" },
  { label: "澎科大4發電站", value: "1-82" },
  { label: "澎科大5發電站", value: "1-83" },
  { label: "澎科大6發電站", value: "1-84" },
  { label: "鴻海精密發電站", value: "1-85" }
]


const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
  });
};
</script>

<style scoped>
.q-tabs {
  display: flex;
  align-items: center;
}

.chart-title {
  font-weight: bold;
  font-size: 1.2rem;
}

.chart-container {
  width: 100%;
}

.col-25 {
  width: 25%;
}
</style>
