<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md items-center">
          <q-space />
          <q-col cols="auto">
            <!-- 新增客戶按鈕 -->
            <q-btn
              label="+ 新增客戶"
              color="deep-orange"
              @click="openAddDialog"
              unelevated
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>

    <q-page class="q-pa-md">
      <!-- Skeleton Loader -->
      <q-card v-if="loading">
        <q-card-section>
          <div class="row q-gutter-md">
            <q-col cols="12">
              <q-skeleton type="text" width="80%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="60%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="70%"></q-skeleton>
            </q-col>
          </div>
        </q-card-section>
        <q-skeleton type="rect" height="200px"></q-skeleton>
      </q-card>

      <!-- 客戶列表 -->
      <q-table
        v-if="!loading && customers.length > 0"
        :rows="customers"
        :columns="columns"
        row-key="customerID"
        flat
        bordered
        hide-bottom
        rows-per-page="10"
        class="customer-table"
      >
        <template v-slot:body-cell-CustomerID="props">
          <q-td :props="props">
            <span>{{ props.row.customerID }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-CustomerName="props">
          <q-td :props="props">
            <span>{{ props.row.customerName }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-CustomerTag="props">
          <q-td :props="props">
            <span>{{ props.row.customerTag }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-CreateDate="props">
          <q-td :props="props">
            <span>{{ props.row.createDate }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-actions="props">
          <q-td :props="props">
            <q-btn
              flat
              label="編輯"
              color="primary"
              @click="openEditDialog(props.row)"
            />
            <q-btn
              flat
              label="刪除"
              color="negative"
              @click="confirmDeleteCustomer(props.row)"
            />
            <q-btn
              label="管理區域"
              color="secondary"
              @click="openRegionManagement(props.row)"
            />
          </q-td>
        </template>
      </q-table>

      <!-- 無符合的客戶資料 -->
      <div
        v-if="!loading && customers.length === 0"
        class="q-pa-md q-gutter-md text-center"
      >
        <q-icon name="info" size="56px" color="grey-7" />
        <div class="text-h6 q-mt-md">無客戶資料</div>
      </div>

      <!-- 使用分页组件 -->
      <div
        v-if="!loading && customers.length > 0"
        class="q-pa-lg flex flex-center"
      >
        <q-pagination
          v-model="pagination.page"
          :max="maxPages"
          @update:model-value="onPageChange"
        />
      </div>
    </q-page>

    <!-- 新增客戶對話框 -->
    <q-dialog v-model="isAddDialogOpen">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">新增客戶資訊</div>
        </q-card-section>
        <q-card-section>
          <q-input v-model="newCustomer.customerName" label="客戶名稱" />
          <q-input
            v-model="newCustomer.customerTag"
            label="客戶代碼標籤"
            maxlength="6"
          />
          <q-input v-model="newCustomer.ContactPerson" label="聯絡人" />
          <q-input v-model="newCustomer.Phone" label="聯絡電話" />
          <q-input v-model="newCustomer.Email" label="電子郵件" />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="addCustomer" />
        </q-card-actions>
      </q-card>
    </q-dialog>

    <!-- 編輯客戶對話框 -->
    <q-dialog v-model="isEditDialogOpen">
      <q-card style="min-width: 600px">
        <q-card-section>
          <div class="text-h6">編輯客戶資訊</div>
        </q-card-section>
        <q-card-section>
          <q-input v-model="editCustomer.customerName" label="客戶名稱" />
          <q-input
            v-model="editCustomer.customerTag"
            label="客戶代碼標籤"
            maxlength="6"
          />
          <q-input v-model="editCustomer.contactPerson" label="聯絡人" />
          <q-input v-model="editCustomer.phone" label="聯絡電話" />
          <q-input v-model="editCustomer.email" label="電子郵件" />
        </q-card-section>
        <q-card-actions align="right">
          <q-btn flat label="取消" v-close-popup />
          <q-btn flat label="保存" color="primary" @click="updateCustomer" />
        </q-card-actions>
      </q-card>
    </q-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import axios from "axios";
import { useQuasar } from "quasar";
import { useRouter } from "vue-router";
const $q = useQuasar();
const router = useRouter(); // Use useRouter to get the router instance

const loading = ref(true);
const customers = ref([]);
const pagination = ref({
  page: 1,
  rowsPerPage: 10,
  rowsNumber: 0,
});
const maxPages = ref(1);

const newCustomer = ref({
  CustomerName: "",
  CustomerTag: "",
  CreateDate: new Date().toISOString().split("T")[0], // 自動帶入現在日期
  Email: "",
  Phone: "",
  ContactPerson: "",
});

const editCustomer = ref({});
const isAddDialogOpen = ref(false);
const isEditDialogOpen = ref(false);

const columns = [
  { name: "CustomerID", label: "客戶ID", field: "customerID" },
  { name: "CustomerName", label: "客戶名稱", field: "customerName" },
  { name: "CustomerTag", label: "客戶代碼", field: "customerTag" },
  { name: "CreateDate", label: "建立日期", field: "createDate" },
  { name: "actions", label: "操作", field: "actions" },
];

const fetchCustomers = async () => {
  loading.value = true;
  try {
    const response = await axios.get("http://localhost:5234/api/customers", {
      params: {
        page: pagination.value.page,
        limit: pagination.value.rowsPerPage,
      },
    });
    customers.value = response.data.customers;
    pagination.value.rowsNumber = response.data.total;
    maxPages.value = Math.ceil(
      response.data.total / pagination.value.rowsPerPage
    );
  } catch (error) {
    console.error("Failed to fetch customers:", error);
  } finally {
    loading.value = false;
  }
};

const onPageChange = () => {
  fetchCustomers();
};

onMounted(() => {
  fetchCustomers();
});

const addCustomer = async () => {
  try {
    await axios.post("http://localhost:5234/api/customers", newCustomer.value);
    $q.notify({
      type: "positive",
      message: "新增客戶成功",
      position: "center",
    });
    await fetchCustomers(); // 確保客戶列表重新加載
    isAddDialogOpen.value = false;
  } catch (error) {
    console.error("Failed to add customer:", error.response.data);
    $q.notify({
      type: "negative",
      message: "新增客戶失敗",
      position: "center",
    });
  }
};

const updateCustomer = async () => {
  try {
    await axios.put(
      `http://localhost:5234/api/customers/${editCustomer.value.customerID}`,
      editCustomer.value
    );
    $q.notify({
      type: "positive",
      message: "編輯客戶成功",
      position: "center",
    });
    fetchCustomers();
    isEditDialogOpen.value = false;
  } catch (error) {
    console.error("Failed to update customer:", error.response.data);
    $q.notify({
      type: "negative",
      message: "編輯客戶失敗",
      position: "center",
    });
  }
};

const deleteCustomer = async (id) => {
  try {
    await axios.delete(`http://localhost:5234/api/customers/${id}`);
    $q.notify({
      type: "positive",
      message: "刪除客戶成功",
      position: "center",
    });
    fetchCustomers();
  } catch (error) {
    console.error("Failed to delete customer:", error.response.data);
    $q.notify({
      type: "negative",
      message: "刪除客戶失敗",
      position: "center",
    });
  }
};

const confirmDeleteCustomer = (customer) => {
  $q.notify({
    type: "warning",
    message: `確定要刪除客戶-${customer.customerName}嗎?`,
    position: "center",
    timeout: 0,
    actions: [
      {
        label: "否",
        color: "white",
        handler: () => {},
      },
      {
        label: "是",
        color: "negative",
        handler: () => {
          deleteCustomer(customer.customerID);
        },
      },
    ],
  });
};

const openAddDialog = () => {
  isAddDialogOpen.value = true;
};

const openEditDialog = (customer) => {
  // 在這裡檢查客戶資料是否正確傳遞
  console.log("Selected customer for editing:", customer);

  // 將選擇的客戶資料賦值給 editCustomer
  editCustomer.value = { ...customer };

  // 檢查 editCustomer 是否正確更新
  console.log("editCustomer after assignment:", editCustomer.value);

  // 打開編輯對話框
  isEditDialogOpen.value = true;

  // 再次檢查 dialog 是否打開，以及資料是否正確
  console.log("Dialog open:", isEditDialogOpen.value);
  console.log("editCustomer in dialog:", editCustomer.value);
};

const openRegionManagement = (customer) => {
  console.log("Navigating to region management for:", customer);

  // Use router.push to navigate
  router.push({
    name: "區域管理",
    params: { customerId: customer.customerID },
  });
};
</script>

<style scoped>
.customer-table {
  width: 100%;
  border-collapse: collapse;
}
</style>
