<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-input
              v-model="startDate"
              label="日期起"
              outlined
              dense
              mask="####/##/##"
              placeholder="YYYY/MM/DD"
              clearable
            >
              <template v-slot:append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    ref="startDateProxy"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      v-model="startDate"
                      mask="YYYY/MM/DD"
                      today-btn
                      @update:model-value="() => $refs.startDateProxy.hide()"
                    />
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-input
              v-model="endDate"
              label="日期迄"
              outlined
              dense
              mask="####/##/##"
              placeholder="YYYY/MM/DD"
              clearable
            >
              <template v-slot:append>
                <q-icon name="event" class="cursor-pointer">
                  <q-popup-proxy
                    ref="endDateProxy"
                    cover
                    transition-show="scale"
                    transition-hide="scale"
                  >
                    <q-date
                      v-model="endDate"
                      mask="YYYY/MM/DD"
                      today-btn
                      @update:model-value="() => $refs.endDateProxy.hide()"
                    />
                  </q-popup-proxy>
                </q-icon>
              </template>
            </q-input>
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-input
              v-model="keyword"
              label="關鍵字查詢"
              outlined
              dense
              placeholder="輸入關鍵字..."
              clearable
            />
          </q-col>

          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
              :loading="isLoading"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onExport"
              unelevated
              class="full-width"
              :disabled="isLoading || isExporting"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <q-page class="q-pa-md">
    <q-table
      :rows="alerts"
      :columns="columns"
      row-key="rowKey"
      :rows-per-page-options="[20]"
      v-model:pagination="pagination"
      @request="onPagination"
      flat
      bordered
      class="alert-table"
      :loading="isLoading"
    >
      <template v-slot:body-cell-dataTime="props">
        <q-td :props="props">
          <span>{{ props.row.dataTime }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-deviceID="props">
        <q-td :props="props">
          <span>{{ props.row.deviceID }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-descript="props">
        <q-td :props="props">
          <span>{{ props.row.descript }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-alertType="props">
        <q-td :props="props">
          <span
            :class="{
              'alert-warning': props.row.alertType.includes('告警'),
              'alert-recover': props.row.alertType.includes('復歸'),
            }"
          >
            {{ props.row.alertType }}
          </span>
        </q-td>
      </template>
      <template v-slot:body-cell-alertValue="props">
        <q-td :props="props">
          <span>{{ props.row.alertValue }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-alertLimit="props">
        <q-td :props="props">
          <span>{{ props.row.alertLimit }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-alertDescript="props">
        <q-td :props="props">
          <span>{{ props.row.alertDescript }}</span>
        </q-td>
      </template>
      <template v-slot:bottom>
        <div class="row items-center justify-between full-width">
          <div>總筆數: {{ totalCount }}</div>
          <div class="pagination-container">
            <q-pagination
              v-model="pagination.page"
              :max="Math.ceil(totalCount / pagination.rowsPerPage)"
              :max-pages="6"
              boundary-links
              direction-links
              @update:model-value="onPageChange"
            />
          </div>
        </div>
      </template>
    </q-table>
  </q-page>
</template>

<script setup>
import { ref, onMounted, watch } from "vue";
import axios from "axios";

// API URL - 使用你的後端 API URL
const API_URL = "http://localhost:5121";

// 狀態變數
const startDate = ref("");
const endDate = ref("");
const keyword = ref("");
const alerts = ref([]);
const isLoading = ref(false);
const isExporting = ref(false);
const totalCount = ref(0);

// 分頁設置 - 設定預設為20筆/頁
const pagination = ref({
  page: 1,
  rowsPerPage: 20, // 固定每頁顯示20筆
  rowsNumber: 0,
});

// 格式化日期為 API 需要的格式 (從 YYYY/MM/DD 轉為 YYYY-MM-DD)
const formatDateForApi = (dateStr) => {
  if (!dateStr) return null;
  return dateStr.replace(/\//g, "-");
};

// 從 API 獲取數據
const fetchAlerts = async () => {
  try {
    isLoading.value = true;

    // 準備參數
    const params = {
      pageNumber: pagination.value.page,
      pageSize: pagination.value.rowsPerPage, // 固定20筆
    };

    if (startDate.value) {
      params.startDate = formatDateForApi(startDate.value);
    }

    if (endDate.value) {
      params.endDate = formatDateForApi(endDate.value);
    }

    if (keyword.value) {
      params.keyword = keyword.value;
    }

    // 呼叫 API
    const response = await axios.get(`${API_URL}/api/Alert`, { params });
    const data = response.data;

    // 更新數據，為每一行添加唯一的 rowKey
    alerts.value = data.items.map((item) => ({
      ...item,
      rowKey: `${item.dataTime}-${item.deviceID}`, // 使用時間和設備 ID 創建唯一鍵
    }));

    totalCount.value = data.totalCount;
    pagination.value.rowsNumber = data.totalCount;
  } catch (error) {
    console.error("獲取告警數據失敗:", error);
    // 你可以在這裡添加錯誤提示
  } finally {
    isLoading.value = false;
  }
};

// 當組件掛載時獲取數據
onMounted(() => {
  fetchAlerts();
});

// 搜索按鈕點擊事件
const onSearch = () => {
  pagination.value.page = 1; // 重置到第一頁
  fetchAlerts();
};

// 處理頁碼變更
const onPageChange = (page) => {
  fetchAlerts();
};

// 處理分頁變更
const onPagination = (newPagination) => {
  pagination.value = newPagination;
  fetchAlerts();
};

// 匯出 Excel
const onExport = async () => {
  if (isExporting.value) return;

  try {
    isExporting.value = true;

    // 準備參數
    const params = {};

    if (startDate.value) {
      params.startDate = formatDateForApi(startDate.value);
    }

    if (endDate.value) {
      params.endDate = formatDateForApi(endDate.value);
    }

    if (keyword.value) {
      params.keyword = keyword.value;
    }

    // 生成包含日期範圍的文件名
    let fileName = "告警記錄";
    const now = new Date();
    const timeStamp = `${now.getFullYear()}${String(
      now.getMonth() + 1
    ).padStart(2, "0")}${String(now.getDate()).padStart(2, "0")}`;

    if (startDate.value && endDate.value) {
      fileName += `_${startDate.value.replace(
        /\//g,
        ""
      )}_${endDate.value.replace(/\//g, "")}`;
    } else if (startDate.value) {
      fileName += `_從${startDate.value.replace(/\//g, "")}`;
    } else if (endDate.value) {
      fileName += `_至${endDate.value.replace(/\//g, "")}`;
    } else {
      fileName += `_${timeStamp}`;
    }

    if (keyword.value) {
      fileName += `_${keyword.value}`;
    }

    fileName += ".xlsx";

    // 呼叫 API 匯出 Excel
    const response = await axios.get(`${API_URL}/api/Alert/export`, {
      params,
      responseType: "blob",
    });

    // 檢查檔案大小
    if (response.data.size === 0) {
      alert("匯出結果為空！");
      return;
    }

    // 創建下載連結
    const url = window.URL.createObjectURL(new Blob([response.data]));
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", fileName);
    document.body.appendChild(link);
    link.click();

    // 釋放資源
    setTimeout(() => {
      window.URL.revokeObjectURL(url);
      document.body.removeChild(link);
    }, 100);
  } catch (error) {
    console.error("匯出 Excel 失敗:", error);
    alert(
      "匯出 Excel 失敗：" +
        (error.response?.data || error.message || "未知錯誤")
    );
  } finally {
    isExporting.value = false;
  }
};

// 資料表列定義
const columns = [
  { name: "dataTime", label: "時間", field: "dataTime", align: "left" },
  { name: "deviceID", label: "設備ID", field: "deviceID", align: "left" },
  { name: "descript", label: "設備描述", field: "descript", align: "left" },
  { name: "alertValue", label: "告警值", field: "alertValue", align: "right" },
  {
    name: "alertLimit",
    label: "告警限制",
    field: "alertLimit",
    align: "right",
  },
  { name: "alertType", label: "告警類型", field: "alertType", align: "left" },
  {
    name: "alertDescript",
    label: "告警描述",
    field: "alertDescript",
    align: "left",
  },
];
</script>

<style scoped>
.alert-warning {
  color: red;
}

.alert-recover {
  color: rgb(22, 121, 2);
}

.alert-table {
  width: 100%;
  border-collapse: collapse;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}
</style>
