<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇區域(第一層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption3"
              :options="options3"
              label="選擇區域(第二層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption4"
              :options="options4"
              label="選擇用電/發電/碳排放"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card class="compare">
      <q-card-section class="chart-header">
        <div class="chart-title">年度同比比較</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <div class="chart-container">
          <canvas ref="yearOnYearChart"></canvas>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <div class="q-pa-md">
    <q-card class="compare">
      <q-card-section class="chart-header">
        <div class="chart-title">月度環比增長率</div>
      </q-card-section>
      <q-card-section class="q-pa-none">
        <div class="chart-container">
          <canvas ref="barChart"></canvas>
        </div>
      </q-card-section>
    </q-card>
  </div>
</template>
<script setup>
import { ref, onMounted, onBeforeUnmount } from "vue";
import { Chart, registerables } from "chart.js";
Chart.register(...registerables);

const yearOnYearChart = ref(null);
const barChart = ref(null);

const yearOnYearData = ref({
  labels: [
    "1月",
    "2月",
    "3月",
    "4月",
    "5月",
    "6月",
    "7月",
    "8月",
    "9月",
    "10月",
    "11月",
    "12月",
  ],
  datasets: [
    {
      label: "2023年",
      type: "bar",
      data: [320, 280, 300, 350, 400, 450, 420, 390, 360, 410, 450, 480],
      backgroundColor: "rgba(75, 192, 192, 0.6)",
    },
    {
      label: "2024年",
      type: "bar",
      data: [300, 270, 310, 330, 420, 460, 430, 410, 380, 420, 460, 500],
      backgroundColor: "rgba(153, 102, 255, 0.6)",
    },
    {
      label: "2023年增長趨勢",
      type: "line",
      data: [320, 280, 300, 350, 400, 450, 420, 390, 360, 410, 450, 480],
      borderColor: "rgba(75, 192, 192, 1)",
      fill: false,
    },
    {
      label: "2024年增長趨勢",
      type: "line",
      data: [300, 270, 310, 330, 420, 460, 430, 410, 380, 420, 460, 500],
      borderColor: "rgba(153, 102, 255, 1)",
      fill: false,
    },
  ],
});

const barData = ref({
  labels: [
    "1月",
    "2月",
    "3月",
    "4月",
    "5月",
    "6月",
    "7月",
    "8月",
    "9月",
    "10月",
    "11月",
    "12月",
  ],
  datasets: [
    {
      label: "環比增長率 (%)",
      data: [5, -10, 3, 7, 10, -5, 8, 2, -3, 5, 6, 4],
      backgroundColor: (context) =>
        context.raw > 0 ? "rgba(75, 192, 192, 0.6)" : "rgba(255, 99, 132, 0.6)",
      borderColor: (context) =>
        context.raw > 0 ? "rgba(75, 192, 192, 1)" : "rgba(255, 99, 132, 1)",
      borderWidth: 1,
    },
  ],
});

const commonOptions = {
  responsive: true,
  maintainAspectRatio: false,
  scales: {
    x: { beginAtZero: true },
    y: { beginAtZero: true },
  },
  plugins: {
    legend: { position: "top" },
    tooltip: {
      callbacks: {
        label: function (tooltipItem) {
          return `${tooltipItem.dataset.label}: ${tooltipItem.raw}`;
        },
      },
    },
  },
};

let myYearOnYearChart = null;
let myBarChart = null;

onMounted(() => {
  myYearOnYearChart = new Chart(yearOnYearChart.value, {
    type: "bar",
    data: yearOnYearData.value,
    options: commonOptions,
  });
  myBarChart = new Chart(barChart.value, {
    type: "bar",
    data: barData.value,
    options: commonOptions,
  });
});

onBeforeUnmount(() => {
  if (myYearOnYearChart) myYearOnYearChart.destroy();
  if (myBarChart) myBarChart.destroy();
});

const selectedOption1 = ref(null);
const selectedOption2 = ref(null);
const selectedOption3 = ref(null);
const selectedOption4 = ref(null);

const options1 = [
  { label: "台灣化學纖維股份有限公司", value: "1-1" },
  { label: "台灣電力股份有限公司", value: "1-2" },
  { label: "台灣高速鐵路股份有限公司", value: "1-3" },
];

const options2 = [
  { label: "新港廠", value: "2-1" },
  { label: "麥寮廠", value: "2-2" },
  { label: "龍德廠", value: "2-3" },
];

const options3 = [
  { label: "區域A", value: "3-1" },
  { label: "區域B", value: "3-2" },
  { label: "區域C", value: "3-3" },
];

const options4 = [
  { label: "用電量", value: "4-1" },
  { label: "發電量", value: "4-2" },
  { label: "碳排量", value: "4-3" },
];

const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
    option3: selectedOption3.value,
  });
};
</script>

<style>
.col-25 {
  width: 25%;
}

.chart-container {
  width: 23%;
}

@media (max-width: 800px) {
  .chart-container {
    width: 100% !important;
  }
}

.compare.chart-header {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 16px;
}

.compare .chart-title {
  font-size: 18px;
  font-weight: bold;
}

.compare .chart-container {
  position: relative;
  width: 100%;
  height: 400px;
}
</style>
