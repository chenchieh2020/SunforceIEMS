<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <div class="col-12 col-sm-4 col-md-3">
            <q-btn
              label="確認全部"
              color="primary"
              @click="acknowledgeAll"
              unelevated
              class="full-width"
              :loading="isLoading"
            />
          </div>
          <div class="col-12 col-sm-4 col-md-3">
            <q-btn
              label="確認已勾選項目"
              color="secondary"
              @click="acknowledgeSelected"
              unelevated
              class="full-width"
              :disabled="!hasSelectedItems"
              :loading="isLoading"
            />
          </div>
          <div class="col-12 col-sm-4 col-md-3">
            <div class="connection-status">
              連線狀態:
              <span :class="connectionStatusClass">{{ connectionStatus }}</span>
            </div>
          </div>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <q-page class="q-pa-md">
    <q-table
      :rows="alerts"
      :columns="columns"
      row-key="rowKey"
      :rows-per-page-options="[20]"
      v-model:pagination="pagination"
      @request="onPagination"
      flat
      bordered
      class="alert-table"
      :loading="isLoading"
    >
      <template v-slot:body="props">
        <q-tr :props="props" :class="getRowClass(props.row)">
          <q-td>
            <q-checkbox v-model="props.row.selected" />
          </q-td>
          <q-td>
            <span>{{ getAckStatus(props.row.ack) }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.userName || "-" }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.dataTime }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.deviceID }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.descript }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.currValue }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.alertValue }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.alertLimit }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.alertType }}</span>
          </q-td>
          <q-td>
            <span>{{ props.row.alertDescript }}</span>
          </q-td>
        </q-tr>
      </template>
      <template v-slot:bottom>
        <div class="row items-center justify-between full-width">
          <div>總筆數: {{ totalCount }}</div>
          <div class="pagination-container">
            <q-pagination
              v-model="pagination.page"
              :max="Math.ceil(totalCount / pagination.rowsPerPage)"
              :max-pages="6"
              boundary-links
              direction-links
              @update:model-value="onPageChange"
            />
          </div>
        </div>
      </template>
    </q-table>
  </q-page>
</template>

<script setup>
import { ref, onMounted, watch, computed, onBeforeUnmount } from "vue";
import axios from "axios";
import * as signalR from "@microsoft/signalr";

// API URL - 使用你的後端 API URL
const API_URL = "http://localhost:5121";
const HUB_URL = `${API_URL}/realTimeAlertHub`;

// 狀態變數
const alerts = ref([]);
const isLoading = ref(false);
const totalCount = ref(0);
const connection = ref(null);
const connectionStatus = ref("未連接");
const connectionStatusClass = ref("status-disconnected");
const reconnectInterval = ref(null);
const reconnectAttempts = ref(0);
const maxReconnectAttempts = 5;
const reconnectDelay = 3000; // 3秒後重連
const isConnecting = ref(false);
const systemInitialized = ref(false);

// 分頁設置
const pagination = ref({
  page: 1,
  rowsPerPage: 20,
  rowsNumber: 0,
});

// 計算是否有選擇的項目
const hasSelectedItems = computed(() => {
  return alerts.value.some((alert) => alert.selected);
});

// 獲取確認狀態文字
const getAckStatus = (ack) => {
  return ack === 1 ? "已確認" : "未確認";
};

// 獲取行的類別來設定顏色
const getRowClass = (row) => {
  if (row.finish === 0 && row.ack === 0) {
    return "alert-warning"; // 新增告警且未確認，紅色並閃爍
  } else if (row.finish === 1 && row.ack === 0) {
    return "alert-recover"; // 告警已復歸但未確認，綠色
  } else if (row.finish === 0 && row.ack === 1) {
    return "alert-normal"; // 告警未復歸但已確認，黑色
  }
  // 告警復歸且被確認 - 不顯示 (會在fetchAlerts中過濾)
  return "";
};

// 從 API 獲取數據
const fetchAlerts = async () => {
  try {
    isLoading.value = true;

    // 準備參數
    const params = {
      pageNumber: pagination.value.page,
      pageSize: pagination.value.rowsPerPage,
    };

    console.log("正在獲取告警數據...");
    // 呼叫 API
    const response = await axios.get(`${API_URL}/api/RealTimeAlert`, {
      params,
      timeout: 10000, // 設置請求超時時間
      withCredentials: false,
    });

    console.log("獲取告警數據成功:", response.status);
    const data = response.data;

    // 更新數據，為每一行添加唯一的 rowKey 和選擇狀態
    alerts.value = data.items
      ? data.items.map((item) => ({
          ...item,
          rowKey: item.rowKey || `${item.dataTime}-${item.deviceID}`,
          selected: false, // 添加選擇狀態
        }))
      : [];

    // 更新總數
    totalCount.value = data.totalCount || 0;
    pagination.value.rowsNumber = data.totalCount || 0;
  } catch (error) {
    console.error("獲取告警數據失敗:", error);

    // 輸出詳細錯誤信息
    if (error.response) {
      // 服務器回應錯誤
      console.log("回應狀態:", error.response.status);
      console.log("回應數據:", error.response.data);
      console.log("回應頭:", error.response.headers);
    } else if (error.request) {
      // 請求發送但沒有收到回應
      console.log("請求發送但無回應:", error.request);
    } else {
      // 其他錯誤
      console.log("錯誤:", error.message);
    }

    // 設置空的告警列表作為備用
    alerts.value = [];
    totalCount.value = 0;
  } finally {
    isLoading.value = false;
  }
};

// 當組件掛載時獲取數據並連接SignalR
onMounted(() => {
  // 延遲初始化，等待系統充分加載
  setTimeout(() => {
    systemInitialized.value = true;
    fetchAlerts();

    // 等待數據加載完成後連接SignalR
    setTimeout(() => {
      connectSignalR();
    }, 1000);
  }, 1000);
});

// SignalR 相關函數
const connectSignalR = () => {
  if (isConnecting.value) return;
  if (!systemInitialized.value) return;

  // 如果已經連接，不再重新連接
  if (
    connection.value &&
    connection.value.state === signalR.HubConnectionState.Connected
  ) {
    console.log("SignalR 已連接，不再嘗試重新連接");
    connectionStatus.value = "已連接";
    connectionStatusClass.value = "status-connected";
    return;
  }

  isConnecting.value = true;

  try {
    connection.value = new signalR.HubConnectionBuilder()
      .withUrl(HUB_URL, {
        skipNegotiation: true,
        transport: signalR.HttpTransportType.WebSockets,
      })
      .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
      .build();

    // 設置連接狀態變更的處理函數
    connection.value.onreconnecting((error) => {
      console.log("SignalR 正在重新連接:", error);
      connectionStatus.value = "重新連接中";
      connectionStatusClass.value = "status-reconnecting";
    });

    connection.value.onreconnected((connectionId) => {
      console.log("SignalR 已重新連接, ID:", connectionId);
      connectionStatus.value = "已連接";
      connectionStatusClass.value = "status-connected";

      // 重新加入組
      setTimeout(() => {
        joinGroup();
      }, 500);
    });

    connection.value.onclose((error) => {
      console.log("SignalR 連接已關閉:", error);
      connectionStatus.value = "已關閉";
      connectionStatusClass.value = "status-disconnected";
    });

    // 監聽告警更新
    connection.value.on("ReceiveAlert", (message) => {
      console.log("收到告警更新:", message);
      if (message.type === "alertUpdate" || message.type === "global") {
        handleNewAlert(message.alert);
      }
    });

    // 監聽批量告警更新
    connection.value.on("ReceiveBatchAlerts", (message) => {
      console.log("收到批量告警更新:", message);
      if (message.type === "batchUpdate") {
        message.alerts.forEach((alert) => handleNewAlert(alert));
      }
    });

    // 監聽告警確認通知
    connection.value.on("ReceiveAlertAcknowledged", (message) => {
      console.log("收到告警確認通知:", message);
      // 更新確認狀態
      updateAcknowledgedAlert(message);
    });

    // 啟動連接
    startConnection();
  } catch (error) {
    console.error("建立 SignalR 連接失敗:", error);
    connectionStatus.value = "連接失敗";
    connectionStatusClass.value = "status-failed";
    isConnecting.value = false;
  }
};

// 加入告警頁面組
const joinGroup = async () => {
  if (
    !connection.value ||
    connection.value.state !== signalR.HubConnectionState.Connected
  ) {
    return;
  }

  try {
    await connection.value.invoke("JoinGroup", "alertPage");
    console.log("已加入告警頁面組");

    // 同時加入全局組以接收系統範圍的通知
    await connection.value.invoke("JoinGroup", "global");
    console.log("已加入全局通知組");
  } catch (error) {
    console.error("加入告警頁面組失敗:", error);
  }
};

// 更新已確認的告警
const updateAcknowledgedAlert = (message) => {
  // 嘗試找到對應的告警
  const alertKey = message.rowKey || `${message.dateTime}-${message.deviceId}`;

  // 查找告警 (考慮欄位命名的差異)
  const index = alerts.value.findIndex((a) => {
    const key = a.rowKey || `${a.dataTime}-${a.deviceID}`;
    return (
      key === alertKey ||
      (a.dataTime === message.dateTime && a.deviceID === message.deviceId) ||
      (a.dataTime === message.dateTime && a.deviceID === message.deviceID)
    );
  });

  if (index !== -1) {
    // 更新確認狀態和確認者
    console.log(`更新告警確認狀態, 索引: ${index}`);
    alerts.value[index].ack = 1;
    alerts.value[index].userName =
      message.userName || alerts.value[index].userName || "-";
  }
};

// 啟動 SignalR 連接
const startConnection = async () => {
  try {
    await connection.value.start();
    console.log("SignalR 已連接");
    connectionStatus.value = "已連接";
    connectionStatusClass.value = "status-connected";
    reconnectAttempts.value = 0;

    // 加入告警頁面組
    await joinGroup();

    // 清除重連計時器
    if (reconnectInterval.value) {
      clearTimeout(reconnectInterval.value);
      reconnectInterval.value = null;
    }

    isConnecting.value = false;
  } catch (error) {
    console.error("SignalR 連接失敗:", error);
    connectionStatus.value = "連接失敗";
    connectionStatusClass.value = "status-failed";
    isConnecting.value = false;

    // 設置重連
    if (
      !reconnectInterval.value &&
      reconnectAttempts.value < maxReconnectAttempts
    ) {
      reconnectInterval.value = setTimeout(() => {
        reconnectAttempts.value++;
        connectionStatus.value = `重新連接中 (${reconnectAttempts.value}/${maxReconnectAttempts})`;
        connectionStatusClass.value = "status-reconnecting";

        console.log(
          `嘗試重新連接 (${reconnectAttempts.value}/${maxReconnectAttempts})`
        );
        startConnection();

        if (reconnectAttempts.value >= maxReconnectAttempts) {
          clearTimeout(reconnectInterval.value);
          reconnectInterval.value = null;
          connectionStatus.value = "連接失敗";
          connectionStatusClass.value = "status-failed";
        }
      }, reconnectDelay);
    }
  }
};

// 處理新的告警資料
const handleNewAlert = (newAlert) => {
  try {
    // 檢查是否為不顯示的告警類型 (告警復歸且被確認)
    if (newAlert && newAlert.finish === 1 && newAlert.ack === 1) {
      return;
    }

    if (!newAlert) {
      console.error("收到無效告警數據");
      return;
    }

    // 標準化欄位名稱
    const normalizedAlert = {
      ...newAlert,
      dataTime: newAlert.dataTime || newAlert.dateTime,
      deviceID: newAlert.deviceID || newAlert.deviceId,
      finish: newAlert.finish !== undefined ? newAlert.finish : newAlert.Finish,
      ack: newAlert.ack !== undefined ? newAlert.ack : newAlert.Ack,
    };

    // 為新告警添加唯一鍵和選擇狀態
    const alertWithKey = {
      ...normalizedAlert,
      rowKey:
        normalizedAlert.rowKey ||
        `${normalizedAlert.dataTime}-${normalizedAlert.deviceID}`,
      selected: false,
    };

    console.log("處理新告警:", alertWithKey);

    // 檢查是否已經存在相同的告警
    const existingIndex = alerts.value.findIndex(
      (a) =>
        a.rowKey === alertWithKey.rowKey ||
        (a.dataTime === alertWithKey.dataTime &&
          a.deviceID === alertWithKey.deviceID)
    );

    if (existingIndex >= 0) {
      // 更新現有告警
      console.log(`更新現有告警 索引:${existingIndex}`);
      alerts.value[existingIndex] = {
        ...alerts.value[existingIndex],
        ...alertWithKey,
      };
    } else if (pagination.value.page === 1) {
      // 只在第一頁時添加新告警
      console.log("添加新告警到列表");
      alerts.value.unshift(alertWithKey);
      totalCount.value++;

      // 確保不超過每頁顯示數量
      if (alerts.value.length > pagination.value.rowsPerPage) {
        alerts.value.pop();
      }
    }
  } catch (error) {
    console.error("處理新告警時發生錯誤:", error, newAlert);
  }
};

// 處理頁碼變更
const onPageChange = (page) => {
  fetchAlerts();
};

// 處理分頁變更
const onPagination = (newPagination) => {
  pagination.value = newPagination;
  fetchAlerts();
};

// 確認所有告警
const acknowledgeAll = async () => {
  try {
    isLoading.value = true;

    // 呼叫 API 確認所有告警
    await axios.post(`${API_URL}/api/RealTimeAlert/acknowledgeAll`);

    // 重新載入數據
    await fetchAlerts();
  } catch (error) {
    console.error("確認所有告警失敗:", error);
    alert(
      "確認所有告警失敗：" +
        (error.response?.data || error.message || "未知錯誤")
    );
  } finally {
    isLoading.value = false;
  }
};

// 確認已選擇的告警
const acknowledgeSelected = async () => {
  try {
    isLoading.value = true;

    // 獲取已選擇的告警
    const selectedAlerts = alerts.value
      .filter((alert) => alert.selected)
      .map((alert) => ({
        DataTime: alert.dataTime,
        DeviceID: alert.deviceID,
      }));

    if (selectedAlerts.length === 0) {
      alert("請先選擇要確認的告警項目");
      isLoading.value = false;
      return;
    }

    // 呼叫 API 確認選擇的告警
    await axios.post(
      `${API_URL}/api/RealTimeAlert/acknowledgeSelected`,
      selectedAlerts
    );

    // 重新載入數據
    await fetchAlerts();
  } catch (error) {
    console.error("確認選擇告警失敗:", error);
    alert(
      "確認選擇告警失敗：" +
        (error.response?.data || error.message || "未知錯誤")
    );
  } finally {
    isLoading.value = false;
  }
};

// 組件卸載時斷開 SignalR 連接
onBeforeUnmount(() => {
  if (connection.value) {
    try {
      // 如果連接是連接狀態，則嘗試離開組
      if (connection.value.state === signalR.HubConnectionState.Connected) {
        // 先離開組
        connection.value
          .invoke("LeaveGroup", "alertPage")
          .catch((err) => console.error("離開告警頁面組時發生錯誤:", err));

        connection.value
          .invoke("LeaveGroup", "global")
          .catch((err) => console.error("離開全局組時發生錯誤:", err));
      }

      // 然後斷開連接
      connection.value
        .stop()
        .catch((err) => console.error("斷開連接時發生錯誤:", err));
    } catch (error) {
      console.error("清理 SignalR 資源時發生錯誤:", error);
    }
  }

  if (reconnectInterval.value) {
    clearTimeout(reconnectInterval.value);
    reconnectInterval.value = null;
  }
});

// 資料表列定義
const columns = [
  { name: "select", label: "", field: "selected", align: "center" },
  { name: "ack", label: "確認狀態", field: "ack", align: "center" },
  { name: "userName", label: "確認者身分", field: "userName", align: "left" },
  { name: "dataTime", label: "日期時間", field: "dataTime", align: "left" },
  { name: "deviceID", label: "點位名稱", field: "deviceID", align: "left" },
  { name: "descript", label: "點位描述", field: "descript", align: "left" },
  { name: "currValue", label: "目前數值", field: "currValue", align: "right" },
  {
    name: "alertValue",
    label: "告警數值",
    field: "alertValue",
    align: "right",
  },
  {
    name: "alertLimit",
    label: "告警臨界",
    field: "alertLimit",
    align: "right",
  },
  { name: "alertType", label: "告警種類", field: "alertType", align: "left" },
  {
    name: "alertDescript",
    label: "告警描述",
    field: "alertDescript",
    align: "left",
  },
];
</script>

<style scoped>
.alert-warning {
  color: red;
  animation: blinker 1s linear infinite;
}

@keyframes blinker {
  50% {
    opacity: 0.5;
  }
}

.alert-recover {
  color: rgb(22, 121, 2);
}

.alert-normal {
  color: black;
}

.alert-table {
  width: 100%;
  border-collapse: collapse;
}

.pagination-container {
  display: flex;
  justify-content: center;
  margin-top: 10px;
}

.status-connected {
  color: green;
  font-weight: bold;
}

.status-disconnected {
  color: red;
  font-weight: bold;
}

.status-reconnecting {
  color: orange;
  font-weight: bold;
  animation: blinker 1s linear infinite;
}

.status-error,
.status-failed {
  color: darkred;
  font-weight: bold;
}

.connection-status {
  padding: 8px;
  text-align: right;
}
</style>
