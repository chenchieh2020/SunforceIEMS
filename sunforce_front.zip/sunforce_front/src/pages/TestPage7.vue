<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <!-- 选择电表型号 -->
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedModelForNewMeter"
              :options="meterModels"
              label="選擇電錶型號"
              option-value="modelName"
              option-label="modelName"
              outlined
              dense
              @input="onMeterModelSelect"
            />
          </q-col>
          <!-- 显示电表型号ID -->
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="selectedModelForNewMeter.modelID"
              label="電錶型號ID"
              outlined
              dense
              readonly
            />
          </q-col>
          <!-- 显示电表型号缩写 -->
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="selectedModelForNewMeter.modelCode"
              label="電錶型號縮寫"
              outlined
              dense
              readonly
            />
          </q-col>
          <!-- 安装日期起 -->
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="startDate"
              label="安裝日期起"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <!-- 安装日期迄 -->
          <q-col cols="12" sm="4" md="3">
            <q-input
              v-model="endDate"
              label="安裝日期迄"
              mask="####-##-##"
              outlined
              dense
              type="date"
            />
          </q-col>
          <!-- 搜索按钮 -->
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <!-- 新增电表按钮 -->
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="+ 新增電錶"
              color="deep-orange"
              @click="openAddDialog"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>

    <q-page class="q-pa-md">
      <!-- Skeleton Loader -->
      <q-card v-if="loading">
        <q-card-section>
          <div class="row q-gutter-md">
            <q-col cols="12">
              <q-skeleton type="text" width="80%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="60%"></q-skeleton>
            </q-col>
            <q-col cols="12">
              <q-skeleton type="text" width="70%"></q-skeleton>
            </q-col>
          </div>
        </q-card-section>
        <q-skeleton type="rect" height="200px"></q-skeleton>
      </q-card>

      <!-- Table Data -->
      <q-table
        v-if="meters.length > 0"
        :rows="meters"
        :columns="columns"
        row-key="electricMeterID"
        flat
        bordered
        hide-bottom
        rows-per-page="10"
        class="meter-table"
      >
        <template v-slot:body-cell-electricMeterName="props">
          <q-td :props="props">
            <span class="meter-name">{{ props.row.electricMeterName }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterNumber="props">
          <q-td :props="props">
            <span>{{ props.row.electricMeterNumber }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-gatewayID="props">
          <q-td :props="props">
            <span>{{ props.row.gatewayID }}</span>
          </q-td>
        </template>
        <!-- 新增的用途列显示 -->
        <template v-slot:body-cell-electricMeterUsageName="props">
          <q-td :props="props">
            <span>{{ props.row.electricMeterUsageName || "无用途信息" }}</span>
          </q-td>
        </template>

        <template v-slot:body-cell-electricMeterInstallStatus="props">
          <q-td :props="props">
            <span>{{
              props.row.electricMeterInstallStatus == 1 ? "已安裝" : "未安裝"
            }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterInstallDate="props">
          <q-td :props="props">
            <span>{{ props.row.electricMeterInstallDate }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterModel="props">
          <q-td :props="props">
            <span>{{ props.row.meterModelName }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterCT="props">
          <q-td :props="props">
            <span>{{ props.row.electricMeterCT }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterStartValue="props">
          <q-td :props="props">
            <span>{{ props.row.electricMeterStartValue }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-electricMeterUsingStatus="props">
          <q-td :props="props">
            <span>{{
              props.row.electricMeterUsingStatus == 1 ? "使用中" : "未使用"
            }}</span>
          </q-td>
        </template>
        <template v-slot:body-cell-actions="props">
          <q-td :props="props">
            <q-btn
              flat
              label="编辑"
              color="primary"
              @click="openEditDialog(props.row)"
            />
            <q-btn
              flat
              label="删除"
              color="negative"
              @click="confirmDeleteMeter(props.row)"
            />
          </q-td>
        </template>
      </q-table>

      <!-- 使用分页组件 -->
      <div class="q-pa-lg flex flex-center">
        <q-pagination
          v-model="pagination.page"
          :max="maxPages"
          @update:model-value="onPageChange"
        />
      </div>
    </q-page>
  </div>

  <!-- 新增电表对话框 -->
  <q-dialog v-model="isAddDialogOpen">
    <q-card style="min-width: 600px">
      <q-card-section>
        <div class="text-h6">新增電錶資訊</div>
      </q-card-section>
      <q-card-section>
        <q-select
          placeholder="請選擇電錶型號"
          v-model="selectedModelForNewMeter"
          :options="meterModels"
          label="電錶型號"
          option-value="modelName"
          option-label="modelName"
          outlined
          dense
          @input="onMeterModelSelect"
        />
        <q-input
          v-model="selectedModelForNewMeter.modelID"
          label="電錶型號ID"
          outlined
          dense
          readonly
        />
        <q-input
          v-model="selectedModelForNewMeter.modelCode"
          label="電錶型號縮寫"
          outlined
          dense
          readonly
        />
        <q-input v-model="newMeter.electricMeterName" label="電錶名稱" />
        <q-input v-model="newMeter.electricMeterTag" label="電表代號(Tag)" />
        <q-input v-model="newMeter.electricMeterNumber" label="電錶表號" />
        <q-input v-model="newMeter.contractNumber" label="契約編號" />
        <q-select
          v-model="newMeter.electricMeterUsageID"
          :options="meterUsages"
          label="選擇電錶用途"
          option-value="usageID"
          option-label="usageName"
          outlined
          dense
        />

        <q-input
          v-model="newMeter.electricMeterCT"
          label="CT變比值(X/Y)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterCT_X"
          label="CT變比值X(電錶實際電流)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterCT_Y"
          label="CT變比值Y(系統測量電流)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterPT"
          label="PT變比值(X/Y)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterPT_X"
          label="PT變比值X(電錶實際電壓)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterPT_Y"
          label="PT變比值Y(系統測量電壓)"
          type="number"
        />
        <q-input
          v-model="newMeter.electricMeterInstallCompany"
          label="施工廠商"
        />
        <div>
          <q-input
            v-model="newMeter.electricMeterInstallDate"
            label="安裝日期"
            type="date"
          />
          <q-input
            v-model="newMeter.electricMeterStartValue"
            label="原始電量"
            type="number"
          />
          <q-checkbox
            v-model="newMeter.electricMeterInstallStatus"
            label="已安裝"
            :true-value="1"
            :false-value="0"
          />
        </div>
        <div>
          <q-checkbox
            v-model="newMeter.electricMeterUsingStatus"
            label="使用中"
            :true-value="1"
            :false-value="0"
          />
        </div>
        <q-input v-model="newMeter.electricMeterNote" label="備註" />
      </q-card-section>
      <q-card-actions align="right">
        <q-btn flat label="取消" v-close-popup />
        <q-btn flat label="保存" color="primary" @click="addMeter" />
      </q-card-actions>
    </q-card>
  </q-dialog>

  <!-- 编辑电表对话框 -->
  <q-dialog v-model="isEditDialogOpen">
    <q-card style="min-width: 600px">
      <q-card-section>
        <div class="text-h6">編輯電錶</div>
      </q-card-section>
      <q-card-section>
        <q-select
          v-model="selectedModelForEditMeter"
          :options="meterModels"
          label="電錶型號"
          option-value="modelName"
          option-label="modelName"
          outlined
          dense
          @input="onMeterModelSelectForEdit"
        />
        <q-input
          v-model="selectedModelForEditMeter.modelID"
          label="電錶型號ID"
          outlined
          dense
          readonly
        />
        <q-input
          v-model="selectedModelForEditMeter.modelCode"
          label="電錶型號縮寫"
          outlined
          dense
          readonly
        />
        <q-input v-model="editMeter.electricMeterName" label="電錶名稱" />
        <q-input v-model="editMeter.electricMeterTag" label="電錶點位前綴" />
        <q-input v-model="editMeter.electricMeterNumber" label="電錶表號" />
        <q-input v-model="editMeter.contractNumber" label="契約編號" />
        <q-select
          v-model="editMeter.electricMeterUsageID"
          :options="meterUsages"
          label="選擇電錶用途"
          option-value="usageID"
          option-label="usageName"
          outlined
          dense
        />

        <q-input
          v-model="editMeter.electricMeterCT"
          label="CT變比值(X/Y)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterCT_X"
          label="CT變比值X(電錶實際電流)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterCT_Y"
          label="CT變比值Y(系統測量電流)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterPT"
          label="PT變比值(X/Y)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterPT_X"
          label="PT變比值X(電錶實際電壓)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterPT_Y"
          label="PT變比值Y(系統測量電壓)"
          type="number"
        />
        <q-input
          v-model="editMeter.electricMeterInstallCompany"
          label="施工廠商"
        />
        <q-input
          v-model="editMeter.electricMeterInstallDate"
          label="安裝日期"
          type="date"
        />
        <q-input
          v-model="editMeter.electricMeterStartValue"
          label="原始電量"
          type="number"
        />
        <div>
          <q-checkbox
            v-model="editMeter.electricMeterInstallStatus"
            label="已安裝"
            :true-value="1"
            :false-value="0"
          />
        </div>
        <div>
          <q-checkbox
            v-model="editMeter.electricMeterUsingStatus"
            label="使用中"
            :true-value="1"
            :false-value="0"
          />
        </div>
        <q-input v-model="editMeter.electricMeterNote" label="備註" />
      </q-card-section>
      <q-card-actions align="right">
        <q-btn flat label="取消" v-close-popup />
        <q-btn flat label="保存" color="primary" @click="updateMeter" />
      </q-card-actions>
    </q-card>
  </q-dialog>
</template>

<script setup>
import { ref, watch, onMounted } from "vue";
import axios from "axios";
import { useQuasar } from "quasar";

const $q = useQuasar();
const selectedOption1 = ref(null);
const selectedOption2 = ref(null);
const startDate = ref("");
const endDate = ref("");
const meters = ref([]);
const loading = ref(false);
const meterModels = ref([]);
const meterUsages = ref([]);
const selectedModelForNewMeter = ref({
  modelID: 0,
  modelName: "請選擇型號",
  modelCode: "DEFAULT",
});
const selectedModelForEditMeter = ref({});
const columns = [
  { name: "electricMeterID", label: "電錶ID", field: "electricMeterID" },
  {
    name: "electricMeterNumber",
    label: "電錶錶號",
    field: "electricMeterNumber",
  },
  { name: "electricMeterName", label: "電錶名稱", field: "electricMeterName" },
  {
    name: "electricMeterUsageName",
    label: "用途",
    field: "electricMeterUsageName",
  }, // 修改为ElectricMeterUsageName
  {
    name: "electricMeterInstallStatus",
    label: "安裝狀態",
    field: "electricMeterInstallStatus",
  },
  {
    name: "electricMeterInstallDate",
    label: "安裝日期",
    field: "electricMeterInstallDate",
  },
  {
    name: "electricMeterModel",
    label: "電錶型號",
    field: "meterModelName", // 修改为meterModelName
  },
  { name: "electricMeterCT", label: "CT變比值", field: "electricMeterCT" },
  {
    name: "electricMeterStartValue",
    label: "原始電量",
    field: "electricMeterStartValue",
  },
  {
    name: "electricMeterUsingStatus",
    label: "使用狀態",
    field: "electricMeterUsingStatus",
  },
  { name: "actions", label: "操作", field: "actions" },
];

const pagination = ref({
  page: 1,
  rowsPerPage: 5,
  rowsNumber: 0,
});
const maxPages = ref(1);

const fetchMeters = async () => {
  loading.value = true;
  try {
    const response = await axios.get(
      `https://localhost/IEMSB/api/electricmeters?page=${pagination.value.page}&limit=${pagination.value.rowsPerPage}`
    );
    meters.value = response.data.meters;
    pagination.value.rowsNumber = response.data.total;
    maxPages.value = Math.ceil(
      response.data.total / pagination.value.rowsPerPage
    );
  } catch (error) {
    console.error("Failed to fetch meters:", error);
  } finally {
    loading.value = false;
  }
};

const fetchMeterModels = async () => {
  try {
    const response = await axios.get("https://localhost/IEMSB/api/metermodels");
    meterModels.value = response.data;
  } catch (error) {
    console.error("Failed to fetch meter models:", error);
  }
};

const fetchMeterUsages = async () => {
  try {
    const response = await axios.get(
      "https://localhost/IEMSB/api/electricmeterusages"
    );
    meterUsages.value = response.data;
  } catch (error) {
    console.error("Failed to fetch meter usages:", error);
  }
};

const onPageChange = () => {
  fetchMeters();
};

watch(
  pagination,
  () => {
    fetchMeters();
  },
  { immediate: true }
);

onMounted(async () => {
  await fetchMeterUsages(); // 先加载用途数据
  await fetchMeterModels(); // 并行加载型号数据
  await fetchMeters(); // 最后加载电表数据，确保 meters.value 每个对象都有 electricMeterUsageName

  console.log("Loaded meter usages:", meterUsages.value);
  console.log("Loaded meters:", meters.value);
});

const newMeter = ref({
  electricMeterNumber: "",
  electricMeterName: "",
  electricMeterTag: "",
  electricMeterModelID: null,
  electricMeterUsageID: null,
  contractNumber: "",
  electricMeterNote: "",
  electricMeterCT: 0,
  electricMeterCT_X: 0,
  electricMeterCT_Y: 0,
  electricMeterPT: 0,
  electricMeterPT_X: 0,
  electricMeterPT_Y: 0,
  electricMeterInstallCompany: "",
  electricMeterUsingStatus: 0,
  electricMeterInstallStatus: 0,
  electricMeterInstallDate: "",
  electricMeterStartValue: 0,
});

const editMeter = ref({});
const isAddDialogOpen = ref(false);
const isEditDialogOpen = ref(false);

const onMeterModelSelect = (modelName) => {
  const selectedModel = meterModels.value.find(
    (model) => model.modelName === modelName
  );
  if (selectedModel) {
    newMeter.value.electricMeterModelID = selectedModel.modelID;
    selectedModelForNewMeter.value = selectedModel;
  }
};

const onMeterModelSelectForEdit = (modelName) => {
  const selectedModel = meterModels.value.find(
    (model) => model.modelName === modelName
  );
  if (selectedModel) {
    editMeter.value.electricMeterModelID = selectedModel.modelID;
    selectedModelForEditMeter.value = selectedModel;
  }

  // 确保用途ID正确赋值
  const selectedUsage = meterUsages.value.find(
    (usage) => usage.usageID === editMeter.value.electricMeterUsageID
  );
  if (selectedUsage) {
    editMeter.value.electricMeterUsageName = selectedUsage.usageName;
  }
};

const addMeter = async () => {
  try {
    const payload = {
      electricMeterNumber: newMeter.value.electricMeterNumber,
      electricMeterName: newMeter.value.electricMeterName,
      electricMeterTag: newMeter.value.electricMeterTag,
      electricMeterModelID: selectedModelForNewMeter.value.modelID,
      electricMeterUsageID: newMeter.value.electricMeterUsageID, // 直接使用 electricMeterUsageID
      electricMeterNote: newMeter.value.electricMeterNote,
      electricMeterCT: newMeter.value.electricMeterCT,
      electricMeterCT_X: newMeter.value.electricMeterCT_X,
      electricMeterCT_Y: newMeter.value.electricMeterCT_Y,
      electricMeterPT: newMeter.value.electricMeterPT,
      electricMeterPT_X: newMeter.value.electricMeterPT_X,
      electricMeterPT_Y: newMeter.value.electricMeterPT_Y,
      electricMeterInstallCompany: newMeter.value.electricMeterInstallCompany,
      electricMeterUsingStatus: newMeter.value.electricMeterUsingStatus,
      electricMeterInstallStatus: newMeter.value.electricMeterInstallStatus,
      electricMeterInstallDate: newMeter.value.electricMeterInstallDate,
      contractNumber: newMeter.value.contractNumber, // 添加 contractNumber
      electricMeterStartValue: parseFloat(
        newMeter.value.electricMeterStartValue
      ),
    };

    console.log("Adding meter payload:", JSON.stringify(payload, null, 2));
    await axios.post("https://localhost/IEMSB/api/electricmeters", payload);
    isAddDialogOpen.value = false;
    $q.notify({
      type: "positive",
      message: "新增電錶成功",
      position: "center",
      actions: [
        {
          label: "確認",
          color: "white",
          handler: () => {
            fetchMeters();
          },
        },
      ],
    });
  } catch (error) {
    console.error("Failed to add meter:", error.response.data);
    $q.notify({
      type: "negative",
      message: "新增電錶失敗",
      position: "center",
    });
  }
};

const updateMeter = async () => {
  try {
    const payload = {
      electricMeterID: editMeter.value.electricMeterID,
      electricMeterNumber: editMeter.value.electricMeterNumber,
      electricMeterName: editMeter.value.electricMeterName,
      electricMeterTag: editMeter.value.electricMeterTag,
      electricMeterNote: editMeter.value.electricMeterNote,
      electricMeterUsageID: editMeter.value.electricMeterUsageID, // 直接使用 electricMeterUsageID
      electricMeterInstallStatus: editMeter.value.electricMeterInstallStatus,
      electricMeterInstallDate: editMeter.value.electricMeterInstallDate,
      electricMeterCT: parseFloat(editMeter.value.electricMeterCT),
      electricMeterCT_X: parseFloat(editMeter.value.electricMeterCT_X),
      electricMeterCT_Y: parseFloat(editMeter.value.electricMeterCT_Y),
      electricMeterPT: parseFloat(editMeter.value.electricMeterPT),
      electricMeterPT_X: parseFloat(editMeter.value.electricMeterPT_X),
      electricMeterPT_Y: parseFloat(editMeter.value.electricMeterPT_Y),
      electricMeterStartValue: parseFloat(
        editMeter.value.electricMeterStartValue
      ),
      electricMeterInstallCompany: editMeter.value.electricMeterInstallCompany,
      electricMeterUsingStatus: editMeter.value.electricMeterUsingStatus,
      contractNumber: editMeter.value.contractNumber,
      electricMeterModelID: selectedModelForEditMeter.value.modelID,
    };

    console.log("Updating meter:", JSON.stringify(payload, null, 2));
    const response = await axios.put(
      `https://localhost/IEMSB/api/electricmeters/${editMeter.value.electricMeterID}`,
      payload
    );
    fetchMeters();
    isEditDialogOpen.value = false;
    $q.notify({
      type: "positive",
      message: "編輯電錶成功",
      position: "center",
    });
  } catch (error) {
    console.error("Failed to update meter:", error);
    $q.notify({
      type: "negative",
      message: "編輯電錶失敗",
      position: "center",
    });
  }
};

const deleteMeter = async (id) => {
  try {
    await axios.delete(`https://localhost/IEMSB/api/electricmeters/${id}`);
    fetchMeters();
    $q.notify({
      type: "positive",
      message: "刪除電錶成功",
      position: "center",
    });
  } catch (error) {
    console.error("Failed to delete meter:", error);
    $q.notify({
      type: "negative",
      message: "刪除電錶失敗",
      position: "center",
    });
  }
};

const confirmDeleteMeter = (meter) => {
  $q.notify({
    type: "warning",
    message: `確定要刪除電表-${meter.electricMeterName}嗎?`,
    position: "center",
    timeout: 0,
    actions: [
      {
        label: "否",
        color: "white",
        handler: () => {},
      },
      {
        label: "是",
        color: "negative",
        handler: () => {
          deleteMeter(meter.electricMeterID);
        },
      },
    ],
  });
};

const openAddDialog = () => {
  isAddDialogOpen.value = true;
};

const openEditDialog = (meter) => {
  // 克隆 meter 的資料到 editMeter
  editMeter.value = { ...meter };

  // 查找并绑定对应的用途对象
  editMeter.value.electricMeterUsageID = meter.electricMeterUsageID;

  // 查找并绑定对应的电表型号
  selectedModelForEditMeter.value = meterModels.value.find(
    (model) => model.modelID === meter.electricMeterModelID
  );

  isEditDialogOpen.value = true;
};
</script>

<style scoped>
.connected {
  color: green;
}

.disconnected {
  color: red;
}

.meter-table {
  width: 100%;
  border-collapse: collapse;
}
</style>
