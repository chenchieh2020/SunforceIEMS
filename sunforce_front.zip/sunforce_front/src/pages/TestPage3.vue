<template>
  <div class="q-pa-md">
    <q-card>
      <q-card-section>
        <div class="row q-gutter-md">
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption1"
              :options="options1"
              label="選擇客戶名稱"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption2"
              :options="options2"
              label="選擇區域(第一層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption3"
              :options="options3"
              label="選擇區域(第二層)"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption5"
              :options="options5"
              label="選擇閘道器"
              outlined
              dense
            />
          </q-col>
          <q-col cols="12" sm="4" md="3" class="col-25">
            <q-select
              v-model="selectedOption4"
              :options="options4"
              label="選擇用電種類"
              outlined
              dense
            />
          </q-col>

          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="搜索"
              color="primary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
          <q-col cols="12" sm="4" md="3">
            <q-btn
              label="匯出Excel"
              color="secondary"
              @click="onSearch"
              unelevated
              class="full-width"
            />
          </q-col>
        </div>
      </q-card-section>
    </q-card>
  </div>
  <q-page class="q-pa-md">
    <q-table
      :rows="filteredMeters"
      :columns="columns"
      row-key="id"
      :rows-per-page-options="[5, 10, 20]"
      v-model:pagination="pagination"
      flat
      bordered
      class="meter-table"
    >
      <template v-slot:body-cell-name="props">
        <q-td :props="props">
          <span class="meter-name">{{ props.row.name }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-connectionStatus="props">
        <q-td :props="props">
          <span
            :class="{
              connected: props.row.connectionStatus === '連接中',
              disconnected: props.row.connectionStatus === '離線',
            }"
          >
            {{ props.row.connectionStatus }}
          </span>
        </q-td>
      </template>
      <template v-slot:body-cell-threePhaseVoltage="props">
        <q-td :props="props">
          <span>{{ props.row.threePhaseVoltage.join(" / ") }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-threePhaseCurrent="props">
        <q-td :props="props">
          <span>{{ props.row.threePhaseCurrent.join(" / ") }}</span>
        </q-td>
      </template>
      <template v-slot:body-cell-usageType="props">
        <q-td :props="props">{{ props.row.usageType }}</q-td>
      </template>
      <template v-slot:body-cell-region="props">
        <q-td :props="props">{{ props.row.region }}</q-td>
      </template>
    </q-table>
  </q-page>
</template>

<script setup>
import { ref, computed } from "vue";

const selectedOption1 = ref(null);
const selectedOption2 = ref(null);
const selectedOption3 = ref(null);
const selectedOption4 = ref(null);
const selectedOption5 = ref(null);

const options1 = [
  { label: "台灣化學纖維股份有限公司", value: "1-1" },
  { label: "台灣電力股份有限公司", value: "1-2" },
  { label: "台灣高速鐵路股份有限公司", value: "1-3" },
];

const options2 = [
  { label: "全廠", value: "2-1" },
  { label: "新港廠", value: "2-2" },
  { label: "麥寮廠", value: "2-3" },
  { label: "龍德廠", value: "2-4" },
];

const options3 = [
  { label: "全區", value: "3-1" },
  { label: "區域A", value: "3-2" },
  { label: "區域B", value: "3-3" },
  { label: "區域C", value: "3-4" },
];

const options4 = [
  { label: "空調用電", value: "4-1" },
  { label: "照明用電", value: "4-2" },
  { label: "動力用電", value: "4-3" },
  { label: "空壓用電", value: "4-4" },
];

const options5 = [
  { label: "Gateway 1", value: "5-1" },
  { label: "Gateway 2", value: "5-2" },
  { label: "Gateway 3", value: "5-3" },
  { label: "Gateway 4", value: "5-4" },
];

const onSearch = () => {
  console.log("搜索點擊", {
    option1: selectedOption1.value,
    option2: selectedOption2.value,
    option3: selectedOption3.value,
    option4: selectedOption4.value,
    option5: selectedOption5.value,
  });
};

const columns = [
  { name: "name", label: "裝置名稱", field: "name", align: "left" },
  {
    name: "connectionStatus",
    label: "連線狀態",
    field: "connectionStatus",
    align: "left",
  },
  { name: "gateway", label: "閘道器", field: "gateway", align: "left" },
  { name: "current", label: "電流 (A)", field: "current", align: "right" },
  { name: "voltage", label: "電壓 (V)", field: "voltage", align: "right" },
  { name: "frequency", label: "頻率 (Hz)", field: "frequency", align: "right" },
  { name: "power", label: "功率 (W)", field: "power", align: "right" },
  {
    name: "powerFactor",
    label: "功率因數",
    field: "powerFactor",
    align: "right",
  },
  {
    name: "threePhaseVoltage",
    label: "三相電壓",
    field: "threePhaseVoltage",
    align: "right",
  },
  {
    name: "threePhaseCurrent",
    label: "三相電流",
    field: "threePhaseCurrent",
    align: "right",
  },
  {
    name: "energyConsumption",
    label: "用電數值 (kWh)",
    field: "energyConsumption",
    align: "right",
  },
  { name: "usageType", label: "用電種類", field: "usageType", align: "left" },
  { name: "region", label: "所屬區域", field: "region", align: "left" },
];

const pagination = ref({
  page: 1,
  rowsPerPage: 10,
  rowsNumber: 0,
});

const meters = ref([
  {
    id: 1,
    name: "電表1",
    gateway: "Gateway 1",
    connectionStatus: "連接中",
    current: 10,
    voltage: 220,
    frequency: 60,
    power: 2200,
    powerFactor: 0.95,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [10, 10, 10],
    energyConsumption: 100,
    usageType: "空調",
    region: "區域A",
  },
  {
    id: 2,
    name: "電表2",
    gateway: "Gateway 2",
    connectionStatus: "離線",
    current: 15,
    voltage: 220,
    frequency: 60,
    power: 3300,
    powerFactor: 0.92,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [15, 15, 15],
    energyConsumption: 200,
    usageType: "照明",
    region: "區域B",
  },
  {
    id: 3,
    name: "電表3",
    gateway: "Gateway 3",
    connectionStatus: "連接中",
    current: 12,
    voltage: 220,
    frequency: 60,
    power: 2640,
    powerFactor: 0.96,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [12, 12, 12],
    energyConsumption: 150,
    usageType: "動力",
    region: "區域C",
  },
  {
    id: 4,
    name: "電表4",
    gateway: "Gateway 4",
    connectionStatus: "連接中",
    current: 20,
    voltage: 220,
    frequency: 60,
    power: 4400,
    powerFactor: 0.9,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [20, 20, 20],
    energyConsumption: 300,
    usageType: "插座",
    region: "區域A",
  },
  {
    id: 5,
    name: "電表5",
    gateway: "Gateway 5",
    connectionStatus: "離線",
    current: 11,
    voltage: 220,
    frequency: 60,
    power: 2420,
    powerFactor: 0.94,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [11, 11, 11],
    energyConsumption: 120,
    usageType: "空壓",
    region: "區域B",
  },
  {
    id: 6,
    name: "電表6",
    gateway: "Gateway 6",
    connectionStatus: "連接中",
    current: 18,
    voltage: 220,
    frequency: 60,
    power: 3960,
    powerFactor: 0.91,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [18, 18, 18],
    energyConsumption: 250,
    usageType: "空調",
    region: "區域C",
  },
  {
    id: 7,
    name: "電表7",
    gateway: "Gateway 7",
    connectionStatus: "連接中",
    current: 14,
    voltage: 220,
    frequency: 60,
    power: 3080,
    powerFactor: 0.93,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [14, 14, 14],
    energyConsumption: 180,
    usageType: "照明",
    region: "區域A",
  },
  {
    id: 8,
    name: "電表8",
    gateway: "Gateway 8",
    connectionStatus: "離線",
    current: 22,
    voltage: 220,
    frequency: 60,
    power: 4840,
    powerFactor: 0.89,
    threePhaseVoltage: [220, 380, 220],
    threePhaseCurrent: [22, 22, 22],
    energyConsumption: 350,
    usageType: "動力",
    region: "區域B",
  },
]);

const filteredMeters = computed(() => {
  const start = (pagination.value.page - 1) * pagination.value.rowsPerPage;
  const end = start + pagination.value.rowsPerPage;
  return meters.value.slice(start, end);
});
</script>

<style scoped>
.connected {
  color: green;
}

.disconnected {
  color: red;
}

.meter-table {
  width: 100%;
  border-collapse: collapse;
}
</style>
